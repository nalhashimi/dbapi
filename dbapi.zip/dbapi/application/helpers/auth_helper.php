<?php
/**
 * Provides authorized access to the system for a user, based on the provided
 * credentials, using a query to the database. If the authorization is
 * successful, a unique JSON Web Token is generated and stored in a cookie.
 * @param  $table - The database table to query.
 * @param $fields - An array of names for the fields to be requested.
 * @param $username_field - The name of the username field.
 * @param $password_field - The name of the password field.
 * @param $id_field - The name of the id field.
 * @param $username_value - The value of the username field.
 * @param $password_value - The value of the password field.
 * @param $service_name - The name of the service.
 * @param $cookie_name - The name of the cookie used to store the authorization
 *  token.
 * @return associative array
 */
function authorize($username_value, $password_value, $servername, $libList, $connType, $persistent, $dbjob, $pcontimeout, $store)
{
    // Load the appropriate helpers
    $ci = & get_instance();
    $ci->load->helper('database');
    $ci->load->helper('error_code');
    
    $ci->load->model('RemoteRequest_model');
    log_message("ERROR", "POST: " . print_r($_POST,true));
    $isValid = $ci->RemoteRequest_model->Connect($_POST);
    $token = '';
    if($isValid) {
        $token = generate_jwt($username_value, $password_value, $servername, $libList, $connType, $persistent, $dbjob, $pcontimeout, $store);
    } else {
        $token = array(
            "code" => BAD_CREDENTIALS,
            "message" => "Token cannot be generated with bad credentials."
        );
    }
    return $token;
}

/**
 * Generates a unique JSON Web Token from the values provided.
 * @param $username_value - The user's unique username.
 * @param $id_value - The user's unique id.
 * @param $service_name - The name of the service.
 * @param $cookie_name - The name of the cookie used to store the authorization
 *  token.
 * @return void
 */
function generate_jwt($username_value, $password_value, $servername, $libList, $connType, $persistent, $dbjob, $pconnTimeOut, $store){
  $secret = parse_ini_file(__DIR__.'/../../config.ini')["secret"];

  $timestamp = date_timestamp_get(date_create());
  mt_srand(intval(substr($timestamp,-16,12)/substr(join(array_map(function ($n) { return sprintf('%03d', $n); }, unpack('C*', $secret))),0,2)));
  $stamp_validator = mt_rand();

  $token = array(
    "iat" => $timestamp,
    "chk" => $stamp_validator,
    "username" => $username_value,
    "password" => $password_value,
    "liblist" => $libList,
    "conntype" => $connType,
    "servername" => $servername,
    "persistent" => $persistent, 
    "dbjob"         => $dbjob,
    "pcontimeout"   => $pconnTimeOut,
    "store"         => $store
  );
  $cookie = array (
    "code" => SUCCESS,
    "token" => jwt_encode($token, $secret)
  );
  
  //   return array(
  //     "code" => SUCCESS,
  //     "message" => "Token regenerated successfully."
  //   );
  return  $cookie["token"];
  // Change the first NULL below to set a domain, change the second NULL below
  // to make this only transmit over HTTPS
  //setcookie($cookie_name, json_encode($cookie), 0, "/", NULL, NULL, true );
}

/**
 * Regenerates a unique JSON Web Token from the values provided. Will return a
 * message if no existing cookie is found.
 * @param $service_name - The name of the service.
 * @param $cookie_name - The name of the cookie used to store the authorization
 *  token.
 * @return associative array
 */
// function regenerate_jwt_cookie($service_name, $cookie_name){
//   // Load the appropriate helpers
//   $ci =& get_instance(); $ci->load->helper('jwt'); $ci->load->helper('error_code');
//   $secret = parse_ini_file(__DIR__.'/../../config.ini')["secret"];

//   if(!isset($_COOKIE[$cookie_name]))
//     return array(
//       "code" => NO_COOKIE,
//       "message" => "Token not found."
//     );

//   $cookie_contents = json_decode($_COOKIE[$cookie_name], true);
//   $token = (array)jwt_decode($cookie_contents["token"], $secret);

//   generate_jwt($token["username"], $token["id"], $service_name, $cookie_name);
//   return array(
//     "code" => SUCCESS,
//     "message" => "Token regenerated successfully."
//   );
// }

/**
 * Checks the validity of a unique JSON Web Token.
 * 
 * @param $tokenIn -
 *            JWT from client.
 * @return true if the cookie is found and the JWT is valid, false otherwise
 */
function is_jwt_valid($tokenIn)
{
    // Load the appropriate helpers
    $ci = & get_instance();
    $ci->load->helper('jwt');
    $secret = parse_ini_file(__DIR__ . '/../../config.ini')["secret"];
    
    if (! isset($tokenIn)) {
        return false;
    }
    
    $token = (array) jwt_decode($tokenIn, $secret);
    
    mt_srand(intval(substr($token["iat"], - 16, 12) / substr(join(array_map(function ($n) {
        return sprintf('%03d', $n);
    }, unpack('C*', $secret))), 0, 2)));
    $stamp_validator = mt_rand();
    if ($stamp_validator != $token["chk"]) {
        return false;
    }
    
    $currTimestamp = date_timestamp_get(date_create());
    $expiration = $currTimestamp - $token["iat"];
    if ($expiration > TOKEN_EXPIRE_LIMIT) {
        return false;
    }
    
    return array(
        "valid" => true,
        "token" => $token
    );
}


function temp_read_token($tokenIn)
{
    // Load the appropriate helpers
    $ci = & get_instance();
    $ci->load->helper('jwt');
    $secret = parse_ini_file(__DIR__ . '/../../config.ini')["secret"];
    
    if (! isset($tokenIn))
        return false;
        
        $token = (array) jwt_decode($tokenIn, $secret);
        echo 'Is token still valid: ' . print_r($token, true);
        
        
        
}


/**
 * Regenerates a unique JSON Web Token from the values provided. Will return a
 * message if no existing cookie is found.
 * @param $service_name - The name of the service.
 * @param $cookie_name - The name of the cookie used to store the authorization
 *  token.
 * @return associative array
 */
function regenerate_jwt($tokenIn){
    // Load the appropriate helpers
    $ci =& get_instance(); $ci->load->helper('jwt'); $ci->load->helper('error_code');
    $secret = parse_ini_file(__DIR__.'/../../config.ini')["secret"];
    
    if(!isset($tokenIn) && $tokenIn != '')
        return array(
            "code" => NO_COOKIE,
            "message" => "Token not found."
        );
        
        //$cookie_contents = json_decode($_COOKIE[$cookie_name], true);
        $token = (array)jwt_decode($tokenIn, $secret);
        //$username_value, $password_value, $servername, $libList, $connType
        return generate_jwt($token["username"], $token["password"], $token["servername"], $token["liblist"], $token["conntype"]);
        
}

/**
 * Checks the validity of a unique JSON Web Token.
 * @param $service_name - The name of the service.
 * @param $cookie_name - The name of the cookie used to store the authorization
 *  token.
 * @return true if the cookie is found and the JWT is valid, false otherwise
 */
function check_jwt_cookie($service_name, $cookie_name){
  // Load the appropriate helpers
  $ci =& get_instance(); $ci->load->helper('jwt');
  $secret = parse_ini_file(__DIR__.'/../../config.ini')["secret"];

  if(!isset($_COOKIE[$cookie_name]))
    return false;

  $cookie_contents = json_decode($_COOKIE[$cookie_name], true);
  $token = (array)jwt_decode($cookie_contents["token"], $secret);

  if($token["iss"] != $service_name)
    return false;

  if($token["id"] != $cookie_contents["id"])
    return false;

  mt_srand(intval(substr($token["iat"],-16,12)/substr(join(array_map(function ($n) { return sprintf('%03d', $n); }, unpack('C*', $secret))),0,2)));
  $stamp_validator = mt_rand();
  if($stamp_validator != $token["chk"])
    return false;

  return true;
}

/**
 * Get header Authorization
 * */
function getAuthorizationHeader(){
    $headers = null;
    if (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER["Authorization"]);
    }
    else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { //Nginx or fast CGI
        $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
    } elseif (function_exists('apache_request_headers')) {
        $requestHeaders = apache_request_headers();
        // Server-side fix for bug in old Android versions (a nice side-effect of this fix means we don't care about capitalization for Authorization)
        $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
        //print_r($requestHeaders);
        if (isset($requestHeaders['Authorization'])) {
            $headers = trim($requestHeaders['Authorization']);
        }
    }
    return $headers;
}
/**
 * get access token from header
 * */
function getBearerToken() {
    $headers = getAuthorizationHeader();
    // HEADER: Get the access token from the header
    if (!empty($headers)) {
        if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
            return $matches[1];
        }
    }
    return null;
}

/**
 * Gets the data stored in a unique JSON Web Token.
 * @param $cookie_name - The name of the cookie used to store the authorization
 *  token.
 * @return associative array
 */
function get_jwt_data($cookie_name){
  // Load the appropriate helpers
  $ci =& get_instance(); $ci->load->helper('jwt'); $ci->load->helper('error_code');
  $secret = parse_ini_file(__DIR__.'/../../config.ini')["secret"];

  if(!isset($_COOKIE[$cookie_name]))
    return array(
      "code" => NO_COOKIE,
      "message" => "Token not found."
    );

  $cookie_contents = json_decode($_COOKIE[$cookie_name], true);
  return (array)jwt_decode($cookie_contents["token"], $secret);
}
?>
