<?php

abstract class ISeries_model extends CI_Model
{
    public $conn            = false;
    public $connProd        = false;

    public $IsMobile        = false;
    public $TRACE           = false;
    public $TRACE_AREAS     = false;
    public $PORTAL_LOGMAIL  = false;

    function __construct($IsMobile=false, $Connect=true)
    {
        // Call CodeIgniter
        parent::__construct();
    }

    abstract function __destruct();

    abstract function Connect($connectOptions);

    abstract function Disconnect($ForceProduction=false);

    abstract function Query2($sql, $prod=false);

    abstract function Select($sql, $values=null, $EmptyResults=false, $prod=false);

    abstract function Update($sql, $values=null, $prod=false);

    abstract function LogDbError($sql, $values=null);

    //abstract function DataArea_Read($key);

    //abstract function DataArea_Write($key, $value, $length);

    function HTMLFormat($str)
    {
        // Replace plaintext entities with HTML
        $str = str_replace("<", "&lt;", $str);
        $str = str_replace(">", "&gt;", $str);
        $str = str_replace(" ", "&nbsp;", $str);
        $str = str_replace("\n", "<br/>", $str);
        return $str;
    }

    function DataArea_Read($key, $library = false)
    {
        $this->load->model('Socket_model');
        $socketCallObj = new Socket_model();

        // Call Socket
        $data = $socketCallObj->DataAreaRead($key, $library);
        $socketCallObj->Disconnect();

        unset($socketCallObj);

        return $data;
    }

    function DataArea_Write($key, $library, $value)
    {

        $this->load->model('Socket_model');
        $socketCallObj = new Socket_model();

        // Call Socket
        $data = $socketCallObj->DataArea_Write($key, $library, $value);
        $socketCallObj->Disconnect();

        unset($socketCallObj);

        return true;
    }
    
    
    function QTrace($title, $sql, $isData=false, $header=true)
    {
        $path = "/DriverCentral/RDB_" . DCMOBILE_SITETAG . ".log";
        if($header) $sql = "\n\n###################### ".date('Ymd H:i:s')." $title #####################\n\n".$sql;

        if(!$isData)
        {
            // Read easycom error
            $msg = '';
            // EasyCom page says both bool and array
            $err = db2_stmt_error();
            if(isset($err))
            {
                $msg = "Error ".$err . "\nSQL: " . $sql . " \nMessage: " . db2_stmt_errormsg();
            }
            $sql .= $msg;

            // Read php error
            $phperr = error_get_last();
            // Returns an associative array describing the last error with keys "type", "message", "file" and "line".
            /// If the error has been caused by a PHP internal function then the "message" begins with its name.
            // Returns NULL if there hasn't been an error yet.
            if(!is_null($phperr))
            {
                $msg = "\n## PHP Error!\n## Type=".$phperr['type']."\n## Message=".$phperr['message']."\n## File=".$phperr['file']."\n## Line=".$phperr['line']."\n";
            }
            else
            {
                $msg = "\n## No PHP Error!";
            }
            $sql .= $msg;
        }

        // Log sql and error
        $fh = fopen($path, 'a');
        if ($fh !== false)
        {
            fwrite($fh, $sql);
            fclose($fh);
        }
    }

    function Log($text)
    {
        $path = "/DriverCentral/RDB_DbError_" . DCMOBILE_SITETAG . ".log";

        // Add header
        $text = "\n\n###################### ".date('Ymd H:i:s')." Fatal #####################\n".$text;

        // APPEND
        $fh = fopen($path, 'a');
        if ($fh !== false)
        {
            fwrite($fh, $text);
            fclose($fh);
        }
    }
}

?>