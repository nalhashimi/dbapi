<?php

class RemoteRequest_model extends CI_Model
{
    public $ISeriesDB       = false;
    
    private $requiredConnectionSettings = ['conntype', 'username', 'password', 'servername', 'liblist', 'dbjob'];
    
    function __construct()
    {
        // Call CodeIgniter
        parent::__construct();
        
    }
    
    function __destruct()
    {
        //$this->Disconnect();
    }
    
    function SetOption($options) {
        
    }
    
    function InValidToken() {
        $this->load->helper('error_code');
        echo json_encode(array(
            "code" => BAD_CREDENTIALS,
            "message" => "Token is not valid."
        ));
    }
    
    private function checkRequiredSettings($connectOptions) 
    {
        foreach ($this->requiredConnectionSettings as $aSetting) {
            if(!isset($connectOptions[$aSetting])) {
                return false;
            }
        }
        return true;
    }
    
    function Connect($connectOptions)
    {
        
        if(!$this->checkRequiredSettings($connectOptions)) {
            return false;
        }
        if($connectOptions['conntype'] != 'db2') {
            $this->load->model('ISeries_I5_model', 'db');
        } else {
            $this->load->model('ISeries_DB2_model', 'db');
        }
        
        
        $rtn = $this->db->Connect($connectOptions);
        
        $this->ISeriesDB = $this->db;
        
        return $rtn;
    }
    
    function Disconnect($ForceProduction=false)
    {
        $this->ISeriesDB->Disconnect($ForceProduction);
    }
    
    function Select($sql, $values=null, $EmptyResults=false, $prod=false)
    {
        $time = -microtime(true);
        $rtn =  $this->ISeriesDB->Select($sql, $values, $EmptyResults, $prod);
        
        // Performance: End
        $time += microtime(true);
        $timeStr = sprintf('%0.2f', $time);
        log_message("ERROR", 'Select (Calc: '.$timeStr.')' . print_r($sql,true) . " V:" . print_r($values,true) . " R:" . print_r($rtn,true));
        
        return $rtn;
    }
    
    
    function Update($sql, $values=null, $prod=false)
    {
        $time = -microtime(true);
        $rtn =  $this->ISeriesDB->Update($sql, $values, $prod);
        
        // Performance: End
        $time += microtime(true);
        $timeStr = sprintf('%0.2f', $time);
        //log_message("ERROR", 'Select (Calc: '.$timeStr.')' . print_r($sql,true) . " V:" . print_r($values,true));
        
        return $rtn;
    }
}