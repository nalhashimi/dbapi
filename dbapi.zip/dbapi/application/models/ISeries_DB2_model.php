<?php
require_once 'ISeries_model.php';
class ISeries_DB2_model extends ISeries_model
{

    public $conn            = false;
    public $connProd        = false;

    public $IsMobile        = false;
    public $TRACE           = false;
    public $TRACE_AREAS     = false;
    public $PORTAL_LOGMAIL  = false;
       
    
    private $PersistentConn = false;
    private $dbUsername     = false;
    private $dbPassword     = false;
    private $DbServerName   = false;
    private $connOptions    = false;

    function __construct()
    {
        // Call CodeIgniter
        parent::__construct();


        // Connect database if not connected
        //if($Connect) $this->Connect();
    }

    function __destruct()
    {
        //$this->Disconnect();
    }
    
    
    function Connect($connectOptions/* $DbServerName, $dbUsername, $dbPassword, $connOptions, $PersistentConn, $dbJob = 'DCPORTAL' */)
    {
        $newConn = true;
        $DFTLIBL = false;
        $old = error_reporting();
        error_reporting(E_ALL & ~E_NOTICE);
        // Connect database if not connected
        if((!$this->conn))
        {
            
            $this->PersistentConn         = (isset($connectOptions['persistent']) && strtoupper($connectOptions['persistent']) == 'Y') ? TRUE : FALSE;
            $this->dbUsername             = strtoupper($connectOptions['username']);
            $this->dbPassword             = strtoupper($connectOptions['password']);
            $this->DbServerName           = strtoupper($connectOptions['servername']);
            $this->connOptions            = array(
                'autocommit' => DB2_AUTOCOMMIT_ON,
                'i5_libl' =>  strtoupper((strlen($connectOptions['liblist'])  > 0 ? str_ireplace(',', ' ', $connectOptions['liblist']) : '')),
                'i5_naming' => DB2_I5_NAMING_ON,
                'i5_query_optimize' => DB2_ALL_IO
            );
            
            if ($this->PersistentConn) {
                $attemptCount = 3;
                do {
                    
                    $newConn = db2_pconnect($this->DbServerName, $this->dbUsername, $this->dbPassword, $this->connOptions);
                    
                    // work around for closed/ended connections.
                    $connError = db2_conn_error($newConn);
                    $isError = $connError !== '';
                    
                    if($isError) {
                        
                        db2_pclose($newConn);
                        $this->LogDbError("CONNECT ERROR", print_r($connError,true));
                    }
                    
                    $attemptCount--;
                    
                } while ($isError && $attemptCount > 0);
            } else {
                $newConn = db2_connect($this->DbServerName, $this->dbUsername, $this->dbPassword, $this->connOptions);
            }
            
            // Re-enable PHP errors
            error_reporting($old);
            
            // Check error
            if(!is_resource($newConn) || db2_conn_error($newConn)) $this->LogDbError("Connect");
            
            
            // Save connection
            $this->conn = $newConn;
        }
        
        return $this->conn;
        
    }

    function Disconnect($ForceProduction=false)
    {
        // Disconnect database
        if($this->conn)
        {
            if ($this->PersistentConn) {
                // This will not close the presistent connection...
                // To close the connection, call db2_pclose, but we
                // want to leave the connection open for next request.
                $success = db2_close( $this->conn);
            } else {
                $success = db2_close($this->conn);
            }
            if(!$success) $this->LogDbError("Disconnect");
            $this->conn = false;
        }
    }

    /**
     * @param string $sql - Statement to run
     * @param boolean $prod - force to use production connection to DB2
     * @param boolean $emptyResults - If SQL statement should return results
     * @return boolean|resource
     */
    function Query2($sql, $prod=false, $emptyResults = false)
    {
        /*
         * SELECT: Returns array(n > 1) or FALSE if empty resultset
         * UPDATE/DELETE: Returns TRUE if success or FALSE if error
         */
        if($this->TRACE)
        {
            $this->QTrace('Query2', $sql, true);
        }

        $result = false;

        // Performance: Start
        $time = -microtime(true);

        // Select connection
        $connUse = ($prod ? $this->connProd : $this->conn);

        $attemptCount = DBAttemptConn;
        do {
            // Connect if necessary
            if(!is_resource($connUse))
            {
                $connUse = $this->Connect($prod);
            }

            // Query
            $data = db2_exec($connUse, $sql);
            if (is_resource($data))
            {
                // Set array(n > 1)
                //if(!$emptyResults) {
                $funcZero = function($name ,$value, $stmt) {
                    return (db2_field_type($stmt, $name) != 'string' ? (($value != '') ? $value * 1 : $value ): rtrim($value));
                };

                while($row = db2_fetch_assoc($data))
                {
                    $trimmed_array=array_map($funcZero, array_keys($row), array_values($row), array_fill(0, count($row), $data));
                    $trimmed_array=array_combine(array_keys($row), $trimmed_array);
                    $result[] = (object) $trimmed_array;
                }
                db2_free_result ($data);

                // Set FALSE if Empty Resultset
                if (!$emptyResults && count($result) == 0) $result = false;
                //}
                db2_commit($connUse);
            }
            else
            {
                // Set TRUE/FALSE
                $result = $data;

                // Log error on FALSE
                $this->LogDbError($sql);
            }
            $attemptCount--;
        } while (!is_resource($data) && $attemptCount > 0);

        // Disconnect if necessary
        if($prod) $this->DisconnectDB2($prod);

        // Performance: End
        $time += microtime(true);
        $timeStr = sprintf('%0.2f', $time);

        // TRACE
        if($this->TRACE && $result !== false)
        {
            $this->QTrace('Query2 Result (Calc: '.$timeStr.')',  print_r($result, true), true);
        }

        return $result;
    }

    function Select($sql, $values=null, $EmptyResults=false, $prod=false)
    {

        if(isset($values) && !is_array($values)) {
            $values = array($values);
        }
        // TRACE
        if($this->TRACE)
        {
            $this->QTrace('SELECT',         $sql,                   true);
            $this->QTrace('SELECT Vals',    print_r($values, true), true);
        }

        // Success: array(n > 0)
        // Fail or Empty: FALSE
        $result = false;

        //error_reporting(0);
        // No parameters: Use i5_query
        if(is_null($values)  || !$values)
        {
            $result = $this->Query2($sql, $prod, $EmptyResults);

            // If EmptyResults enabled, Set EMPTY ARRAY if n = 0
            if($EmptyResults && $result == false) $result = array();
        }
        else
        {
            // Performance: Start
            $time = -microtime(true);

            // Select connection
            $connUse = ($prod ? $this->connProd : $this->conn);

            $attemptCount = DBAttemptConn;
            do {
                // Connect if necessary
                if(!is_resource($connUse))
                {
                    $this->LogDbError("RECONNECT CONNUSE: ", false);
                    $connUse = $this->Connect($prod);
                }


                // NOTE: No parameters will raise errors such as "Key operation on file with no key".
                // If you must set one parameter use WHERE 1=? with param='1'.
                $query = db2_prepare( $connUse, $sql);

                if(is_resource($query))
                {

                    $success = db2_execute($query, $values);

                    //Frees the system and database resources
                    db2_free_stmt($query);

                    if($success !== false)
                    {

                        // Set array
                        $result = array();

                        $funcZero = function($name ,$value, $stmt) {
                            return (db2_field_type($stmt, $name) != 'string' ? (($value != '') ? $value * 1 : $value ) : rtrim($value));
                        };

                        while($row = db2_fetch_assoc($query))
                        {
                            $trimmed_array=array_map($funcZero, array_keys($row), array_values($row), array_fill(0, count($row), $query));
                            $trimmed_array=array_combine(array_keys($row), $trimmed_array);
                            $result[] = (object) $trimmed_array;
                        }

                        db2_free_result($query);

                        // If EmptyResults disabled, Set FALSE if n = 0
                        if (!$EmptyResults && count($result) == 0) $result = false;
                    }
                    else
                    {
                        // Fail: Log error on FALSE
                        $this->LogDbError($sql, $values);
                    }
                }
                else
                {
                    // Fail: Log error on FALSE
                    $this->LogDbError($sql, $values);
                    //$this->LogDbError(db2_stmt_errormsg());
                }
                $attemptCount--;
            } while (!is_resource($query) && $attemptCount > 0);

            // Disconnect if necessary
            if($prod) $this->Disconnect($prod);
            // Performance: End
            $time += microtime(true);
            $timeStr = sprintf('%0.2f', $time);

            // TRACE
            if($this->TRACE && $result !== false)
            {
                $this->QTrace('SELECT Result (Calc: '.$timeStr.')',  print_r($result, true), true);
            }
        }


        return $result;
    }

    function Update($sql, $values=null, $prod=false)
    {
        // TRACE
        if($this->TRACE)
        {
            $this->QTrace('UPDATE',         $sql,                   true);
            $this->QTrace('UPDATE Vals',    print_r($values, true), true);
        }

        // Success: TRUE
        // Fail: FALSE
        $result = false;

        // No parameters: Use i5_query
        if(is_null($values))
        {
            $result = $this->Query2($sql, $prod);
        }
        else
        {
            // Select connection
            $connUse = ($prod ? $this->connProd : $this->conn);

            $attemptCount = DBAttemptConn;
            do {
                // Connect if necessary
                if(!is_resource($connUse))
                {
                    $connUse = $this->Connect($prod);
                }
                $query = db2_prepare( $connUse, $sql);

                //Frees the system and database resources
                db2_free_stmt($query);

                if(is_resource($query))
                {
                    // Success or Fail
                    $result = db2_execute($query, $values);

                    // Fail: Log error on FALSE
                    if($result === false) $this->LogDbError($sql, $values);
                }
                else
                {
                    // Fail: Log error on FALSE
                    $this->LogDbError($sql, $values);
                }
                $attemptCount--;
            } while (!is_resource($query) && $attemptCount > 0);
        }

        if(!$result) {

            // Fail: Log error on FALSE
            $this->LogDbError($sql, $values);
        }

        // TRACE
        if($this->TRACE) $this->QTrace('UPDATE Result', ($result ? 'UPDATE OK' : 'UPDATE FAIL!!!'), true);

        return $result;
    }




    /**
     * Logs messages to file or displays when ECHO_DB_ERROR is set to true.
     * @param string $sql      - SQL script to log
     * @param array $values   - Any values used in SQL query to log
     * @return string           - Error message is returned.
     */
    function LogDbError($sql, $values=null)
    {
        $msg = '';

        // EasyCom page says both bool and array
        $err = db2_stmt_error();
        if(isset($err))
        {
            $msg = "Error ".$err . "\nSQL: " . $sql . " \nMessage: " . db2_stmt_errormsg();
        }

        if(ECHO_DB_ERROR )
        {
            echo "<h1>LogDbError</h1>".$this->HTMLFormat($msg).(!is_null($values) ? "\n<h2>Values</h2>".print_r($values, true) : "");
        }

        $this->Log($msg."\n\n".print_r($values,true));

        return $msg;
    }




}

?>