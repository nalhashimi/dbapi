<?php
require_once 'ISeries_model.php';
class ISeries_I5_Model extends ISeries_model
{
    public $conn            = false;
    public $connProd        = false;

    public $IsMobile        = false;
    public $TRACE           = false;
    public $TRACE_AREAS     = false;
    public $PORTAL_LOGMAIL  = false;
    
    
    private $PersistentConn = false;
    private $dbUsername     = false;
    private $dbPassword     = false;
    private $DbServerName   = false;
    private $connOptions    = false;
    
    function __construct($IsMobile=false, $Connect=false)
    {
        // Call CodeIgniter
        parent::__construct();


        // Connect database if not connected
        if($Connect) $this->Connect();
    }


    function __destruct()
    {
        $this->Disconnect();
    }


    function Connect($connectOptions = false)
    {
        // Returns: connection resource if created, true if already connected
        $newConn = true;
        $DFTLIBL = false;

        // Use same connection if already on production
        //if($ForceProduction && DbServer == 'as400p') $ForceProduction = false;

        // Connect database if not connected
        if(!$this->conn)
        {
            // Check for Store Login
            $this->dbUsername             = strtoupper($connectOptions['username']);
            $this->dbPassword             = strtoupper($connectOptions['password']);
            $this->DbServerName           = strtoupper($connectOptions['servername']);
            
            $this->PersistentConn         = (isset($connectOptions['persistent']) && strtoupper($connectOptions['persistent']) == 'y') ? TRUE : FALSE;

            // Set job name
            //  Assert NOT MOBILE because we also assert Desktop Auth Session
            /* 7/27/2017 Update to give a more generic job name
             $dbJob = "DC".(!$this->IsMobile && $this->userData->IsAuthenticated
             ? ($this->userData->LoginType == LoginType_Portal
             ?   "V_".substr($this->userData->Username,0,6)
             :    "_".substr($this->userData->Username,0,7))
             : "ANON");
             */
            $dbJob = strtoupper($connectOptions['dbjob']);

            // Temporarily disable PHP errors
            $old = error_reporting();
            error_reporting(0);


            $connectionOptions = array (
                I5_OPTIONS_INITLIBL => 
                    (strlen($connectOptions['liblist'])  > 0 ? $connectOptions['liblist'] .',' : '').
                    'EASYCOM',
                I5_OPTIONS_JOBNAME                  => $dbJob,
                I5_OPTIONS_SQLNAMING                => 'SYS',
                I5_OPTIONS_AUTOMATIC_NEXT_RESULT    => '1'
            );

            if($store != '000') {
                $cmdString = "VCFSYS" . $store;
                if(strpos($connectionOptions[I5_OPTIONS_INITLIBL], 'STOREPGMS')) {
                    $connectionOptions[I5_OPTIONS_INITLIBL] = substr($connectionOptions[I5_OPTIONS_INITLIBL], 0, strpos($connectionOptions[I5_OPTIONS_INITLIBL], 'STOREPGMS'))   . $cmdString . ',' . substr($connectionOptions[I5_OPTIONS_INITLIBL], strpos($connectionOptions[I5_OPTIONS_INITLIBL], 'STOREPGMS'));
                }

            }

            if ($connectOptions['persistent'] == 'y') {

                $connectionOptions[I5_OPTIONS_IDLE_TIMEOUT] = $connectOptions['pconntimout'];

                $newConn = i5_pconnect($this->DbServerName, $this->dbUsername, $this->dbPassword, $connectionOptions
                    );
            } else {

                $newConn = i5_connect($this->DbServerName, $this->dbUsername, $this->dbPassword, $connectionOptions);
            }

            // Re-enable PHP errors
            error_reporting($old);
            
            // Check error
            if(!is_resource($newConn)) $this->LogDbError( "Connect");

            $this->conn = $newConn;

            // DFTLIBL Override
            if($DFTLIBL)
            {
                // Read DFTLIBL Data Area
                //   NOTE: Max library name length in this list is 10
                $LIBL_List = '';
                $DFTLIBL_Read = i5_command("RTVDTAARA", array("DTAARA" => "DFTLIBL"), array("RTNVAR" => "LIBL_List"), $newConn);

                if($DFTLIBL_Read)
                {
                    $DFTLIBL_List = explode(" ",strtoupper($LIBL_List));

                    foreach($DFTLIBL_List as $LibKey => $Lib)
                    {
                        // Remove empty, data, and pgm libraries
                        if(empty($Lib)
                            || (strlen(DbDataLib) > 0 && strpos($Lib, strtoupper(DbDataLib)) !== false)
                            || (strlen(DbPgmLib)  > 0 && strpos($Lib, strtoupper(DbPgmLib))  !== false)
                            )
                        {
                            unset($DFTLIBL_List[$LibKey]);
                        }
                    }

                    // Recreate list
                    $DFTLIBL_Set = '';

                    foreach($DFTLIBL_List as $Lib)
                    {
                        $DFTLIBL_Set .= str_pad(trim($Lib), 10, " ", STR_PAD_RIGHT);

                        // Add Data and Pgm libraries AFTER QTEMP
                        if($Lib == 'QTEMP')
                        {
                            if(strlen(DbDataLib) > 0) $DFTLIBL_Set .= " ".str_pad(DbDataLib, 10, " ", STR_PAD_RIGHT);
                            if(strlen(DbPgmLib)  > 0) $DFTLIBL_Set .= " ".str_pad(DbPgmLib,  10, " ", STR_PAD_RIGHT);
                        }
                    }

                    $DFTLIBL_Update = i5_command("CHGLIBL",   array("LIBL"   => $DFTLIBL_Set), array(), $newConn);
                    $DFTLIBL_Run    = i5_command("CHGCURLIB", array("CURLIB" => "*CRTDFT"),    array(), $newConn);

                    // Check errors
                    if(!($DFTLIBL_Update || $DFTLIBL_Run))
                    {
                        $this->LogDbError($ForceProduction ? "Prod_Connect" : "Connect");
                    }
                }
                else
                {
                    // Check error
                    $this->LogDbError($ForceProduction ? "Prod_Connect" : "Connect");
                }
            }
        }

        return $newConn;
    }

    function Disconnect($ForceProduction=false)
    {
        // Disconnect database
        if(( $this->conn))
        {
            if ($this->PersistentConn) {
                // Keep connection open for next connection request.
                $success = i5_close($ForceProduction ? $this->connProd : $this->conn);//i5_pclose($ForceProduction ? $this->connProd : $this->conn);
            } else {
                $success = i5_close($ForceProduction ? $this->connProd : $this->conn);
            }

            if(!$success) $this->LogDbError($ForceProduction ? "Prod_Disconnect" : "Disconnect");
            if($ForceProduction) $this->connProd = false; else $this->conn = false;
        }
    }

    function Query2($sql, $prod=false)
    {
        /*
         * SELECT: Returns array(n > 1) or FALSE if empty resultset
         * UPDATE/DELETE: Returns TRUE if success or FALSE if error
         */
        if($this->TRACE)
        {
            $this->QTrace('Query2', $sql, true);
        }

        $result = false;
        $ProdConnect = false;
        // Performance: Start
        $time = -microtime(true);

        // Select connection
        $connUse = $this->conn;

        // Connect if necessary
        if(!$connUse)
        {
            $connUse = $this->Connect(false);
        }

        // Query
        $data = i5_query($sql, $connUse);
        if (is_resource($data))
        {
            // Set array(n > 1)
            while($row = i5_fetch_object($data))
            {
                $result[] = $row;
            }
            i5_free_query($data);

            // Set FALSE if Empty Resultset
            if (count($result) == 0) $result = false;
        }
        else
        {
            // Set TRUE/FALSE
            $result = $data;

            // Log error on FALSE
            $this->LogDbError($sql);
        }

        // Disconnect if necessary
        if($ProdConnect) $this->Disconnect(true);
        // Performance: End
        $time += microtime(true);
        $timeStr = sprintf('%0.2f', $time);

        // TRACE
        if($this->TRACE && $result !== false)
        {
            $this->QTrace('Query2 Result (Calc: '.$timeStr.')',  print_r($result, true), true);
        }


        return $result;
    }

    function Select($sql, $values=null, $EmptyResults=false, $prod=false)
    {
        // TRACE
        if($this->TRACE)
        {
            $this->QTrace('SELECT',         $sql,                   true);
            $this->QTrace('SELECT Vals',    print_r($values, true), true);
        }

        // Success: array(n > 0)
        // Fail or Empty: FALSE
        $result = false;
        $ProdConnect = false;


        // No parameters: Use i5_query
        if(is_null($values))
        {
            $result = $this->Query2($sql, $prod);

            // If EmptyResults enabled, Set EMPTY ARRAY if n = 0
            if($EmptyResults && $result == false) $result = array();
        }
        else
        {
            // Performance: Start
            $time = -microtime(true);
            // Select connection
            $connUse = ($prod ? $this->connProd : $this->conn);

            // Connect if necessary
            if(!$connUse && $prod)
            {
                $connUse = $this->Connect(true);
                $ProdConnect = true;
            }

            // NOTE: No parameters will raise errors such as "Key operation on file with no key".
            // If you must set one parameter use WHERE 1=? with param='1'.
            $query = i5_prepare($sql, $connUse);

            if(is_resource($query))
            {
                $success = i5_execute($query, $values);

                if($success !== false)
                {
                    // Set array
                    $result = array();
                    while($row = i5_fetch_object($query))
                    {
                        $result[] = $row;
                    }
                    i5_free_query($query);

                    // If EmptyResults disabled, Set FALSE if n = 0
                    if (!$EmptyResults && count($result) == 0) $result = false;
                }
                else
                {
                    // Fail: Log error on FALSE
                    $this->LogDbError(__FUNCTION__ . ": " . $sql, $values);
                }
            }
            else
            {
                // Fail: Log error on FALSE
                $this->LogDbError($sql, $values);
            }

            // Disconnect if necessary
            if($ProdConnect) $this->Disconnect(true);

            // Performance: End
            $time += microtime(true);
            $timeStr = sprintf('%0.2f', $time);

            // TRACE
            if($this->TRACE && $result !== false)
            {
                $this->QTrace('SELECT Result (Calc: '.$timeStr.')',  print_r($result, true), true);
            }
            
        }

        return $result;
    }

    function Update($sql, $values=null, $prod=false)
    {
        // TRACE
        if($this->TRACE)
        {
            $this->QTrace('UPDATE',         $sql,                   true);
            $this->QTrace('UPDATE Vals',    print_r($values, true), true);
        }

        // Success: TRUE
        // Fail: FALSE
        $result = false;

        // No parameters: Use i5_query
        if(is_null($values))
        {
            $result = $this->Query2($sql, $prod);
        }
        else
        {
            // Select connection
            $connUse = ($prod ? $this->connProd : $this->conn);

            $query = i5_prepare($sql, $connUse);
            if(is_resource($query))
            {
                // Success or Fail
                $result = i5_execute($query, $values);

                // Fail: Log error on FALSE
                if($result === false) $this->LogDbError($sql, $values);
            }
            else
            {
                // Fail: Log error on FALSE
                $this->LogDbError($sql, $values);
            }
        }

        // TRACE
        if($this->TRACE) $this->QTrace('UPDATE Result', ($result ? 'UPDATE OK' : 'UPDATE FAIL!!!'), true);

        return $result;
    }


    function DataArea_Read_ezcom($key)
    {
        return i5_data_area_read($key);
    }


    function DataArea_Write_ezcom($key, $value, $length)
    {
        // should just fail if already exists...
        $CreateOK = i5_data_area_create($key, $length);
        $WriteOK  = i5_data_area_write($key, $value);
        return $WriteOK;
    }

    function LogDbError($sql, $values=null)
    {
        $msg = '';

        // EasyCom page says both bool and array
        $err = i5_error();
        if(is_array($err))
        {
            $msg = "Error ".$err['num']."\nCat ".$err['cat']."\nMsg '".$err['msg']."'\nDesc '".$err['desc']."'\nStack '".$sql."'";
            $trace = debug_backtrace();
            $caller = $trace[1];
            
            $msg .=  "Called by {$caller['function']}";
            
        }

        if(ECHO_DB_ERROR) echo "<h1>LogDbError</h1>".$this->HTMLFormat($msg).(!is_null($values) ? "\n<h2>Values</h2>".print_r($values, true) : "");
        if(LOG_DB_ERROR) $this->Log($msg."\n\n".print_r($values,true));

        return $msg;
    }



}


?>