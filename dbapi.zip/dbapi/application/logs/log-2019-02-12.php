<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-12 09:33:24 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:33:24 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:34:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:34:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:34:06 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:34:06 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:34:07 --> Select (Calc: 0.38)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190211
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190212
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190212 AND A.RADATE < 20190220)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100834
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 4
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 2
            [RADRVUSER] => 6200528438
            [RADATE] => 20190212
        )

)

ERROR - 2019-02-12 09:34:07 --> Select (Calc: 0.08)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100834'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190212' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-12 09:34:08 --> Select (Calc: 0.03)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100834' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100834
            [RHDATE] => 20190212
            [RHTRUC] => 4
            [RHDRIV] => David Karnofel
            [RHHELP] => Shane Brown
            [RHSTOP] => 9
            [RHCUBE] => 705
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 2
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 45369
            [RHHLPEMP] => 71830
            [RHTRNAME] => VAN1
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11950521
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 48
            [RHDRVDIST] => 47733
            [RHPRJDEP] => 800
            [RHPRJARV] => 1558
            [RHPRJMILES] => 127
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-12 09:34:10 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:34:10 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:34:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:34:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:34:17 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:34:17 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:34:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:34:18 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:34:19 --> Select (Calc: 0.01)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190211
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190212
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190212 AND A.RADATE < 20190220)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100834
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 4
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 2
            [RADRVUSER] => 6200528438
            [RADATE] => 20190212
        )

)

ERROR - 2019-02-12 09:34:23 --> Select (Calc: 0.04)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-12 09:34:24 --> Select (Calc: 0.09)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864793
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/502946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:24 --> Select (Calc: 0.03)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888382
)
 R:
ERROR - 2019-02-12 09:34:25 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888404
)
 R:
ERROR - 2019-02-12 09:34:26 --> Select (Calc: 0.05)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623893
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1623893.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:26 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623893
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1623893.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:27 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888358
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/644648.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:28 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888366
)
 R:
ERROR - 2019-02-12 09:34:28 --> Select (Calc: 0.03)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946293
)
 R:
ERROR - 2019-02-12 09:34:29 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946307
)
 R:
ERROR - 2019-02-12 09:34:30 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946315
)
 R:
ERROR - 2019-02-12 09:34:31 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946137
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735835.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:31 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946188
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735812.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946196
)
 R:
ERROR - 2019-02-12 09:34:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946153
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735796.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:33 --> Select (Calc: 0.04)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1859048
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/476502.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:34 --> Select (Calc: 0.05)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1701487
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1701487_SA
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:34:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1858173
)
 R:
ERROR - 2019-02-12 09:34:35 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800655
)
 R:
ERROR - 2019-02-12 09:34:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800663
)
 R:
ERROR - 2019-02-12 09:34:36 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776894
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/426333.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:37 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1868586
)
 R:
ERROR - 2019-02-12 09:34:38 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1869299
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501832.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:38 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782177
)
 R:
ERROR - 2019-02-12 09:34:39 --> Select (Calc: 0.07)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782215
)
 R:
ERROR - 2019-02-12 09:34:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782223
)
 R:
ERROR - 2019-02-12 09:34:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782266
)
 R:
ERROR - 2019-02-12 09:34:41 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 0
)
 R:
ERROR - 2019-02-12 09:34:42 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929119
)
 R:
ERROR - 2019-02-12 09:34:42 --> Select (Calc: 0.03)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867393
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1867393_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:34:43 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:44 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900978
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649804.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:45 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900935
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649815.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905759
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/677111.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905759
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/677111.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:47 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864335
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1864335_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:34:48 --> Select (Calc: 0.04)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1731203
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1654624_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:34:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1731203
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1654624_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:34:49 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905732
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1905732_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:34:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900854
)
 R:
ERROR - 2019-02-12 09:34:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900862
)
 R:
ERROR - 2019-02-12 09:34:51 --> Select (Calc: 0.03)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1931636
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/691102.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:34:52 --> Select (Calc: 0.02)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100834 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 127
            [RHMILES] => 2
            [RHDATE] => 20190212
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-12 09:35:07 --> Select (Calc: 14.39)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=01
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864793
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888382
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888404
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1623893
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1623893
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888358
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888366
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946293
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [8] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946307
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [9] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946315
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [10] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 80
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946137
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [11] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946188
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [12] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946196
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [13] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 100
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946153
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:08 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=02
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1859048
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1701487
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1858173
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:09 --> Select (Calc: 0.06)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=03
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254499
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800655
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254499
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800663
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:09 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=04
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 220936
            [RSINSEQ] => 10
            [RSINSSS] => 3
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776894
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 220936
            [RSINSEQ] => 10
            [RSINSSS] => 3
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776894
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:10 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=05
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => B
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1868586
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1869299
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782177
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782215
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782223
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782266
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:11 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=06
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254598
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929119
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254598
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867393
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:11 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=07
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900978
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900935
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:12 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=08
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1731203
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1731203
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1905759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1905759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864335
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1905732
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:13 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=09
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900854
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900862
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1931636
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:35:14 --> Select (Calc: 0.16)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=01
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:14 --> Select (Calc: 0.01)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=02
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:15 --> Select (Calc: 0.03)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=03
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:16 --> Select (Calc: 0.05)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=04
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:16 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=05
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:17 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=06
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:18 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=07
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:18 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=08
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:19 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=09
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:35:20 --> Select (Calc: 0.11)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254511
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-12 09:35:21 --> Select (Calc: 0.14)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1864793'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700753036-3M' V: R:
ERROR - 2019-02-12 09:35:21 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888382'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '3650-37' V: R:
ERROR - 2019-02-12 09:35:22 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888404'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '3650-38' V: R:
ERROR - 2019-02-12 09:35:23 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1623893'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FS1006-3B' V: R:
ERROR - 2019-02-12 09:35:29 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:35:29 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:35:30 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:35:30 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:35:31 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190211
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190212
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190212 AND A.RADATE < 20190220)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100834
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 4
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 2
            [RADRVUSER] => 6200528438
            [RADATE] => 20190212
        )

)

ERROR - 2019-02-12 09:35:34 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-12 09:35:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864793
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/502946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:35 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888382
)
 R:
ERROR - 2019-02-12 09:35:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888404
)
 R:
ERROR - 2019-02-12 09:35:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623893
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1623893.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623893
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1623893.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888358
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/644648.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:38 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888366
)
 R:
ERROR - 2019-02-12 09:35:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946293
)
 R:
ERROR - 2019-02-12 09:35:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946307
)
 R:
ERROR - 2019-02-12 09:35:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946315
)
 R:
ERROR - 2019-02-12 09:35:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946137
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735835.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:41 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946188
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735812.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:42 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946196
)
 R:
ERROR - 2019-02-12 09:35:42 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946153
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735796.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:43 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1859048
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/476502.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1701487
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1701487_SA
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:35:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1858173
)
 R:
ERROR - 2019-02-12 09:35:45 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800655
)
 R:
ERROR - 2019-02-12 09:35:45 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800663
)
 R:
ERROR - 2019-02-12 09:35:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776894
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/426333.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:47 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1868586
)
 R:
ERROR - 2019-02-12 09:35:47 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1869299
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501832.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782177
)
 R:
ERROR - 2019-02-12 09:35:49 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782215
)
 R:
ERROR - 2019-02-12 09:35:49 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782223
)
 R:
ERROR - 2019-02-12 09:35:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782266
)
 R:
ERROR - 2019-02-12 09:35:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 0
)
 R:
ERROR - 2019-02-12 09:35:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929119
)
 R:
ERROR - 2019-02-12 09:35:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867393
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1867393_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:35:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:56 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:57 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900978
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649804.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:57 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900935
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649815.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:58 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905759
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/677111.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:58 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905759
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/677111.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:35:59 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864335
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1864335_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:36:00 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1731203
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1654624_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:36:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1731203
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1654624_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:36:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905732
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1905732_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:36:02 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900854
)
 R:
ERROR - 2019-02-12 09:36:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900862
)
 R:
ERROR - 2019-02-12 09:36:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1931636
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/691102.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:36:04 --> Select (Calc: 0.01)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100834 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 127
            [RHMILES] => 2
            [RHDATE] => 20190212
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-12 09:36:05 --> Select (Calc: 0.02)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=01
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864793
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888382
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888404
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1623893
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1623893
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888358
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888366
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946293
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [8] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946307
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [9] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946315
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [10] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 80
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946137
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [11] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946188
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [12] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946196
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [13] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 100
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946153
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:06 --> Select (Calc: 0.02)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=02
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1859048
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1701487
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1858173
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:06 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=03
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254499
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800655
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254499
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800663
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:07 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=04
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 220936
            [RSINSEQ] => 10
            [RSINSSS] => 3
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776894
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 220936
            [RSINSEQ] => 10
            [RSINSSS] => 3
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776894
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:08 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=05
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => B
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1868586
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1869299
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782177
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782215
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782223
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782266
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:08 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=06
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254598
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929119
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254598
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867393
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:09 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=07
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900978
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900935
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:10 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=08
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1731203
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1731203
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1905759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1905759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864335
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1905732
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:10 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=09
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900854
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900862
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1931636
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:36:11 --> Select (Calc: 0.01)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=01
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:12 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=02
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:12 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=03
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:13 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=04
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:14 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=05
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:15 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=06
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:15 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=07
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:16 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=08
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:16 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=09
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:36:17 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254511
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-12 09:36:18 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1864793'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700753036-3M' V: R:
ERROR - 2019-02-12 09:36:19 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888382'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '3650-37' V: R:
ERROR - 2019-02-12 09:36:19 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888404'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '3650-38' V: R:
ERROR - 2019-02-12 09:36:20 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1623893'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FS1006-3B' V: R:
ERROR - 2019-02-12 09:36:21 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1623893'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FS1006-3B' V: R:
ERROR - 2019-02-12 09:36:21 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888358'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = '3650-44' V: R:
ERROR - 2019-02-12 09:36:22 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888366'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = '3650-45' V: R:
ERROR - 2019-02-12 09:36:23 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946293'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-751' V: R:
ERROR - 2019-02-12 09:36:23 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946307'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-750' V: R:
ERROR - 2019-02-12 09:36:24 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946315'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-801' V: R:
ERROR - 2019-02-12 09:36:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946137'
								    	and MSSEQ = 080
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-440' V: R:
ERROR - 2019-02-12 09:36:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946188'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-412' V: R:
ERROR - 2019-02-12 09:36:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946196'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-432' V: R:
ERROR - 2019-02-12 09:36:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946153'
								    	and MSSEQ = 100
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-455' V: R:
ERROR - 2019-02-12 09:36:28 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254338
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>        No Instructions Provided
        )

)

ERROR - 2019-02-12 09:36:28 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1859048'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-2198-OR-RO' V: R:
ERROR - 2019-02-12 09:36:29 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1701487'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'HKMFSQ' V: R:
ERROR - 2019-02-12 09:36:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1858173'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'FO-229818-RO' V: R:
ERROR - 2019-02-12 09:36:31 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254499
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-12 09:36:31 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254499
					    				and MTYPE = 'I'
								    	and MSKU  = '1800655'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '236-22-WESEXP-BC' V: R:
ERROR - 2019-02-12 09:36:32 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254499
					    				and MTYPE = 'I'
								    	and MSKU  = '1800663'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '236-42-WESEXP-BC' V: R:
ERROR - 2019-02-12 09:36:33 --> Select (Calc: 0.05)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 220936
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-12 09:36:52 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:36:52 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:36:53 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:36:53 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:36:54 --> Select (Calc: 0.11)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190211
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190212
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190212 AND A.RADATE < 20190220)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100834
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 4
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 2
            [RADRVUSER] => 6200528438
            [RADATE] => 20190212
        )

)

ERROR - 2019-02-12 09:36:57 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-12 09:36:57 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864793
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/502946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:36:58 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888382
)
 R:
ERROR - 2019-02-12 09:36:59 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888404
)
 R:
ERROR - 2019-02-12 09:36:59 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623893
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1623893.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:00 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623893
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1623893.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888358
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/644648.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888366
)
 R:
ERROR - 2019-02-12 09:37:02 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946293
)
 R:
ERROR - 2019-02-12 09:37:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946307
)
 R:
ERROR - 2019-02-12 09:37:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946315
)
 R:
ERROR - 2019-02-12 09:37:04 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946137
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735835.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:05 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946188
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735812.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:05 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946196
)
 R:
ERROR - 2019-02-12 09:37:06 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946153
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735796.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:06 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1859048
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/476502.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:07 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1701487
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1701487_SA
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:37:08 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1858173
)
 R:
ERROR - 2019-02-12 09:37:08 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800655
)
 R:
ERROR - 2019-02-12 09:37:09 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800663
)
 R:
ERROR - 2019-02-12 09:37:10 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776894
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/426333.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:10 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1868586
)
 R:
ERROR - 2019-02-12 09:37:11 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1869299
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501832.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:12 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782177
)
 R:
ERROR - 2019-02-12 09:37:12 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782215
)
 R:
ERROR - 2019-02-12 09:37:13 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782223
)
 R:
ERROR - 2019-02-12 09:37:13 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782266
)
 R:
ERROR - 2019-02-12 09:37:14 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 0
)
 R:
ERROR - 2019-02-12 09:37:15 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929119
)
 R:
ERROR - 2019-02-12 09:37:15 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867393
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1867393_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:37:16 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:17 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:17 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900978
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649804.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:18 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900935
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649815.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:19 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905759
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/677111.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:19 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905759
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/677111.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:20 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864335
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1864335_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:37:21 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1731203
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1654624_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:37:22 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1731203
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1654624_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:37:22 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905732
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1905732_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:37:23 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900854
)
 R:
ERROR - 2019-02-12 09:37:24 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900862
)
 R:
ERROR - 2019-02-12 09:37:24 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1931636
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/691102.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:37:25 --> Select (Calc: 0.03)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100834 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 127
            [RHMILES] => 2
            [RHDATE] => 20190212
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-12 09:37:26 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=01
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864793
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888382
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888404
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1623893
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1623893
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888358
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888366
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946293
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [8] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946307
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [9] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946315
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [10] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 80
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946137
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [11] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946188
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [12] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946196
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [13] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 100
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946153
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:27 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=02
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1859048
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1701487
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1858173
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:27 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=03
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254499
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800655
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254499
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800663
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:28 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=04
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 220936
            [RSINSEQ] => 10
            [RSINSSS] => 3
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776894
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 220936
            [RSINSEQ] => 10
            [RSINSSS] => 3
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776894
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:29 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=05
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => B
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1868586
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1869299
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782177
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782215
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782223
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782266
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:29 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=06
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254598
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929119
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254598
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867393
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:30 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=07
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900978
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900935
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:31 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=08
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1731203
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1731203
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1905759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1905759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864335
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1905732
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:31 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=09
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900854
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900862
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1931636
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:37:32 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=01
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:33 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=02
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:33 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=03
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:34 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=04
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:35 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=05
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:35 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=06
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:36 --> Select (Calc: 0.02)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=07
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:37 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=08
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:37 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=09
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:37:38 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254511
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-12 09:37:39 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1864793'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700753036-3M' V: R:
ERROR - 2019-02-12 09:37:39 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888382'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '3650-37' V: R:
ERROR - 2019-02-12 09:37:40 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888404'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '3650-38' V: R:
ERROR - 2019-02-12 09:37:41 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1623893'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FS1006-3B' V: R:
ERROR - 2019-02-12 09:37:41 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1623893'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FS1006-3B' V: R:
ERROR - 2019-02-12 09:37:42 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888358'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = '3650-44' V: R:
ERROR - 2019-02-12 09:37:42 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888366'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = '3650-45' V: R:
ERROR - 2019-02-12 09:37:43 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946293'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-751' V: R:
ERROR - 2019-02-12 09:37:44 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946307'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-750' V: R:
ERROR - 2019-02-12 09:37:44 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946315'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-801' V: R:
ERROR - 2019-02-12 09:37:45 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946137'
								    	and MSSEQ = 080
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-440' V: R:
ERROR - 2019-02-12 09:37:45 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946188'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-412' V: R:
ERROR - 2019-02-12 09:37:46 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946196'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-432' V: R:
ERROR - 2019-02-12 09:37:47 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946153'
								    	and MSSEQ = 100
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-455' V: R:
ERROR - 2019-02-12 09:37:48 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254338
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>        No Instructions Provided
        )

)

ERROR - 2019-02-12 09:37:48 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1859048'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-2198-OR-RO' V: R:
ERROR - 2019-02-12 09:37:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1701487'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'HKMFSQ' V: R:
ERROR - 2019-02-12 09:37:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1858173'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'FO-229818-RO' V: R:
ERROR - 2019-02-12 09:37:50 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254499
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-12 09:37:51 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254499
					    				and MTYPE = 'I'
								    	and MSKU  = '1800655'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '236-22-WESEXP-BC' V: R:
ERROR - 2019-02-12 09:37:52 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254499
					    				and MTYPE = 'I'
								    	and MSKU  = '1800663'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '236-42-WESEXP-BC' V: R:
ERROR - 2019-02-12 09:37:52 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 220936
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-12 09:37:53 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 220936
					    				and MTYPE = 'D'
								    	and MSKU  = '1776894'
								    	and MSSEQ = 010
								    	and MSBSQ = 03
								    	and MITEM = '700730109-5M' V: R:
ERROR - 2019-02-12 09:37:54 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253719
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => BED PICK UP HAS BEEN PAID AND CUSTOMER WANTS A 30 MINUTE CALL AHE
        )

    [1] => stdClass Object
        (
            [MTEXT] => AD WHEN ON THE WAY
        )

)

ERROR - 2019-02-12 09:37:55 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1868586'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700600212-4B' V: R:
ERROR - 2019-02-12 09:37:55 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1869299'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700753038-4M' V: R:
ERROR - 2019-02-12 09:37:56 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1782177'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '2639-20H' V: R:
ERROR - 2019-02-12 09:38:07 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:38:07 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:38:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:38:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:38:09 --> Select (Calc: 0.09)SELECT COUNT(*) AS MSGCOUNT
                FROM RTSMBLACT
                WHERE RMSTR# = 825
                AND RMROUT = 100834 V: R:Array
(
    [0] => stdClass Object
        (
            [MSGCOUNT] => 0
        )

)

ERROR - 2019-02-12 09:38:10 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:38:10 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:38:11 --> Select (Calc: 0.01)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190211
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190212
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190212 AND A.RADATE < 20190220)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100834
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 4
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 2
            [RADRVUSER] => 6200528438
            [RADATE] => 20190212
        )

)

ERROR - 2019-02-12 09:38:12 --> Select (Calc: 0.02)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100834'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190212' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-12 09:38:13 --> Select (Calc: 0.03)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100834' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100834
            [RHDATE] => 20190212
            [RHTRUC] => 4
            [RHDRIV] => David Karnofel
            [RHHELP] => Shane Brown
            [RHSTOP] => 9
            [RHCUBE] => 705
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 2
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 45369
            [RHHLPEMP] => 71830
            [RHTRNAME] => VAN1
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11950521
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 48
            [RHDRVDIST] => 47733
            [RHPRJDEP] => 800
            [RHPRJARV] => 1558
            [RHPRJMILES] => 127
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-12 09:38:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:38:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:38:27 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:38:27 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:38:28 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:38:28 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:38:29 --> Select (Calc: 0.01)SELECT COUNT(*) AS MSGCOUNT
                FROM RTSMBLACT
                WHERE RMSTR# = 825
                AND RMROUT = 100834 V: R:Array
(
    [0] => stdClass Object
        (
            [MSGCOUNT] => 0
        )

)

ERROR - 2019-02-12 09:38:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:38:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:38:32 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:38:32 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:38:32 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190211
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190212
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190212 AND A.RADATE < 20190220)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100834
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 4
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 2
            [RADRVUSER] => 6200528438
            [RADATE] => 20190212
        )

)

ERROR - 2019-02-12 09:38:36 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-12 09:38:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864793
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/502946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:38 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888382
)
 R:
ERROR - 2019-02-12 09:38:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888404
)
 R:
ERROR - 2019-02-12 09:38:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623893
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1623893.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:41 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623893
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1623893.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:42 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888358
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/644648.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:43 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888366
)
 R:
ERROR - 2019-02-12 09:38:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946293
)
 R:
ERROR - 2019-02-12 09:38:45 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946307
)
 R:
ERROR - 2019-02-12 09:38:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946315
)
 R:
ERROR - 2019-02-12 09:38:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946137
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735835.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:47 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946188
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735812.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946196
)
 R:
ERROR - 2019-02-12 09:38:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1946153
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/735796.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:49 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1859048
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/476502.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1701487
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1701487_SA
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:38:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1858173
)
 R:
ERROR - 2019-02-12 09:38:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800655
)
 R:
ERROR - 2019-02-12 09:38:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800663
)
 R:
ERROR - 2019-02-12 09:38:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776894
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/426333.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:53 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1868586
)
 R:
ERROR - 2019-02-12 09:38:54 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1869299
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501832.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:38:54 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782177
)
 R:
ERROR - 2019-02-12 09:38:55 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782215
)
 R:
ERROR - 2019-02-12 09:38:56 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782223
)
 R:
ERROR - 2019-02-12 09:38:57 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1782266
)
 R:
ERROR - 2019-02-12 09:38:58 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 0
)
 R:
ERROR - 2019-02-12 09:38:59 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929119
)
 R:
ERROR - 2019-02-12 09:38:59 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867393
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1867393_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:39:00 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:39:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:39:02 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900978
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649804.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:39:02 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900935
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649815.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:39:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905759
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/677111.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:39:04 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905759
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/677111.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:39:04 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864335
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1864335_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:39:05 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1731203
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1654624_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:39:06 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1731203
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1654624_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:39:06 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1905732
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1905732_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-12 09:39:07 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900854
)
 R:
ERROR - 2019-02-12 09:39:08 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900862
)
 R:
ERROR - 2019-02-12 09:39:08 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1931636
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/691102.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-12 09:39:09 --> Select (Calc: 0.01)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100834 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 127
            [RHMILES] => 2
            [RHDATE] => 20190212
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-12 09:39:10 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=01
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864793
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888382
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888404
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1623893
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1623893
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888358
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888366
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946293
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [8] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946307
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [9] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946315
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [10] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 80
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946137
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [11] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946188
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [12] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946196
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [13] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254511
            [RSINSEQ] => 100
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1946153
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:11 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=02
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1859048
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1701487
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254338
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1858173
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:11 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=03
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254499
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800655
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254499
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800663
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:12 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=04
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 220936
            [RSINSEQ] => 10
            [RSINSSS] => 3
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776894
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 220936
            [RSINSEQ] => 10
            [RSINSSS] => 3
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776894
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:13 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=05
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => B
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1868586
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1869299
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782177
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782215
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782223
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253719
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1782266
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:13 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=06
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254598
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929119
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254598
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867393
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:14 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=07
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900978
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254608
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900935
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:15 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=08
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1731203
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1731203
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1905759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1905759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864335
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254614
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1905732
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:15 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190212' AND (DMEFFEND = 0 OR DMEFFEND >= '20190212')
                    WHERE RSSTORE=00825
                    AND RSROUT=100834
                    AND RSSTOP=09
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900854
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900862
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254302
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1931636
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-12 09:39:16 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=01
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:17 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=02
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:17 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=03
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:18 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=04
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:19 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=05
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:19 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=06
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:20 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=07
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:21 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=08
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:21 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100834
                    AND RISTOP=09
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-12 09:39:22 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254511
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-12 09:39:23 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1864793'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700753036-3M' V: R:
ERROR - 2019-02-12 09:39:23 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888382'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '3650-37' V: R:
ERROR - 2019-02-12 09:39:24 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888404'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '3650-38' V: R:
ERROR - 2019-02-12 09:39:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1623893'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FS1006-3B' V: R:
ERROR - 2019-02-12 09:39:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1623893'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FS1006-3B' V: R:
ERROR - 2019-02-12 09:39:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888358'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = '3650-44' V: R:
ERROR - 2019-02-12 09:39:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1888366'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = '3650-45' V: R:
ERROR - 2019-02-12 09:39:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946293'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-751' V: R:
ERROR - 2019-02-12 09:39:28 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946307'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-750' V: R:
ERROR - 2019-02-12 09:39:29 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946315'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-801' V: R:
ERROR - 2019-02-12 09:39:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946137'
								    	and MSSEQ = 080
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-440' V: R:
ERROR - 2019-02-12 09:39:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946188'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-412' V: R:
ERROR - 2019-02-12 09:39:31 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946196'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-432' V: R:
ERROR - 2019-02-12 09:39:32 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254511
					    				and MTYPE = 'I'
								    	and MSKU  = '1946153'
								    	and MSSEQ = 100
								    	and MSBSQ = 00
								    	and MITEM = '195-S318-455' V: R:
ERROR - 2019-02-12 09:39:33 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254338
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>        No Instructions Provided
        )

)

ERROR - 2019-02-12 09:39:33 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1859048'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-2198-OR-RO' V: R:
ERROR - 2019-02-12 09:39:34 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1701487'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'HKMFSQ' V: R:
ERROR - 2019-02-12 09:39:35 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254338
					    				and MTYPE = 'I'
								    	and MSKU  = '1858173'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'FO-229818-RO' V: R:
ERROR - 2019-02-12 09:39:36 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254499
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-12 09:39:36 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254499
					    				and MTYPE = 'I'
								    	and MSKU  = '1800655'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '236-22-WESEXP-BC' V: R:
ERROR - 2019-02-12 09:39:37 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254499
					    				and MTYPE = 'I'
								    	and MSKU  = '1800663'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '236-42-WESEXP-BC' V: R:
ERROR - 2019-02-12 09:39:38 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 220936
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-12 09:39:38 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 220936
					    				and MTYPE = 'D'
								    	and MSKU  = '1776894'
								    	and MSSEQ = 010
								    	and MSBSQ = 03
								    	and MITEM = '700730109-5M' V: R:
ERROR - 2019-02-12 09:39:39 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253719
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => BED PICK UP HAS BEEN PAID AND CUSTOMER WANTS A 30 MINUTE CALL AHE
        )

    [1] => stdClass Object
        (
            [MTEXT] => AD WHEN ON THE WAY
        )

)

ERROR - 2019-02-12 09:39:40 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1868586'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700600212-4B' V: R:
ERROR - 2019-02-12 09:39:41 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1869299'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700753038-4M' V: R:
ERROR - 2019-02-12 09:39:41 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1782177'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '2639-20H' V: R:
ERROR - 2019-02-12 09:39:42 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1782215'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '2639-17USR' V: R:
ERROR - 2019-02-12 09:39:42 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1782223'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '2639-19SR' V: R:
ERROR - 2019-02-12 09:39:43 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'I'
								    	and MSKU  = '1782266'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '2639-18USF' V: R:
ERROR - 2019-02-12 09:39:44 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253719
					    				and MTYPE = 'B'
								    	and MSKU  = '0'
								    	and MSSEQ = 000
								    	and MSBSQ = 00
								    	and MITEM = '' V: R:
ERROR - 2019-02-12 09:39:44 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254598
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-12 09:39:45 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254598
					    				and MTYPE = 'I'
								    	and MSKU  = '1929119'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BG-PG' V: R:
ERROR - 2019-02-12 09:39:46 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254598
					    				and MTYPE = 'I'
								    	and MSKU  = '1867393'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'K116HM-L1-1EH-MG' V: R:
ERROR - 2019-02-12 09:39:47 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254608
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-12 09:39:47 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254608
					    				and MTYPE = 'I'
								    	and MSKU  = '1900943'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '6186V90AGXDK-RG' V: R:
ERROR - 2019-02-12 09:39:48 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254608
					    				and MTYPE = 'I'
								    	and MSKU  = '1900943'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '6186V90AGXDK-RG' V: R:
ERROR - 2019-02-12 09:39:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254608
					    				and MTYPE = 'I'
								    	and MSKU  = '1900978'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '6186V10QGXDK-RG' V: R:
ERROR - 2019-02-12 09:39:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254608
					    				and MTYPE = 'I'
								    	and MSKU  = '1900935'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '6186V20AGXDK-RG' V: R:
ERROR - 2019-02-12 09:39:50 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254614
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUSTOMER SAID TO GIVE HER A CALL IF DRIVERS NEED ANY ASSISTANCE F
        )

    [1] => stdClass Object
        (
            [MTEXT] => INDING THE PLACE SAID ITS NEW AND THE SUB DIVISION NAME IS ENCLAV
        )

    [2] => stdClass Object
        (
            [MTEXT] => E OF ADELEE
        )

)

ERROR - 2019-02-12 09:39:51 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254614
					    				and MTYPE = 'I'
								    	and MSKU  = '1905759'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'OO8302-03' V: R:
ERROR - 2019-02-12 09:39:51 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254614
					    				and MTYPE = 'I'
								    	and MSKU  = '1905759'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'OO8302-03' V: R:
ERROR - 2019-02-12 09:39:52 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254614
					    				and MTYPE = 'I'
								    	and MSKU  = '1864335'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'OL1321-ASI' V: R:
ERROR - 2019-02-12 09:39:53 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254614
					    				and MTYPE = 'F'
								    	and MSKU  = '1731203'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'ST90837C' V: R:
ERROR - 2019-02-12 09:39:53 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254614
					    				and MTYPE = 'F'
								    	and MSKU  = '1731203'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'ST90837C' V: R:
ERROR - 2019-02-12 09:39:54 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254614
					    				and MTYPE = 'F'
								    	and MSKU  = '1905732'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'OO8302-43' V: R:
ERROR - 2019-02-12 09:39:55 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254302
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-12 09:39:55 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254302
					    				and MTYPE = 'C'
								    	and MSKU  = '1900854'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '5073E60RLLNV-WB' V: R:
ERROR - 2019-02-12 09:39:56 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254302
					    				and MTYPE = 'C'
								    	and MSKU  = '1900862'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '5073E70LLLNV-WB' V: R:
ERROR - 2019-02-12 09:39:56 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254302
					    				and MTYPE = 'C'
								    	and MSKU  = '1931636'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '5033320BLODN-WDG' V: R:
ERROR - 2019-02-12 09:39:57 --> Select (Calc: 0.05)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => D
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => C
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Complete
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => C
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Complete Service
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => C
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Picked Up
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => F
            [MBLPRBSTS] => 9
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Follow Up
            [MBLWRDREQ] => 5
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => H
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Not At Home
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => H
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Not At Home
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 1
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged Merchandise
            [MBLWRDREQ] => 3
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => N
            [MBLPRBSTS] => 1
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Incomplete Service
            [MBLWRDREQ] => 3
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Not On Truck
            [MBLWRDREQ] => 3
        )

    [12] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => N
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Wrong Parts
            [MBLWRDREQ] => 3
        )

    [13] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 3
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Wrong Merchandise
            [MBLWRDREQ] => 5
        )

    [14] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Too Big
            [MBLWRDREQ] => 5
        )

    [15] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => N
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Did Not Pickup
            [MBLWRDREQ] => 5
        )

    [16] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => D
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Deliver
            [MBLWRDREQ] => 0
        )

    [17] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => P
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Pickup
            [MBLWRDREQ] => 0
        )

    [18] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => X
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Transfer
            [MBLWRDREQ] => 0
        )

    [19] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => S
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Start Service
            [MBLWRDREQ] => 0
        )

    [20] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => W
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wrong Address
            [MBLWRDREQ] => 0
        )

    [21] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => X
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Reschedule Stop
            [MBLWRDREQ] => 4
        )

    [22] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => X
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Reschedule Stop
            [MBLWRDREQ] => 4
        )

)

ERROR - 2019-02-12 09:39:58 --> Select (Calc: 0.03)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-12 09:39:59 --> Select (Calc: 0.09)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:00 --> Select (Calc: 0.06)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:01 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-12 09:40:02 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:03 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-12 09:40:04 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:05 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-12 09:40:05 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:06 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:07 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:08 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:09 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:10 --> Select (Calc: 0.01)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:10 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:11 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-12 09:40:13 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:40:13 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:40:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:40:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 09:41:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:41:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:41:26 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:41:26 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:41:49 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:41:49 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:42:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:42:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:42:40 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:42:40 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:42:48 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:42:48 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:43:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:43:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:43:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:43:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:43:54 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:43:54 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:44:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:44:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:44:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:44:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:44:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:44:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:44:23 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:44:23 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:44:32 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:44:32 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:44:41 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:44:41 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:44:55 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:44:55 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:45:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:45:04 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:45:10 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:45:10 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:45:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:45:18 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:45:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:45:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:45:33 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:45:33 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:46:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:46:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:46:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:46:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:47:20 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:47:20 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:47:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:47:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:50:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:50:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:52:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:52:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:55:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:55:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:58:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:58:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:59:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:59:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:59:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:59:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:59:23 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:59:23 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:59:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:59:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:59:38 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:59:38 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:59:47 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:59:47 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 09:59:53 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 09:59:53 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:00:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:00:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:00:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:00:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:00:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:00:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:00:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:00:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:00:32 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:00:32 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:00:38 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:00:38 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:00:44 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:00:44 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:00:52 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:00:52 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:01:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:01:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:01:07 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:01:07 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:01:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:01:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:01:22 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:01:22 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:08:06 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:08:06 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:08:06 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:08:06 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:08:07 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:08:07 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 10:08:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:08:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:08:09 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:08:09 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:08:09 --> Select (Calc: 0.02)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190211
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190212
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190212 AND A.RADATE < 20190220)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100834
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 4
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 2
            [RADRVUSER] => 6200528438
            [RADATE] => 20190212
        )

)

ERROR - 2019-02-12 10:08:10 --> Select (Calc: 0.02)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100834'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190212' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-12 10:08:11 --> Select (Calc: 0.03)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100834' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100834
            [RHDATE] => 20190212
            [RHTRUC] => 4
            [RHDRIV] => David Karnofel
            [RHHELP] => Shane Brown
            [RHSTOP] => 9
            [RHCUBE] => 705
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 2
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 45369
            [RHHLPEMP] => 71830
            [RHTRNAME] => VAN1
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11950521
            [RHDRVSEQ] => 1
            [RHDRVTIM] => 48
            [RHDRVDIST] => 47733
            [RHPRJDEP] => 800
            [RHPRJARV] => 1524
            [RHPRJMILES] => 127
            [RHACTDEP] => 941
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Completed Stop 01
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-12 10:08:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:08:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 10:57:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:57:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-12 10:57:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:57:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-12 10:57:59 --> Select (Calc: 0.08)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190211
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190212
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190212 AND A.RADATE < 20190220)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100834
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 4
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 2
            [RADRVUSER] => 6200528438
            [RADATE] => 20190212
        )

)

ERROR - 2019-02-12 10:58:00 --> Select (Calc: 0.04)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100834'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190212' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-12 10:58:00 --> Select (Calc: 0.01)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100834' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100834
            [RHDATE] => 20190212
            [RHTRUC] => 4
            [RHDRIV] => David Karnofel
            [RHHELP] => Shane Brown
            [RHSTOP] => 9
            [RHCUBE] => 705
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 2
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 45369
            [RHHLPEMP] => 71830
            [RHTRNAME] => VAN1
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11950521
            [RHDRVSEQ] => 1
            [RHDRVTIM] => 48
            [RHDRVDIST] => 47733
            [RHPRJDEP] => 800
            [RHPRJARV] => 1524
            [RHPRJMILES] => 127
            [RHACTDEP] => 941
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Completed Stop 01
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-12 10:58:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-12 10:58:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

