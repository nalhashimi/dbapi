<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-31 15:39:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:39:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:39:57 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 15:39:57 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 15:40:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:40:14 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 15:40:14 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 15:40:14 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 15:40:14 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 15:40:14 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 15:40:14 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-01-31 15:40:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-31 15:40:16 --> Select (Calc: 0.14)SELECT COUNT(*) AS MSGCOUNT
                FROM RTSMBLACT
                WHERE RMSTR# = 825
                AND RMROUT = 100529 V: R:Array
(
    [0] => stdClass Object
        (
            [MSGCOUNT] => 1113
        )

)

ERROR - 2019-01-31 15:40:17 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:17 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:40:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:18 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-31 15:40:19 --> Select (Calc: 0.38)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190130
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190131 AND A.RADATE < 20190208)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 67
            [RAROUT] => 19990
            [RHCMP] => RR
            [SMMRKT] => MIRGR
            [RHTRUC] => 1
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => RR_67_01
            [RHMILES] => 25200
            [RADRVUSER] => 4084760099
            [RADATE] => 20190131
        )

)

ERROR - 2019-01-31 15:40:20 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:20 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:40:21 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:21 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-31 15:40:22 --> Select (Calc: 0.01)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190130
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190131 AND A.RADATE < 20190208)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 67
            [RAROUT] => 19990
            [RHCMP] => RR
            [SMMRKT] => MIRGR
            [RHTRUC] => 1
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => RR_67_01
            [RHMILES] => 25200
            [RADRVUSER] => 4084760099
            [RADATE] => 20190131
        )

)

ERROR - 2019-01-31 15:40:23 --> Select (Calc: 0.16)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='19990'  OR RASTR# = '67' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190131' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

)

ERROR - 2019-01-31 15:40:24 --> Select (Calc: 0.11)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='67'
                               AND RHROUT='19990' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 67
            [RHROUT] => 19990
            [RHDATE] => 20190131
            [RHTRUC] => 1
            [RHDRIV] => MICHAEL DEVRIES
            [RHHELP] => DYLAN TOLAR
            [RHSTOP] => 7
            [RHCUBE] => 558
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => RR
            [RHMILES] => 25200
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 96241
            [RHHLPEMP] => 96736
            [RHTRNAME] => RR_67_01
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11871601
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 16
            [RHDRVDIST] => 7816
            [RHPRJDEP] => 800
            [RHPRJARV] => 1353
            [RHPRJMILES] => 71
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Grand Rapids
        )

)

ERROR - 2019-01-31 15:40:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 067
)

ERROR - 2019-01-31 15:40:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:40:32 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:32 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:40:33 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:33 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:40:34 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190130
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190131 AND A.RADATE < 20190208)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 67
            [RAROUT] => 19990
            [RHCMP] => RR
            [SMMRKT] => MIRGR
            [RHTRUC] => 1
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => RR_67_01
            [RHMILES] => 25200
            [RADRVUSER] => 4084760099
            [RADATE] => 20190131
        )

)

ERROR - 2019-01-31 15:40:35 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='19990'  OR RASTR# = '67' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190131' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

)

ERROR - 2019-01-31 15:40:36 --> Select (Calc: 0.01)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='67'
                               AND RHROUT='19990' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 67
            [RHROUT] => 19990
            [RHDATE] => 20190131
            [RHTRUC] => 1
            [RHDRIV] => MICHAEL DEVRIES
            [RHHELP] => DYLAN TOLAR
            [RHSTOP] => 7
            [RHCUBE] => 558
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => RR
            [RHMILES] => 25200
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 96241
            [RHHLPEMP] => 96736
            [RHTRNAME] => RR_67_01
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11871601
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 16
            [RHDRVDIST] => 7816
            [RHPRJDEP] => 800
            [RHPRJARV] => 1353
            [RHPRJMILES] => 71
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Grand Rapids
        )

)

ERROR - 2019-01-31 15:40:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 067
)

ERROR - 2019-01-31 15:40:47 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:47 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:40:48 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:48 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:40:49 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:40:49 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 067
)

ERROR - 2019-01-31 15:40:49 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190130
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190131 AND A.RADATE < 20190208)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 67
            [RAROUT] => 19990
            [RHCMP] => RR
            [SMMRKT] => MIRGR
            [RHTRUC] => 1
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => RR_67_01
            [RHMILES] => 25200
            [RADRVUSER] => 4084760099
            [RADATE] => 20190131
        )

)

ERROR - 2019-01-31 15:40:53 --> Select (Calc: 0.03)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=067 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Grand Rapids
            [SADD1] => 4110 28th Street SE
            [SCITY] => Kentwood
            [SSTCD] => MI
            [SZIPCD] => 495120000
            [SMRGL#] => 6162850262
            [SMCOMP] => V
        )

)

ERROR - 2019-01-31 15:40:53 --> Select (Calc: 0.05)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1937839
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/717235.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:40:54 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1937782
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/717229.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:40:55 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1937634
)
 R:
ERROR - 2019-01-31 15:40:55 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1937642
)
 R:
ERROR - 2019-01-31 15:40:56 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1937669
)
 R:
ERROR - 2019-01-31 15:40:57 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1623915
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/368925.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:40:57 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1893777
)
 R:
ERROR - 2019-01-31 15:40:58 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1893785
)
 R:
ERROR - 2019-01-31 15:40:59 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1673998
)
 R:
ERROR - 2019-01-31 15:40:59 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1936654
)
 R:
ERROR - 2019-01-31 15:41:00 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1936832
)
 R:
ERROR - 2019-01-31 15:41:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1936867
)
 R:
ERROR - 2019-01-31 15:41:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1936867
)
 R:
ERROR - 2019-01-31 15:41:02 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1788558
)
 R:
ERROR - 2019-01-31 15:41:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1789732
)
 R:
ERROR - 2019-01-31 15:41:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1789759
)
 R:
ERROR - 2019-01-31 15:41:04 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1789767
)
 R:
ERROR - 2019-01-31 15:41:04 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1789767
)
 R:
ERROR - 2019-01-31 15:41:05 --> Select (Calc: 0.05)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1790072
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/492659.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:41:06 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1790048
)
 R:
ERROR - 2019-01-31 15:41:06 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1790056
)
 R:
ERROR - 2019-01-31 15:41:07 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1864807
)
 R:
ERROR - 2019-01-31 15:41:08 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1865048
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/V_1865005_SA
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-01-31 15:41:08 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1610708
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/379720.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:41:09 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1473425
)
 R:
ERROR - 2019-01-31 15:41:09 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1803972
)
 R:
ERROR - 2019-01-31 15:41:10 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900935
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649815.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:41:11 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900935
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649815.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:41:11 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:41:12 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900943
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649823.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:41:12 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1900978
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/649804.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-01-31 15:41:13 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1649469
)
 R:
ERROR - 2019-01-31 15:41:14 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1649477
)
 R:
ERROR - 2019-01-31 15:41:14 --> Select (Calc: 0.08)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00067 AND RAROUT=019990 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 71
            [RHMILES] => 25200
            [RHDATE] => 20190131
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-01-31 15:41:15 --> Select (Calc: 0.12)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190131' AND (DMEFFEND = 0 OR DMEFFEND >= '20190131')
                    WHERE RSSTORE=00067
                    AND RSROUT=019990
                    AND RSSTOP=01
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 456883
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1937839
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 456883
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1937782
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 456883
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1937634
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 456883
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1937642
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 456883
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1937669
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 456883
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1623915
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-01-31 15:41:16 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190131' AND (DMEFFEND = 0 OR DMEFFEND >= '20190131')
                    WHERE RSSTORE=00067
                    AND RSROUT=019990
                    AND RSSTOP=02
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459264
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1893777
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459264
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1893785
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459264
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1673998
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-01-31 15:41:16 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190131' AND (DMEFFEND = 0 OR DMEFFEND >= '20190131')
                    WHERE RSSTORE=00067
                    AND RSROUT=019990
                    AND RSSTOP=03
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459219
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1936654
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459219
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1936832
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459219
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1936867
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459219
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1936867
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-01-31 15:41:17 --> Select (Calc: 0.03)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190131' AND (DMEFFEND = 0 OR DMEFFEND >= '20190131')
                    WHERE RSSTORE=00067
                    AND RSROUT=019990
                    AND RSSTOP=04
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459267
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1788558
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459267
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1789732
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459267
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1789759
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459267
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1789767
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459267
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1789767
            [RSPRCTP] => I
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459267
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1790048
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459267
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1790056
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459267
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1790072
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-01-31 15:41:18 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190131' AND (DMEFFEND = 0 OR DMEFFEND >= '20190131')
                    WHERE RSSTORE=00067
                    AND RSROUT=019990
                    AND RSSTOP=05
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459301
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1864807
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459301
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1865048
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459301
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1610708
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459301
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1473425
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 459301
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1803972
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-01-31 15:41:18 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190131' AND (DMEFFEND = 0 OR DMEFFEND >= '20190131')
                    WHERE RSSTORE=00067
                    AND RSROUT=019990
                    AND RSSTOP=06
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 458796
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900935
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 458796
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900935
            [RSPRCTP] => I
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 458796
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 458796
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900943
            [RSPRCTP] => I
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 458796
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1900978
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-01-31 15:41:19 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190131' AND (DMEFFEND = 0 OR DMEFFEND >= '20190131')
                    WHERE RSSTORE=00067
                    AND RSROUT=019990
                    AND RSSTOP=07
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 457056
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1649469
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 67
            [RSINVNO] => 457056
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1649477
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-01-31 15:41:20 --> Select (Calc: 0.15)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00067
                    AND RIROUT=019990
                    AND RISTOP=01
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-01-31 15:41:20 --> Select (Calc: 0.02)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00067
                    AND RIROUT=019990
                    AND RISTOP=02
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-01-31 15:41:21 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00067
                    AND RIROUT=019990
                    AND RISTOP=03
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-01-31 15:41:21 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00067
                    AND RIROUT=019990
                    AND RISTOP=04
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-01-31 15:41:22 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00067
                    AND RIROUT=019990
                    AND RISTOP=05
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-01-31 15:41:23 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00067
                    AND RIROUT=019990
                    AND RISTOP=06
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-01-31 15:41:23 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00067
                    AND RIROUT=019990
                    AND RISTOP=07
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-01-31 15:41:24 --> Select (Calc: 0.08)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00067
                                    and MINV# = 456883
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => LONG CIRCLE DRIVEWAY CALL WHEN YOU ARE ON YOUR WAY
        )

)

ERROR - 2019-01-31 15:41:25 --> Select (Calc: 0.06)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 456883
					    				and MTYPE = 'I'
								    	and MSKU  = '1937839'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'B00191-GC' V: R:
ERROR - 2019-01-31 15:41:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 456883
					    				and MTYPE = 'I'
								    	and MSKU  = '1937782'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'B00191-N' V: R:
ERROR - 2019-01-31 15:41:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 456883
					    				and MTYPE = 'I'
								    	and MSKU  = '1937634'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = 'B00191-5H' V: R:
ERROR - 2019-01-31 15:41:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 456883
					    				and MTYPE = 'I'
								    	and MSKU  = '1937642'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = 'B00191-5SF' V: R:
ERROR - 2019-01-31 15:41:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 456883
					    				and MTYPE = 'I'
								    	and MSKU  = '1937669'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = 'B00191-56SR' V: R:
ERROR - 2019-01-31 15:41:28 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 456883
					    				and MTYPE = 'I'
								    	and MSKU  = '1623915'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = 'FS1006-5B' V: R:
ERROR - 2019-01-31 15:41:28 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00067
                                    and MINV# = 459264
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-01-31 15:41:29 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459264
					    				and MTYPE = 'I'
								    	and MSKU  = '1893777'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1500-32-BG' V: R:
ERROR - 2019-01-31 15:41:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459264
					    				and MTYPE = 'I'
								    	and MSKU  = '1893785'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1500-42-BG' V: R:
ERROR - 2019-01-31 15:41:31 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459264
					    				and MTYPE = 'I'
								    	and MSKU  = '1673998'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '26362' V: R:
ERROR - 2019-01-31 15:41:31 --> Select (Calc: 0.03)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00067
                                    and MINV# = 459219
                                    and MTYPE = 'D' V: R:
ERROR - 2019-01-31 15:41:32 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459219
					    				and MTYPE = 'I'
								    	and MSKU  = '1936654'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX2023-05-FC-CC' V: R:
ERROR - 2019-01-31 15:41:33 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459219
					    				and MTYPE = 'I'
								    	and MSKU  = '1936832'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX2023-04-FC-CC' V: R:
ERROR - 2019-01-31 15:41:33 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459219
					    				and MTYPE = 'I'
								    	and MSKU  = '1936867'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX2023-21-FC-CC' V: R:
ERROR - 2019-01-31 15:41:34 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459219
					    				and MTYPE = 'I'
								    	and MSKU  = '1936867'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'PX2023-21-FC-CC' V: R:
ERROR - 2019-01-31 15:41:35 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00067
                                    and MINV# = 459267
                                    and MTYPE = 'D' V: R:
ERROR - 2019-01-31 15:41:35 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459267
					    				and MTYPE = 'I'
								    	and MSKU  = '1788558'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'EM970KHB' V: R:
ERROR - 2019-01-31 15:41:36 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459267
					    				and MTYPE = 'I'
								    	and MSKU  = '1789732'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'EM970KFB' V: R:
ERROR - 2019-01-31 15:41:36 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459267
					    				and MTYPE = 'I'
								    	and MSKU  = '1789759'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'EM970KR' V: R:
ERROR - 2019-01-31 15:41:37 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459267
					    				and MTYPE = 'I'
								    	and MSKU  = '1789767'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'EM970KDB' V: R:
ERROR - 2019-01-31 15:41:38 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459267
					    				and MTYPE = 'I'
								    	and MSKU  = '1789767'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'EM970KDB' V: R:
ERROR - 2019-01-31 15:41:38 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459267
					    				and MTYPE = 'I'
								    	and MSKU  = '1790072'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'EM900NS' V: R:
ERROR - 2019-01-31 15:41:39 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459267
					    				and MTYPE = 'F'
								    	and MSKU  = '1790048'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'EM900DR' V: R:
ERROR - 2019-01-31 15:41:40 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459267
					    				and MTYPE = 'F'
								    	and MSKU  = '1790056'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'EM900MR' V: R:
ERROR - 2019-01-31 15:41:40 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00067
                                    and MINV# = 459301
                                    and MTYPE = 'D' V: R:
ERROR - 2019-01-31 15:41:41 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459301
					    				and MTYPE = 'I'
								    	and MSKU  = '1864807'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700600254-5B' V: R:
ERROR - 2019-01-31 15:41:41 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459301
					    				and MTYPE = 'I'
								    	and MSKU  = '1865048'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '700753045-5M' V: R:
ERROR - 2019-01-31 15:41:42 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459301
					    				and MTYPE = 'I'
								    	and MSKU  = '1610708'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'BGM03AWFQ' V: R:
ERROR - 2019-01-31 15:41:43 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459301
					    				and MTYPE = 'I'
								    	and MSKU  = '1473425'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'LY320-153QHF' V: R:
ERROR - 2019-01-31 15:41:43 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 459301
					    				and MTYPE = 'I'
								    	and MSKU  = '1803972'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'LY320-253QKR' V: R:
ERROR - 2019-01-31 15:41:44 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00067
                                    and MINV# = 458796
                                    and MTYPE = 'D' V: R:
ERROR - 2019-01-31 15:41:45 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 458796
					    				and MTYPE = 'I'
								    	and MSKU  = '1900935'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '6186V20AGXDK-RG' V: R:
ERROR - 2019-01-31 15:41:45 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 458796
					    				and MTYPE = 'I'
								    	and MSKU  = '1900935'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '6186V20AGXDK-RG' V: R:
ERROR - 2019-01-31 15:41:46 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 458796
					    				and MTYPE = 'I'
								    	and MSKU  = '1900943'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '6186V90AGXDK-RG' V: R:
ERROR - 2019-01-31 15:41:47 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 458796
					    				and MTYPE = 'I'
								    	and MSKU  = '1900943'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '6186V90AGXDK-RG' V: R:
ERROR - 2019-01-31 15:41:47 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 458796
					    				and MTYPE = 'I'
								    	and MSKU  = '1900978'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '6186V10QGXDK-RG' V: R:
ERROR - 2019-01-31 15:41:48 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00067
                                    and MINV# = 457056
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-01-31 15:41:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 457056
					    				and MTYPE = 'I'
								    	and MSKU  = '1649469'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'D00280SB' V: R:
ERROR - 2019-01-31 15:41:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00067
					    				and MINV# = 457056
					    				and MTYPE = 'I'
								    	and MSKU  = '1649477'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'D00280SBT' V: R:
ERROR - 2019-01-31 15:41:50 --> Select (Calc: 0.01)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => D
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => C
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Complete
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => C
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Complete Service
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => C
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Picked Up
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => F
            [MBLPRBSTS] => 9
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Follow Up
            [MBLWRDREQ] => 5
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => H
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Not At Home
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => H
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Not At Home
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 1
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged Merchandise
            [MBLWRDREQ] => 3
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => N
            [MBLPRBSTS] => 1
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Incomplete Service
            [MBLWRDREQ] => 3
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Not On Truck
            [MBLWRDREQ] => 3
        )

    [12] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => N
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Wrong Parts
            [MBLWRDREQ] => 3
        )

    [13] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 3
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Wrong Merchandise
            [MBLWRDREQ] => 5
        )

    [14] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Too Big
            [MBLWRDREQ] => 5
        )

    [15] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => N
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Did Not Pickup
            [MBLWRDREQ] => 5
        )

    [16] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => D
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Deliver
            [MBLWRDREQ] => 0
        )

    [17] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => P
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Pickup
            [MBLWRDREQ] => 0
        )

    [18] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => X
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Transfer
            [MBLWRDREQ] => 0
        )

    [19] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => S
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Start Service
            [MBLWRDREQ] => 0
        )

    [20] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => W
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wrong Address
            [MBLWRDREQ] => 0
        )

    [21] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => X
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Reschedule Stop
            [MBLWRDREQ] => 4
        )

    [22] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => X
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Reschedule Stop
            [MBLWRDREQ] => 4
        )

)

ERROR - 2019-01-31 15:41:51 --> Select (Calc: 0.04)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-01-31 15:41:52 --> Select (Calc: 0.04)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:41:53 --> Select (Calc: 0.02)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:41:54 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-01-31 15:41:54 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:41:55 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-01-31 15:41:56 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:41:57 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-01-31 15:41:58 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:41:58 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:41:59 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:42:00 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:42:01 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:42:02 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:42:02 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:42:03 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-01-31 15:42:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:42:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:42:06 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:42:06 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 067
)

ERROR - 2019-01-31 15:42:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:42:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:42:56 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:42:56 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:43:29 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:43:29 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:43:51 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:43:51 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:44:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:44:04 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:44:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:44:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:47:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:47:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:50:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:50:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:51:59 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:51:59 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:52:23 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:52:23 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:55:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:55:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 15:58:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 15:58:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:01:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:01:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:04:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:04:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:07:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:07:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:10:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:10:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:13:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:13:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:16:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:16:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:19:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:19:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:19:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 16:19:00 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-31 16:22:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:22:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:25:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:25:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:28:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:28:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:31:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:31:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:34:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:34:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:37:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:37:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:40:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:40:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:43:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:43:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:46:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:46:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:49:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:49:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:52:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:52:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-31 16:55:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-31 16:55:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

