ERROR - 2019-01-22 16:15:51 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:15:53 --> Severity: Warning --> i5_prepare() expects parameter 2 to be resource, boolean given /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 287
ERROR - 2019-01-22 16:15:53 --> Severity: Warning --> No default connection found. /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 287
ERROR - 2019-01-22 16:15:53 --> Select (Calc: 0.00)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:15:53 --> Query2 Result (Calc: 0.34) :
ERROR - 2019-01-22 16:28:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:28:19 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 417
ERROR - 2019-01-22 16:31:27 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:31:28 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 417
ERROR - 2019-01-22 16:32:36 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:32:37 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 418
ERROR - 2019-01-22 16:35:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:35:32 --> Severity: Notice --> Undefined variable: connectOptions /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 50
ERROR - 2019-01-22 16:35:32 --> Severity: Notice --> Undefined variable: connectOptions /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 51
ERROR - 2019-01-22 16:35:32 --> Severity: Notice --> Undefined variable: connectOptions /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 62
ERROR - 2019-01-22 16:35:33 --> CONNECTED: Resource id #22
ERROR - 2019-01-22 16:35:33 --> CONNECTED: Resource id #22
ERROR - 2019-01-22 16:35:33 --> Select (Calc: 0.03)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:35:33 --> Query2 Result (Calc: 0.16) :
ERROR - 2019-01-22 16:35:33 --> Severity: Notice --> Use of undefined constant PersistentConn - assumed 'PersistentConn' /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 173
ERROR - 2019-01-22 16:37:23 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:37:24 --> Severity: Notice --> Undefined variable: connectOptions /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 50
ERROR - 2019-01-22 16:37:24 --> Severity: Notice --> Undefined variable: connectOptions /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 51
ERROR - 2019-01-22 16:37:24 --> Severity: Notice --> Undefined variable: connectOptions /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 64
ERROR - 2019-01-22 16:37:24 --> CONNECTED: Resource id #22
ERROR - 2019-01-22 16:37:24 --> CONNECTED: Resource id #22
ERROR - 2019-01-22 16:37:24 --> Select (Calc: 0.04)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:37:24 --> Query2 Result (Calc: 0.11) :
ERROR - 2019-01-22 16:38:03 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:38:04 --> CONNECTED: 
ERROR - 2019-01-22 16:38:04 --> CONNECTED: 
ERROR - 2019-01-22 16:38:04 --> Severity: Warning --> i5_prepare() expects parameter 2 to be resource, boolean given /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 290
ERROR - 2019-01-22 16:38:04 --> Severity: Warning --> No default connection found. /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 290
ERROR - 2019-01-22 16:38:04 --> Select (Calc: 0.00)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:38:04 --> Query2 Result (Calc: 0.33) :
ERROR - 2019-01-22 16:39:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:39:05 --> CONNECTED: Array
(
    [iat] => 1548193144
    [chk] => 1840115750
    [username] => DCPORTAL
    [password] => DCPORTAL
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [conntype] => ezc
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pcontimeout] => 1
    [store] => 000
)

ERROR - 2019-01-22 16:39:05 --> CONNECTED: 
ERROR - 2019-01-22 16:39:05 --> Severity: Warning --> i5_prepare() expects parameter 2 to be resource, boolean given /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 290
ERROR - 2019-01-22 16:39:05 --> Severity: Warning --> No default connection found. /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 290
ERROR - 2019-01-22 16:39:05 --> Select (Calc: 0.00)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:39:05 --> Query2 Result (Calc: 0.34) :
ERROR - 2019-01-22 16:42:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:42:46 --> CONNECTED: Array
(
    [iat] => 1548193365
    [chk] => 535329417
    [username] => DCPORTAL
    [password] => DCPORTAL
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [conntype] => ezc
    [servername] => DEVELOP
    [persistent] => n
    [dbjob] => DCMOBILE
    [pcontimeout] => 1
    [store] => 000
)

ERROR - 2019-01-22 16:42:46 --> CONNECTED: 
ERROR - 2019-01-22 16:42:46 --> Severity: Warning --> i5_prepare() expects parameter 2 to be resource, boolean given /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 290
ERROR - 2019-01-22 16:42:46 --> Severity: Warning --> No default connection found. /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_I5_model.php 290
ERROR - 2019-01-22 16:42:46 --> Select (Calc: 0.00)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:42:46 --> Query2 Result (Calc: 0.34) :
ERROR - 2019-01-22 16:45:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:45:32 --> CONNECTED: Array
(
    [iat] => 1548193531
    [chk] => 649745545
    [username] => DCPORTAL
    [password] => DCPORTAL
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [conntype] => ezc
    [servername] => DEVELOP
    [persistent] => n
    [dbjob] => DCMOBILE
    [pcontimeout] => 1
    [store] => 000
)

ERROR - 2019-01-22 16:45:32 --> CONNECTED: Resource id #19
ERROR - 2019-01-22 16:45:32 --> Select (Calc: 0.03)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:45:32 --> Query2 Result (Calc: 0.14) :
ERROR - 2019-01-22 16:45:33 --> CONNECTED: Array
(
    [iat] => 1548193531
    [chk] => 649745545
    [username] => DCPORTAL
    [password] => DCPORTAL
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [conntype] => ezc
    [servername] => DEVELOP
    [persistent] => n
    [dbjob] => DCMOBILE
    [pcontimeout] => 1
    [store] => 000
)

ERROR - 2019-01-22 16:45:33 --> CONNECTED: Resource id #18
ERROR - 2019-01-22 16:45:33 --> Select (Calc: 0.03)SELECT S.STRNBR,S.SNAME,S.SMACUN
            FROM VALUECITY/STRMST S
            WHERE S.SMCLDT=0
            AND S.SMLOC#=1
            AND S.SMCOMP IN ('A','V')
            ORDER BY S.STRNBR V:
ERROR - 2019-01-22 16:45:33 --> Query2 Result (Calc: 0.09) :
ERROR - 2019-01-22 16:46:40 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:46:41 --> CONNECTED: Array
(
    [iat] => 1548193600
    [chk] => 274136673
    [username] => DCPORTAL
    [password] => DCPORTAL
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [conntype] => ezc
    [servername] => DEVELOP
    [persistent] => n
    [dbjob] => DCMOBILE
    [pcontimeout] => 1
    [store] => 000
)

ERROR - 2019-01-22 16:46:41 --> CONNECTED: Resource id #18
ERROR - 2019-01-22 16:46:41 --> Select (Calc: 0.04)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:46:41 --> Query2 Result (Calc: 0.12) :
ERROR - 2019-01-22 16:46:42 --> CONNECTED: Array
(
    [iat] => 1548193600
    [chk] => 274136673
    [username] => DCPORTAL
    [password] => DCPORTAL
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [conntype] => ezc
    [servername] => DEVELOP
    [persistent] => n
    [dbjob] => DCMOBILE
    [pcontimeout] => 1
    [store] => 000
)

ERROR - 2019-01-22 16:46:42 --> CONNECTED: Resource id #18
ERROR - 2019-01-22 16:46:42 --> Select (Calc: 0.02)SELECT S.STRNBR,S.SNAME,S.SMACUN
            FROM VALUECITY/STRMST S
            WHERE S.SMCLDT=0
            AND S.SMLOC#=1
            AND S.SMCOMP IN ('A','V')
            ORDER BY S.STRNBR V:
ERROR - 2019-01-22 16:46:42 --> Query2 Result (Calc: 0.05) :
ERROR - 2019-01-22 16:48:44 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-22 16:48:45 --> CONNECTED: Array
(
    [iat] => 1548193724
    [chk] => 645470368
    [username] => DCPORTAL
    [password] => DCPORTAL
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [conntype] => ezc
    [servername] => DEVELOP
    [persistent] => n
    [dbjob] => DCMOBILE
    [pcontimeout] => 1
    [store] => 000
)

ERROR - 2019-01-22 16:48:45 --> CONNECTED: Resource id #18
ERROR - 2019-01-22 16:48:45 --> Select (Calc: 0.04)SELECT * FROM WEBUSRPRF JOIN WEBUSRACS ON (UPPROFILE = USPROFILE AND USACCESSID = 'DrvCentral') WHERE UPPROFILE = ? ORDER BY UPPROFILE DESC FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => NALHASH
)

ERROR - 2019-01-22 16:48:45 --> Query2 Result (Calc: 0.11) :
ERROR - 2019-01-22 16:48:46 --> CONNECTED: Array
(
    [iat] => 1548193724
    [chk] => 645470368
    [username] => DCPORTAL
    [password] => DCPORTAL
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [conntype] => ezc
    [servername] => DEVELOP
    [persistent] => n
    [dbjob] => DCMOBILE
    [pcontimeout] => 1
    [store] => 000
)

ERROR - 2019-01-22 16:48:46 --> CONNECTED: Resource id #18
ERROR - 2019-01-22 16:48:46 --> Select (Calc: 0.03)SELECT S.STRNBR,S.SNAME,S.SMACUN
            FROM VALUECITY/STRMST S
            WHERE S.SMCLDT=0
            AND S.SMLOC#=1
            AND S.SMCOMP IN ('A','V')
            ORDER BY S.STRNBR V:
ERROR - 2019-01-22 16:48:46 --> Query2 Result (Calc: 0.07) :
