ERROR - 2019-01-28 11:48:39 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:48:39 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:55:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:55:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:57:09 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:57:09 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:57:39 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:57:39 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:57:41 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:57:41 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:57:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:57:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:58:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:58:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:58:19 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:58:19 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:58:26 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:58:26 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:58:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:58:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:58:38 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:58:38 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:58:44 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:58:44 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-28 11:58:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-28 11:58:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

