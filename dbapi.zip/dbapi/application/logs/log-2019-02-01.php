<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-01 09:20:49 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 09:20:49 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 09:20:49 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:20:49 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:23:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 09:23:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 09:23:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:23:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:23:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:23:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:23:00 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:23:00 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-02-01 09:26:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 09:26:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 09:29:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 09:29:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 09:32:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 09:32:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 09:32:01 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:32:01 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:35:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 09:35:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 09:35:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:35:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:35:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:35:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:35:00 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 09:35:00 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-02-01 09:38:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 09:38:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 09:41:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 09:41:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:07:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:07:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:07:45 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:07:45 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:07:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:07:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:07:57 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:07:57 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:07:57 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:07:57 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:07:57 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:07:57 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-02-01 14:08:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:13 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:13 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 067
)

ERROR - 2019-02-01 14:08:14 --> Select (Calc: 0.07)SELECT COUNT(*) AS MSGCOUNT
                FROM RTSMBLACT
                WHERE RMSTR# = 67
                AND RMROUT = 19990 V: R:Array
(
    [0] => stdClass Object
        (
            [MSGCOUNT] => 811
        )

)

ERROR - 2019-02-01 14:08:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 067
)

ERROR - 2019-02-01 14:08:17 --> Select (Calc: 0.05)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:08:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:18 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:18 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 067
)

ERROR - 2019-02-01 14:08:19 --> Select (Calc: 0.01)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:08:20 --> Select (Calc: 0.03)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100574'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 14:08:21 --> Select (Calc: 0.04)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100574' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100574
            [RHDATE] => 20190201
            [RHTRUC] => 50
            [RHDRIV] => Eric Snell
            [RHHELP] => Eric Snell
            [RHSTOP] => 6
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => B
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 60942
            [RHHLPEMP] => 60942
            [RHTRNAME] => 
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready to Load: 8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 14:08:22 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:22 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:08:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:26 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:26 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:26 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:26 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:27 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:08:28 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100574'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 14:08:28 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100574' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100574
            [RHDATE] => 20190201
            [RHTRUC] => 50
            [RHDRIV] => Eric Snell
            [RHHELP] => Eric Snell
            [RHSTOP] => 6
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => B
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 60942
            [RHHLPEMP] => 60942
            [RHTRNAME] => 
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready to Load: 8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 14:08:30 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:30 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:08:30 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:08:30 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:08:30 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:08:30 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:08:30 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-01 14:08:30 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-02-01 14:08:33 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:33 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:34 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:34 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:08:34 --> Select (Calc: 0.07)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:08:35 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100574'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 14:08:36 --> Select (Calc: 0.01)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100574' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100574
            [RHDATE] => 20190201
            [RHTRUC] => 50
            [RHDRIV] => Eric Snell
            [RHHELP] => Eric Snell
            [RHSTOP] => 6
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => B
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 60942
            [RHHLPEMP] => 60942
            [RHTRNAME] => 
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready to Load: 8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 14:08:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:08:39 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:39 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:40 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:40 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:08:41 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:08:41 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:08:41 --> Select (Calc: 0.01)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:08:43 --> Select (Calc: 0.01)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 14:08:44 --> Select (Calc: 0.03)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929089
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1929089_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:08:45 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1592548
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1592548_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:08:45 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912976
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643263.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 14:08:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1485857
)
 R:
ERROR - 2019-02-01 14:08:46 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1727184
)
 R:
ERROR - 2019-02-01 14:08:47 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808915
)
 R:
ERROR - 2019-02-01 14:08:48 --> Select (Calc: 0.04)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100574 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 14:08:49 --> Select (Calc: 0.03)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 249677
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929089
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:08:49 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237343
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1592548
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:08:50 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237193
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912976
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:08:50 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 227231
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1485857
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:08:51 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 105
            [RSINVNO] => 277442
            [RSINSEQ] => 50
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1727184
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:08:52 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 164
            [RSINVNO] => 19003
            [RSINSEQ] => 10
            [RSINSSS] => 2
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808915
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:08:52 --> Select (Calc: 0.06)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:08:53 --> Select (Calc: 0.03)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:08:54 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:08:54 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:08:55 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:08:55 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:08:56 --> Select (Calc: 0.04)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 249677
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:08:57 --> Select (Calc: 0.03)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 249677
					    				and MTYPE = 'S'
								    	and MSKU  = '1929089'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BL-PB' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => COMPARTMENT LID ON LAF ISNT SECURED PROPERLY
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/2/19 QC IN RECLINER FOR RSF ARM TOP AND HINGES. INCOMPLETE. ES8
        )

    [2] => stdClass Object
        (
            [MTEXT] => 25.
        )

    [3] => stdClass Object
        (
            [MTEXT] => QC IN RCLNR FOR
        )

    [4] => stdClass Object
        (
            [MTEXT] => ARM TOP AND HINGES
        )

)

ERROR - 2019-02-01 14:08:58 --> Select (Calc: 0.02)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237343
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:08:58 --> Select (Calc: 0.03)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237343
					    				and MTYPE = 'S'
								    	and MSKU  = '1592548'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'XW9387-L1-1E-DW' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                     PROBLEM WITH FABRIC
        )

)

ERROR - 2019-02-01 14:08:59 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237193
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:09:00 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237193
					    				and MTYPE = 'S'
								    	and MSKU  = '1912976'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '820482-6M' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST REPORTING THAT BED HAS "BROKEN DAMAGE", RIPPLES IN THE
        )

    [1] => stdClass Object
        (
            [MTEXT] => MATT.
        )

)

ERROR - 2019-02-01 14:09:01 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 227231
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 961 ATLANTIC AVE, APT 626 COLUMBUS, OH 43229
        )

)

ERROR - 2019-02-01 14:09:02 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 227231
					    				and MTYPE = 'S'
								    	and MSKU  = '1485857'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VC185-53QFS' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST STATES FOOTBOARD HAS DENTS IN IT.
        )

)

ERROR - 2019-02-01 14:09:03 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 277442
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:09:03 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 277442
					    				and MTYPE = 'S'
								    	and MSKU  = '1727184'
								    	and MSSEQ = 050
								    	and MSBSQ = 01
								    	and MITEM = 'WYB-809-4-MB' V: R:
ERROR - 2019-02-01 14:09:04 --> Select (Calc: 0.04)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 19003
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => X
        )

)

ERROR - 2019-02-01 14:09:05 --> Select (Calc: 0.02)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 19003
					    				and MTYPE = 'S'
								    	and MSKU  = '1808915'
								    	and MSSEQ = 010
								    	and MSBSQ = 02
								    	and MITEM = '8633-67-CCH' V: R:
ERROR - 2019-02-01 14:09:05 --> Select (Calc: 0.01)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:
ERROR - 2019-02-01 14:09:06 --> Select (Calc: 0.02)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:09:07 --> Select (Calc: 0.06)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN1
            [CTCURMILES] => 2
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [8] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 14:09:08 --> Select (Calc: 0.05)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 14:09:09 --> Select (Calc: 0.08)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:10 --> Select (Calc: 0.02)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:11 --> Select (Calc: 0.01)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:09:12 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:13 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 14:09:14 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:15 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 14:09:16 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:17 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:17 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:18 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:19 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:20 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:21 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:22 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:09:23 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:23 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:23 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:23 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:24 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:24 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:09:30 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:30 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:35 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:35 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:40 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:40 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:42 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:42 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:46 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:46 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:48 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:48 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:54 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:54 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:55 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:55 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:09:59 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:09:59 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:09 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:09 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:10:11 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:11 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:13 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:13 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:15 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:10:16 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100574'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 14:10:17 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100574' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100574
            [RHDATE] => 20190201
            [RHTRUC] => 50
            [RHDRIV] => Eric Snell
            [RHHELP] => Eric Snell
            [RHSTOP] => 6
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => C
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 60942
            [RHHLPEMP] => 60942
            [RHTRNAME] => VAN1
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Stop 01 load aborted
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 14:10:17 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:17 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:10:46 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:46 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:47 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:47 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:10:48 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:10:48 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:10:48 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:10:50 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 14:10:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929089
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1929089_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:10:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1592548
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1592548_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:10:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912976
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643263.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 14:10:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1485857
)
 R:
ERROR - 2019-02-01 14:10:53 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1727184
)
 R:
ERROR - 2019-02-01 14:10:54 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808915
)
 R:
ERROR - 2019-02-01 14:10:55 --> Select (Calc: 0.01)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100574 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 14:10:55 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 141000
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 249677
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929089
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:10:56 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140957
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237343
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1592548
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:10:56 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140954
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237193
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912976
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:10:57 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140949
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 227231
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1485857
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:10:58 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140946
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 105
            [RSINVNO] => 277442
            [RSINSEQ] => 50
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1727184
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:10:58 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140940
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 164
            [RSINVNO] => 19003
            [RSINSEQ] => 10
            [RSINSSS] => 2
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808915
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:10:59 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:10:59 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:11:00 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:11:01 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:11:01 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:11:02 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:11:03 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 249677
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:11:03 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 249677
					    				and MTYPE = 'S'
								    	and MSKU  = '1929089'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BL-PB' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => COMPARTMENT LID ON LAF ISNT SECURED PROPERLY
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/2/19 QC IN RECLINER FOR RSF ARM TOP AND HINGES. INCOMPLETE. ES8
        )

    [2] => stdClass Object
        (
            [MTEXT] => 25.
        )

    [3] => stdClass Object
        (
            [MTEXT] => QC IN RCLNR FOR
        )

    [4] => stdClass Object
        (
            [MTEXT] => ARM TOP AND HINGES
        )

)

ERROR - 2019-02-01 14:11:04 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237343
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:11:05 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237343
					    				and MTYPE = 'S'
								    	and MSKU  = '1592548'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'XW9387-L1-1E-DW' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                     PROBLEM WITH FABRIC
        )

)

ERROR - 2019-02-01 14:11:05 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237193
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:11:06 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237193
					    				and MTYPE = 'S'
								    	and MSKU  = '1912976'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '820482-6M' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST REPORTING THAT BED HAS "BROKEN DAMAGE", RIPPLES IN THE
        )

    [1] => stdClass Object
        (
            [MTEXT] => MATT.
        )

)

ERROR - 2019-02-01 14:11:07 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 227231
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 961 ATLANTIC AVE, APT 626 COLUMBUS, OH 43229
        )

)

ERROR - 2019-02-01 14:11:07 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 227231
					    				and MTYPE = 'S'
								    	and MSKU  = '1485857'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VC185-53QFS' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST STATES FOOTBOARD HAS DENTS IN IT.
        )

)

ERROR - 2019-02-01 14:11:09 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 277442
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:11:09 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 277442
					    				and MTYPE = 'S'
								    	and MSKU  = '1727184'
								    	and MSSEQ = 050
								    	and MSBSQ = 01
								    	and MITEM = 'WYB-809-4-MB' V: R:
ERROR - 2019-02-01 14:11:10 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 19003
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => X
        )

)

ERROR - 2019-02-01 14:11:11 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 19003
					    				and MTYPE = 'S'
								    	and MSKU  = '1808915'
								    	and MSSEQ = 010
								    	and MSBSQ = 02
								    	and MITEM = '8633-67-CCH' V: R:
ERROR - 2019-02-01 14:11:11 --> Select (Calc: 0.01)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTOP] => 1
            [RSPRBACT] => U
        )

    [1] => stdClass Object
        (
            [RSSTOP] => 2
            [RSPRBACT] => U
        )

    [2] => stdClass Object
        (
            [RSSTOP] => 3
            [RSPRBACT] => U
        )

    [3] => stdClass Object
        (
            [RSSTOP] => 4
            [RSPRBACT] => U
        )

    [4] => stdClass Object
        (
            [RSSTOP] => 5
            [RSPRBACT] => U
        )

    [5] => stdClass Object
        (
            [RSSTOP] => 6
            [RSPRBACT] => U
        )

)

ERROR - 2019-02-01 14:11:12 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:11:13 --> Select (Calc: 0.01)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 14:11:13 --> Select (Calc: 0.01)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 14:11:14 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:15 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:16 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:11:17 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:18 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 14:11:18 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:19 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 14:11:20 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:21 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:22 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:22 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:23 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:24 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:25 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:26 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:11:27 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:11:27 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:11:28 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:11:28 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:11:33 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:11:33 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:17:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:17:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:22:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:22:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:22:59 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:22:59 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:22:59 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:23:01 --> Select (Calc: 0.01)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 14:23:01 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929089
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1929089_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:23:02 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1592548
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1592548_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:23:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912976
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643263.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 14:23:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1485857
)
 R:
ERROR - 2019-02-01 14:23:04 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1727184
)
 R:
ERROR - 2019-02-01 14:23:05 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808915
)
 R:
ERROR - 2019-02-01 14:23:05 --> Select (Calc: 0.01)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100574 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 14:23:06 --> Select (Calc: 0.02)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 141000
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 249677
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929089
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:23:07 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140957
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237343
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1592548
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:23:07 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140954
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237193
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912976
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:23:08 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140949
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 227231
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1485857
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:23:09 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140946
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 105
            [RSINVNO] => 277442
            [RSINSEQ] => 50
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1727184
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:23:10 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => L
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 141757
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 164
            [RSINVNO] => 19003
            [RSINSEQ] => 10
            [RSINSSS] => 2
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808915
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:23:10 --> Select (Calc: 0.01)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:23:11 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:23:12 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:23:13 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:23:14 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:23:14 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:23:15 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 249677
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:23:16 --> Select (Calc: 0.02)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 249677
					    				and MTYPE = 'S'
								    	and MSKU  = '1929089'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BL-PB' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => COMPARTMENT LID ON LAF ISNT SECURED PROPERLY
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/2/19 QC IN RECLINER FOR RSF ARM TOP AND HINGES. INCOMPLETE. ES8
        )

    [2] => stdClass Object
        (
            [MTEXT] => 25.
        )

    [3] => stdClass Object
        (
            [MTEXT] => QC IN RCLNR FOR
        )

    [4] => stdClass Object
        (
            [MTEXT] => ARM TOP AND HINGES
        )

)

ERROR - 2019-02-01 14:23:17 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237343
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:23:18 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237343
					    				and MTYPE = 'S'
								    	and MSKU  = '1592548'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'XW9387-L1-1E-DW' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                     PROBLEM WITH FABRIC
        )

)

ERROR - 2019-02-01 14:23:18 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237193
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:23:19 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237193
					    				and MTYPE = 'S'
								    	and MSKU  = '1912976'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '820482-6M' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST REPORTING THAT BED HAS "BROKEN DAMAGE", RIPPLES IN THE
        )

    [1] => stdClass Object
        (
            [MTEXT] => MATT.
        )

)

ERROR - 2019-02-01 14:23:22 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 227231
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 961 ATLANTIC AVE, APT 626 COLUMBUS, OH 43229
        )

)

ERROR - 2019-02-01 14:23:23 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 227231
					    				and MTYPE = 'S'
								    	and MSKU  = '1485857'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VC185-53QFS' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST STATES FOOTBOARD HAS DENTS IN IT.
        )

)

ERROR - 2019-02-01 14:23:24 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 277442
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:23:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 277442
					    				and MTYPE = 'S'
								    	and MSKU  = '1727184'
								    	and MSSEQ = 050
								    	and MSBSQ = 01
								    	and MITEM = 'WYB-809-4-MB' V: R:
ERROR - 2019-02-01 14:23:26 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 19003
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => X
        )

)

ERROR - 2019-02-01 14:23:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 19003
					    				and MTYPE = 'S'
								    	and MSKU  = '1808915'
								    	and MSSEQ = 010
								    	and MSBSQ = 02
								    	and MITEM = '8633-67-CCH' V: R:
ERROR - 2019-02-01 14:23:27 --> Select (Calc: 0.01)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTOP] => 1
            [RSPRBACT] => U
        )

    [1] => stdClass Object
        (
            [RSSTOP] => 2
            [RSPRBACT] => U
        )

    [2] => stdClass Object
        (
            [RSSTOP] => 3
            [RSPRBACT] => U
        )

    [3] => stdClass Object
        (
            [RSSTOP] => 4
            [RSPRBACT] => U
        )

    [4] => stdClass Object
        (
            [RSSTOP] => 5
            [RSPRBACT] => U
        )

    [5] => stdClass Object
        (
            [RSSTOP] => 6
            [RSPRBACT] => L
        )

)

ERROR - 2019-02-01 14:23:28 --> Select (Calc: 0.01)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:23:29 --> Select (Calc: 0.02)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 14:23:29 --> Select (Calc: 0.01)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 14:23:30 --> Select (Calc: 0.01)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:31 --> Select (Calc: 0.01)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:32 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:23:33 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:34 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 14:23:35 --> Select (Calc: 0.02)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:36 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 14:23:37 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:38 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:39 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:39 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:40 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:41 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:42 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:43 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:23:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:23:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:23:46 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:23:46 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:25:40 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:25:40 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:25:44 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:25:44 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:31:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:31:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:31:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:31:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:31:59 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:32:01 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 14:32:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929089
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1929089_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:32:02 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1592548
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1592548_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:32:02 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912976
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643263.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 14:32:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1485857
)
 R:
ERROR - 2019-02-01 14:32:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1727184
)
 R:
ERROR - 2019-02-01 14:32:04 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808915
)
 R:
ERROR - 2019-02-01 14:32:05 --> Select (Calc: 0.00)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100574 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 14:32:06 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 141000
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 249677
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929089
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:32:06 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140957
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237343
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1592548
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:32:07 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140954
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237193
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912976
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:32:07 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140949
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 227231
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1485857
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:32:08 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140946
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 105
            [RSINVNO] => 277442
            [RSINSEQ] => 50
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1727184
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:32:09 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => L
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 142544
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 164
            [RSINVNO] => 19003
            [RSINSEQ] => 10
            [RSINSSS] => 2
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808915
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:32:09 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:32:10 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:32:10 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:32:11 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:32:12 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:32:12 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:32:13 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 249677
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:32:14 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 249677
					    				and MTYPE = 'S'
								    	and MSKU  = '1929089'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BL-PB' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => COMPARTMENT LID ON LAF ISNT SECURED PROPERLY
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/2/19 QC IN RECLINER FOR RSF ARM TOP AND HINGES. INCOMPLETE. ES8
        )

    [2] => stdClass Object
        (
            [MTEXT] => 25.
        )

    [3] => stdClass Object
        (
            [MTEXT] => QC IN RCLNR FOR
        )

    [4] => stdClass Object
        (
            [MTEXT] => ARM TOP AND HINGES
        )

)

ERROR - 2019-02-01 14:32:14 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237343
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:32:15 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237343
					    				and MTYPE = 'S'
								    	and MSKU  = '1592548'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'XW9387-L1-1E-DW' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                     PROBLEM WITH FABRIC
        )

)

ERROR - 2019-02-01 14:32:16 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237193
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:32:17 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237193
					    				and MTYPE = 'S'
								    	and MSKU  = '1912976'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '820482-6M' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST REPORTING THAT BED HAS "BROKEN DAMAGE", RIPPLES IN THE
        )

    [1] => stdClass Object
        (
            [MTEXT] => MATT.
        )

)

ERROR - 2019-02-01 14:32:17 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 227231
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 961 ATLANTIC AVE, APT 626 COLUMBUS, OH 43229
        )

)

ERROR - 2019-02-01 14:32:18 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 227231
					    				and MTYPE = 'S'
								    	and MSKU  = '1485857'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VC185-53QFS' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST STATES FOOTBOARD HAS DENTS IN IT.
        )

)

ERROR - 2019-02-01 14:32:19 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 277442
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:32:19 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 277442
					    				and MTYPE = 'S'
								    	and MSKU  = '1727184'
								    	and MSSEQ = 050
								    	and MSBSQ = 01
								    	and MITEM = 'WYB-809-4-MB' V: R:
ERROR - 2019-02-01 14:32:20 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 19003
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => X
        )

)

ERROR - 2019-02-01 14:32:21 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 19003
					    				and MTYPE = 'S'
								    	and MSKU  = '1808915'
								    	and MSSEQ = 010
								    	and MSBSQ = 02
								    	and MITEM = '8633-67-CCH' V: R:
ERROR - 2019-02-01 14:32:21 --> Select (Calc: 0.00)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTOP] => 1
            [RSPRBACT] => U
        )

    [1] => stdClass Object
        (
            [RSSTOP] => 2
            [RSPRBACT] => U
        )

    [2] => stdClass Object
        (
            [RSSTOP] => 3
            [RSPRBACT] => U
        )

    [3] => stdClass Object
        (
            [RSSTOP] => 4
            [RSPRBACT] => U
        )

    [4] => stdClass Object
        (
            [RSSTOP] => 5
            [RSPRBACT] => U
        )

    [5] => stdClass Object
        (
            [RSSTOP] => 6
            [RSPRBACT] => L
        )

)

ERROR - 2019-02-01 14:32:22 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:32:23 --> Select (Calc: 0.01)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 14:32:24 --> Select (Calc: 0.01)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 14:32:25 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:26 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:26 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:32:27 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:28 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 14:32:29 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:30 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 14:32:31 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:31 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:32 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:33 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:34 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:35 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:35 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:36 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:32:40 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:32:40 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:32:41 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:32:41 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:33:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:33:18 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:33:22 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:33:22 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:34:29 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:34:29 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:34:30 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:34:30 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:34:31 --> Select (Calc: 0.04)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:34:32 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 14:34:33 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929089
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1929089_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:34:33 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1592548
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1592548_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:34:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912976
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643263.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 14:34:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1485857
)
 R:
ERROR - 2019-02-01 14:34:35 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1727184
)
 R:
ERROR - 2019-02-01 14:34:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808915
)
 R:
ERROR - 2019-02-01 14:34:36 --> Select (Calc: 0.01)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100574 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 14:34:37 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 141000
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 249677
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929089
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:34:38 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140957
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237343
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1592548
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:34:38 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140954
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237193
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912976
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:34:39 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140949
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 227231
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1485857
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:34:39 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140946
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 105
            [RSINVNO] => 277442
            [RSINSEQ] => 50
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1727184
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:34:40 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => L
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 143321
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 164
            [RSINVNO] => 19003
            [RSINSEQ] => 10
            [RSINSSS] => 2
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808915
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:34:41 --> Select (Calc: 0.01)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:34:41 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:34:42 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:34:42 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:34:43 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:34:44 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:34:44 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 249677
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:34:45 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 249677
					    				and MTYPE = 'S'
								    	and MSKU  = '1929089'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BL-PB' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => COMPARTMENT LID ON LAF ISNT SECURED PROPERLY
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/2/19 QC IN RECLINER FOR RSF ARM TOP AND HINGES. INCOMPLETE. ES8
        )

    [2] => stdClass Object
        (
            [MTEXT] => 25.
        )

    [3] => stdClass Object
        (
            [MTEXT] => QC IN RCLNR FOR
        )

    [4] => stdClass Object
        (
            [MTEXT] => ARM TOP AND HINGES
        )

)

ERROR - 2019-02-01 14:34:46 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237343
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:34:47 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237343
					    				and MTYPE = 'S'
								    	and MSKU  = '1592548'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'XW9387-L1-1E-DW' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                     PROBLEM WITH FABRIC
        )

)

ERROR - 2019-02-01 14:34:48 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237193
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:34:48 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237193
					    				and MTYPE = 'S'
								    	and MSKU  = '1912976'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '820482-6M' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST REPORTING THAT BED HAS "BROKEN DAMAGE", RIPPLES IN THE
        )

    [1] => stdClass Object
        (
            [MTEXT] => MATT.
        )

)

ERROR - 2019-02-01 14:34:49 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 227231
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 961 ATLANTIC AVE, APT 626 COLUMBUS, OH 43229
        )

)

ERROR - 2019-02-01 14:34:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 227231
					    				and MTYPE = 'S'
								    	and MSKU  = '1485857'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VC185-53QFS' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST STATES FOOTBOARD HAS DENTS IN IT.
        )

)

ERROR - 2019-02-01 14:34:50 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 277442
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:34:51 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 277442
					    				and MTYPE = 'S'
								    	and MSKU  = '1727184'
								    	and MSSEQ = 050
								    	and MSBSQ = 01
								    	and MITEM = 'WYB-809-4-MB' V: R:
ERROR - 2019-02-01 14:34:52 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 19003
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => X
        )

)

ERROR - 2019-02-01 14:34:52 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:34:52 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:34:53 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 19003
					    				and MTYPE = 'S'
								    	and MSKU  = '1808915'
								    	and MSSEQ = 010
								    	and MSBSQ = 02
								    	and MITEM = '8633-67-CCH' V: R:
ERROR - 2019-02-01 14:34:53 --> Select (Calc: 0.00)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTOP] => 1
            [RSPRBACT] => U
        )

    [1] => stdClass Object
        (
            [RSSTOP] => 2
            [RSPRBACT] => U
        )

    [2] => stdClass Object
        (
            [RSSTOP] => 3
            [RSPRBACT] => U
        )

    [3] => stdClass Object
        (
            [RSSTOP] => 4
            [RSPRBACT] => U
        )

    [4] => stdClass Object
        (
            [RSSTOP] => 5
            [RSPRBACT] => U
        )

    [5] => stdClass Object
        (
            [RSSTOP] => 6
            [RSPRBACT] => L
        )

)

ERROR - 2019-02-01 14:34:54 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:34:55 --> Select (Calc: 0.00)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 14:34:55 --> Select (Calc: 0.00)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 14:34:56 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:34:57 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:34:58 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:34:59 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:34:59 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 14:35:00 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:01 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 14:35:02 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:03 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:03 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:04 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:05 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:06 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:07 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:07 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:35:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:35:09 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:35:11 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 14:35:11 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929089
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1929089_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:35:12 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1592548
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1592548_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:35:12 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912976
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643263.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 14:35:13 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1485857
)
 R:
ERROR - 2019-02-01 14:35:13 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1727184
)
 R:
ERROR - 2019-02-01 14:35:14 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808915
)
 R:
ERROR - 2019-02-01 14:35:15 --> Select (Calc: 0.00)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100574 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 14:35:16 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 141000
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 249677
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929089
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:35:16 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140957
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237343
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1592548
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:35:17 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140954
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237193
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912976
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:35:18 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140949
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 227231
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1485857
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:35:18 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140946
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 105
            [RSINVNO] => 277442
            [RSINSEQ] => 50
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1727184
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:35:19 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => L
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 143321
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 164
            [RSINVNO] => 19003
            [RSINSEQ] => 10
            [RSINSSS] => 2
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808915
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:35:20 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:35:20 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:35:21 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:35:21 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:35:22 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:35:23 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:35:23 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 249677
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:35:24 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 249677
					    				and MTYPE = 'S'
								    	and MSKU  = '1929089'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BL-PB' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => COMPARTMENT LID ON LAF ISNT SECURED PROPERLY
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/2/19 QC IN RECLINER FOR RSF ARM TOP AND HINGES. INCOMPLETE. ES8
        )

    [2] => stdClass Object
        (
            [MTEXT] => 25.
        )

    [3] => stdClass Object
        (
            [MTEXT] => QC IN RCLNR FOR
        )

    [4] => stdClass Object
        (
            [MTEXT] => ARM TOP AND HINGES
        )

)

ERROR - 2019-02-01 14:35:25 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237343
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:35:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237343
					    				and MTYPE = 'S'
								    	and MSKU  = '1592548'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'XW9387-L1-1E-DW' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                     PROBLEM WITH FABRIC
        )

)

ERROR - 2019-02-01 14:35:26 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237193
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:35:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237193
					    				and MTYPE = 'S'
								    	and MSKU  = '1912976'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '820482-6M' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST REPORTING THAT BED HAS "BROKEN DAMAGE", RIPPLES IN THE
        )

    [1] => stdClass Object
        (
            [MTEXT] => MATT.
        )

)

ERROR - 2019-02-01 14:35:28 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 227231
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 961 ATLANTIC AVE, APT 626 COLUMBUS, OH 43229
        )

)

ERROR - 2019-02-01 14:35:28 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 227231
					    				and MTYPE = 'S'
								    	and MSKU  = '1485857'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VC185-53QFS' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST STATES FOOTBOARD HAS DENTS IN IT.
        )

)

ERROR - 2019-02-01 14:35:29 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 277442
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:35:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 277442
					    				and MTYPE = 'S'
								    	and MSKU  = '1727184'
								    	and MSSEQ = 050
								    	and MSBSQ = 01
								    	and MITEM = 'WYB-809-4-MB' V: R:
ERROR - 2019-02-01 14:35:31 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 19003
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => X
        )

)

ERROR - 2019-02-01 14:35:31 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 19003
					    				and MTYPE = 'S'
								    	and MSKU  = '1808915'
								    	and MSSEQ = 010
								    	and MSBSQ = 02
								    	and MITEM = '8633-67-CCH' V: R:
ERROR - 2019-02-01 14:35:32 --> Select (Calc: 0.01)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTOP] => 1
            [RSPRBACT] => U
        )

    [1] => stdClass Object
        (
            [RSSTOP] => 2
            [RSPRBACT] => U
        )

    [2] => stdClass Object
        (
            [RSSTOP] => 3
            [RSPRBACT] => U
        )

    [3] => stdClass Object
        (
            [RSSTOP] => 4
            [RSPRBACT] => U
        )

    [4] => stdClass Object
        (
            [RSSTOP] => 5
            [RSPRBACT] => U
        )

    [5] => stdClass Object
        (
            [RSSTOP] => 6
            [RSPRBACT] => L
        )

)

ERROR - 2019-02-01 14:35:33 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:35:34 --> Select (Calc: 0.02)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 14:35:35 --> Select (Calc: 0.01)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 14:35:36 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:37 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:38 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:35:38 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:41 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 14:35:42 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:43 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 14:35:44 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:45 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:46 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:46 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:48 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:48 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:49 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:50 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:35:52 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:35:52 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:35:53 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:35:53 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:37:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:37:04 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:37:11 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:37:11 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:45:44 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:45:44 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:45:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:45:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:45:45 --> Select (Calc: 0.02)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:45:47 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 14:45:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929089
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1929089_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:45:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1592548
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1592548_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:45:49 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912976
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643263.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 14:45:49 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1485857
)
 R:
ERROR - 2019-02-01 14:45:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1727184
)
 R:
ERROR - 2019-02-01 14:45:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808915
)
 R:
ERROR - 2019-02-01 14:45:52 --> Select (Calc: 0.01)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100574 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 14:45:52 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 141000
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 249677
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929089
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:45:53 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140957
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237343
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1592548
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:45:54 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140954
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237193
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912976
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:45:54 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140949
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 227231
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1485857
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:45:55 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140946
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 105
            [RSINVNO] => 277442
            [RSINSEQ] => 50
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1727184
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:45:56 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => L
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 143711
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 164
            [RSINVNO] => 19003
            [RSINSEQ] => 10
            [RSINSSS] => 2
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808915
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:45:56 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:45:57 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:45:58 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:45:58 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:45:59 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:45:59 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:46:00 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 249677
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:46:01 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 249677
					    				and MTYPE = 'S'
								    	and MSKU  = '1929089'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BL-PB' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => COMPARTMENT LID ON LAF ISNT SECURED PROPERLY
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/2/19 QC IN RECLINER FOR RSF ARM TOP AND HINGES. INCOMPLETE. ES8
        )

    [2] => stdClass Object
        (
            [MTEXT] => 25.
        )

    [3] => stdClass Object
        (
            [MTEXT] => QC IN RCLNR FOR
        )

    [4] => stdClass Object
        (
            [MTEXT] => ARM TOP AND HINGES
        )

)

ERROR - 2019-02-01 14:46:02 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237343
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:46:02 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237343
					    				and MTYPE = 'S'
								    	and MSKU  = '1592548'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'XW9387-L1-1E-DW' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                     PROBLEM WITH FABRIC
        )

)

ERROR - 2019-02-01 14:46:03 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237193
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:46:04 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237193
					    				and MTYPE = 'S'
								    	and MSKU  = '1912976'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '820482-6M' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST REPORTING THAT BED HAS "BROKEN DAMAGE", RIPPLES IN THE
        )

    [1] => stdClass Object
        (
            [MTEXT] => MATT.
        )

)

ERROR - 2019-02-01 14:46:05 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 227231
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 961 ATLANTIC AVE, APT 626 COLUMBUS, OH 43229
        )

)

ERROR - 2019-02-01 14:46:05 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 227231
					    				and MTYPE = 'S'
								    	and MSKU  = '1485857'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VC185-53QFS' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST STATES FOOTBOARD HAS DENTS IN IT.
        )

)

ERROR - 2019-02-01 14:46:06 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 277442
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:46:07 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 277442
					    				and MTYPE = 'S'
								    	and MSKU  = '1727184'
								    	and MSSEQ = 050
								    	and MSBSQ = 01
								    	and MITEM = 'WYB-809-4-MB' V: R:
ERROR - 2019-02-01 14:46:08 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 19003
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => X
        )

)

ERROR - 2019-02-01 14:46:08 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 19003
					    				and MTYPE = 'S'
								    	and MSKU  = '1808915'
								    	and MSSEQ = 010
								    	and MSBSQ = 02
								    	and MITEM = '8633-67-CCH' V: R:
ERROR - 2019-02-01 14:46:09 --> Select (Calc: 0.00)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTOP] => 1
            [RSPRBACT] => U
        )

    [1] => stdClass Object
        (
            [RSSTOP] => 2
            [RSPRBACT] => U
        )

    [2] => stdClass Object
        (
            [RSSTOP] => 3
            [RSPRBACT] => U
        )

    [3] => stdClass Object
        (
            [RSSTOP] => 4
            [RSPRBACT] => U
        )

    [4] => stdClass Object
        (
            [RSSTOP] => 5
            [RSPRBACT] => U
        )

    [5] => stdClass Object
        (
            [RSSTOP] => 6
            [RSPRBACT] => L
        )

)

ERROR - 2019-02-01 14:46:10 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:46:10 --> Select (Calc: 0.01)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 14:46:11 --> Select (Calc: 0.01)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 14:46:12 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:13 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:14 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:46:15 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:15 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 14:46:16 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:17 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 14:46:18 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:19 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:20 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:20 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:21 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:22 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:23 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:24 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:46:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:46:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:46:26 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:46:26 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:46:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:46:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:47:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:47:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:49:03 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:49:03 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:49:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:49:04 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:49:05 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 14:49:06 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 14:49:07 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929089
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1929089_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:49:07 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1592548
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1592548_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 14:49:08 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912976
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643263.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 14:49:09 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1485857
)
 R:
ERROR - 2019-02-01 14:49:09 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1727184
)
 R:
ERROR - 2019-02-01 14:49:10 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808915
)
 R:
ERROR - 2019-02-01 14:49:11 --> Select (Calc: 0.00)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100574 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 14:49:11 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 141000
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 249677
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929089
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:49:12 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140957
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237343
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1592548
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:49:13 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140954
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 237193
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912976
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:49:13 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140949
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 227231
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1485857
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:49:14 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => U
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 140946
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 105
            [RSINVNO] => 277442
            [RSINSEQ] => 50
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1727184
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:49:15 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => L
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 144632
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 164
            [RSINVNO] => 19003
            [RSINSEQ] => 10
            [RSINSSS] => 2
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808915
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 14:49:15 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:49:16 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:49:16 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:49:17 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:49:18 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:49:18 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100574
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 14:49:19 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 249677
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:49:20 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 249677
					    				and MTYPE = 'S'
								    	and MSKU  = '1929089'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX551-01P/BL-PB' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => COMPARTMENT LID ON LAF ISNT SECURED PROPERLY
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/2/19 QC IN RECLINER FOR RSF ARM TOP AND HINGES. INCOMPLETE. ES8
        )

    [2] => stdClass Object
        (
            [MTEXT] => 25.
        )

    [3] => stdClass Object
        (
            [MTEXT] => QC IN RCLNR FOR
        )

    [4] => stdClass Object
        (
            [MTEXT] => ARM TOP AND HINGES
        )

)

ERROR - 2019-02-01 14:49:20 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237343
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:49:21 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237343
					    				and MTYPE = 'S'
								    	and MSKU  = '1592548'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'XW9387-L1-1E-DW' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                     PROBLEM WITH FABRIC
        )

)

ERROR - 2019-02-01 14:49:22 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 237193
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:49:23 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 237193
					    				and MTYPE = 'S'
								    	and MSKU  = '1912976'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '820482-6M' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST REPORTING THAT BED HAS "BROKEN DAMAGE", RIPPLES IN THE
        )

    [1] => stdClass Object
        (
            [MTEXT] => MATT.
        )

)

ERROR - 2019-02-01 14:49:24 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 227231
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 961 ATLANTIC AVE, APT 626 COLUMBUS, OH 43229
        )

)

ERROR - 2019-02-01 14:49:24 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 227231
					    				and MTYPE = 'S'
								    	and MSKU  = '1485857'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VC185-53QFS' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => CUST STATES FOOTBOARD HAS DENTS IN IT.
        )

)

ERROR - 2019-02-01 14:49:25 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 277442
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 14:49:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 277442
					    				and MTYPE = 'S'
								    	and MSKU  = '1727184'
								    	and MSSEQ = 050
								    	and MSBSQ = 01
								    	and MITEM = 'WYB-809-4-MB' V: R:
ERROR - 2019-02-01 14:49:27 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 19003
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => X
        )

)

ERROR - 2019-02-01 14:49:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 19003
					    				and MTYPE = 'S'
								    	and MSKU  = '1808915'
								    	and MSSEQ = 010
								    	and MSBSQ = 02
								    	and MITEM = '8633-67-CCH' V: R:
ERROR - 2019-02-01 14:49:28 --> Select (Calc: 0.00)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100574
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTOP] => 1
            [RSPRBACT] => U
        )

    [1] => stdClass Object
        (
            [RSSTOP] => 2
            [RSPRBACT] => U
        )

    [2] => stdClass Object
        (
            [RSSTOP] => 3
            [RSPRBACT] => U
        )

    [3] => stdClass Object
        (
            [RSSTOP] => 4
            [RSPRBACT] => U
        )

    [4] => stdClass Object
        (
            [RSSTOP] => 5
            [RSPRBACT] => U
        )

    [5] => stdClass Object
        (
            [RSSTOP] => 6
            [RSPRBACT] => L
        )

)

ERROR - 2019-02-01 14:49:29 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:49:29 --> Select (Calc: 0.00)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 14:49:30 --> Select (Calc: 0.00)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 14:49:31 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:32 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:32 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 14:49:33 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:34 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 14:49:35 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:36 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 14:49:36 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:37 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:38 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:39 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:40 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:40 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:41 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:42 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 14:49:44 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:49:44 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:49:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:49:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 14:56:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:56:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:58:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:58:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 14:58:41 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 14:58:41 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:04:09 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:04:09 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:04:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:04:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:04:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:04:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:04:13 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:04:13 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:04:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:04:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:04:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:04:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:04:15 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100574
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 50
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN1
            [RHMILES] => 0
            [RADRVUSER] => 0493528475
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:04:16 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100574'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 15:04:17 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100574' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100574
            [RHDATE] => 20190201
            [RHTRUC] => 50
            [RHDRIV] => Eric Snell
            [RHHELP] => Eric Snell
            [RHSTOP] => 6
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => C
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 60942
            [RHHLPEMP] => 60942
            [RHTRNAME] => VAN1
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Stop 06 load aborted
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 15:04:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:04:18 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:05:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:05:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:05:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:05:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:05:17 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:05:18 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100593'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 15:05:19 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100593' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100593
            [RHDATE] => 20190201
            [RHTRUC] => 51
            [RHDRIV] => Austin Williams
            [RHHELP] => Austin Williams
            [RHSTOP] => 5
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => B
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 63205
            [RHHLPEMP] => 63205
            [RHTRNAME] => 
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready to Load: 8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 15:05:20 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:05:20 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:05:24 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:05:24 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:05:24 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:05:24 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:05:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:05:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:05:26 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:05:28 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 15:05:29 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1834843
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501115.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:05:29 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1937707
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1937707.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:05:30 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1630938
)
 R:
ERROR - 2019-02-01 15:05:30 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1897578
)
 R:
ERROR - 2019-02-01 15:05:31 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1818465
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/420943.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:05:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1818473
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/420946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:05:33 --> Select (Calc: 0.00)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100593 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 15:05:33 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 19
            [RSINVNO] => 753245
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1834843
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:05:34 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 251845
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1937707
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:05:34 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 239311
            [RSINSEQ] => 20
            [RSINSSS] => 6
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1630938
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:05:35 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 240333
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1897578
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:05:36 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 165
            [RSINVNO] => 13034
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1818465
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 165
            [RSINVNO] => 13034
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1818473
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:05:36 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:05:37 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:05:38 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:05:38 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:05:39 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:05:40 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 753245
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:05:41 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 753245
					    				and MTYPE = 'S'
								    	and MSKU  = '1834843'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '1126-CPB420' V: R:
ERROR - 2019-02-01 15:05:41 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 251845
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:05:42 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 251845
					    				and MTYPE = 'S'
								    	and MSKU  = '1937707'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1861R-P4SF9KH' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => SCRATCHES ON TABLE TOP
        )

)

ERROR - 2019-02-01 15:05:43 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 239311
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:05:43 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 239311
					    				and MTYPE = 'S'
								    	and MSKU  = '1630938'
								    	and MSSEQ = 020
								    	and MSBSQ = 06
								    	and MITEM = '1240-49-BSC' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 1/22/1019 12:09 CCI CHAISE IS BOUNCING WHEN YOU SIT IN IT AND YOU
        )

    [1] => stdClass Object
        (
            [MTEXT] => SINK IN IT MARKG@CC
        )

)

ERROR - 2019-02-01 15:05:44 --> Select (Calc: 0.12)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 240333
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:05:45 --> Select (Calc: 0.02)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 240333
					    				and MTYPE = 'S'
								    	and MSKU  = '1897578'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'UJP546255NF-CG' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => LOUD SQUEEK WHEN STTING ON LVST
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/4/19 DAKOTA@825 NO ONE HOME. 235-250P.
        )

    [2] => stdClass Object
        (
            [MTEXT] => LOUD SQUEEK WHEN STTING ON LVST
        )

)

ERROR - 2019-02-01 15:05:46 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 13034
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:05:47 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 13034
					    				and MTYPE = 'S'
								    	and MSKU  = '1818465'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680-R-AM' V: R:
ERROR - 2019-02-01 15:05:47 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 13034
					    				and MTYPE = 'S'
								    	and MSKU  = '1818473'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680-SOF-AM' V: R:
ERROR - 2019-02-01 15:05:48 --> Select (Calc: 0.00)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:
ERROR - 2019-02-01 15:05:49 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 15:05:49 --> Select (Calc: 0.00)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN2
            [CTCURMILES] => 1
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [7] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 15:05:50 --> Select (Calc: 0.00)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 15:05:51 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:05:52 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:05:53 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 15:05:54 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:05:55 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 15:05:55 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:05:56 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 15:05:57 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:05:58 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:05:59 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:06:00 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:06:01 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:06:02 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:06:02 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:06:03 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:06:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:06:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:06:06 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:06:06 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:12:21 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:12:21 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:14:24 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:14:24 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:14:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:14:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:14:26 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN2
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:14:27 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 15:14:28 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1834843
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501115.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:14:28 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1937707
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1937707.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:14:29 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1630938
)
 R:
ERROR - 2019-02-01 15:14:30 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1897578
)
 R:
ERROR - 2019-02-01 15:14:31 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1818465
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/420943.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:14:31 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1818473
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/420946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:14:32 --> Select (Calc: 0.00)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100593 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 15:14:33 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 19
            [RSINVNO] => 753245
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1834843
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:14:33 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 251845
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1937707
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:14:34 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 239311
            [RSINSEQ] => 20
            [RSINSSS] => 6
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1630938
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:14:34 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 240333
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1897578
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:14:35 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 165
            [RSINVNO] => 13034
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1818465
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 165
            [RSINVNO] => 13034
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1818473
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:14:36 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:14:36 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:14:37 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:14:38 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:14:38 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:14:39 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 753245
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:14:40 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 753245
					    				and MTYPE = 'S'
								    	and MSKU  = '1834843'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '1126-CPB420' V: R:
ERROR - 2019-02-01 15:14:40 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 251845
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:14:41 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 251845
					    				and MTYPE = 'S'
								    	and MSKU  = '1937707'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1861R-P4SF9KH' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => SCRATCHES ON TABLE TOP
        )

)

ERROR - 2019-02-01 15:14:42 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 239311
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:14:42 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 239311
					    				and MTYPE = 'S'
								    	and MSKU  = '1630938'
								    	and MSSEQ = 020
								    	and MSBSQ = 06
								    	and MITEM = '1240-49-BSC' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 1/22/1019 12:09 CCI CHAISE IS BOUNCING WHEN YOU SIT IN IT AND YOU
        )

    [1] => stdClass Object
        (
            [MTEXT] => SINK IN IT MARKG@CC
        )

)

ERROR - 2019-02-01 15:14:43 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 240333
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:14:44 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 240333
					    				and MTYPE = 'S'
								    	and MSKU  = '1897578'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'UJP546255NF-CG' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => LOUD SQUEEK WHEN STTING ON LVST
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/4/19 DAKOTA@825 NO ONE HOME. 235-250P.
        )

    [2] => stdClass Object
        (
            [MTEXT] => LOUD SQUEEK WHEN STTING ON LVST
        )

)

ERROR - 2019-02-01 15:14:45 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 13034
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:14:45 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 13034
					    				and MTYPE = 'S'
								    	and MSKU  = '1818465'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680-R-AM' V: R:
ERROR - 2019-02-01 15:14:46 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 13034
					    				and MTYPE = 'S'
								    	and MSKU  = '1818473'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680-SOF-AM' V: R:
ERROR - 2019-02-01 15:14:47 --> Select (Calc: 0.00)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:
ERROR - 2019-02-01 15:14:48 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 15:14:48 --> Select (Calc: 0.00)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 15:14:49 --> Select (Calc: 0.00)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 15:14:50 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:14:51 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:14:52 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 15:14:53 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:14:53 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 15:14:54 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:14:55 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 15:14:56 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:14:57 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:14:57 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:14:58 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:14:59 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:15:00 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:15:01 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:15:02 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:15:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:15:04 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:15:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:15:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:15:29 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:15:29 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:16:38 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:16:38 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:16:54 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:16:54 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:16:54 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:16:54 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:16:55 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:16:55 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:16:56 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:16:56 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:16:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:16:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:16:57 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN2
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:16:58 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100593'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 15:16:58 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100593' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100593
            [RHDATE] => 20190201
            [RHTRUC] => 51
            [RHDRIV] => Austin Williams
            [RHHELP] => Austin Williams
            [RHSTOP] => 5
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => C
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 63205
            [RHHLPEMP] => 63205
            [RHTRNAME] => VAN2
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Driver now loading
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 15:16:59 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:16:59 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:19:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:19:04 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:19:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:19:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:19:05 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100579
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 7135528975
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:19:06 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100579'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 15:19:07 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100579' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100579
            [RHDATE] => 20190201
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 9
            [RHCUBE] => 853
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => B
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => 
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 11881501
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 11
            [RHDRVDIST] => 6925
            [RHPRJDEP] => 730
            [RHPRJARV] => 1605
            [RHPRJMILES] => 48
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready to Load: 8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 15:19:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:19:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:19:11 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:19:11 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:19:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:19:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:19:13 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:19:13 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:19:14 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100579
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => 
            [RHMILES] => 0
            [RADRVUSER] => 7135528975
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:19:16 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 15:19:17 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831577
)
 R:
ERROR - 2019-02-01 15:19:17 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831585
)
 R:
ERROR - 2019-02-01 15:19:18 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831623
)
 R:
ERROR - 2019-02-01 15:19:18 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831666
)
 R:
ERROR - 2019-02-01 15:19:19 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831534
)
 R:
ERROR - 2019-02-01 15:19:20 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1673998
)
 R:
ERROR - 2019-02-01 15:19:20 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1907328
)
 R:
ERROR - 2019-02-01 15:19:21 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1907336
)
 R:
ERROR - 2019-02-01 15:19:22 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1907352
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/646670.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:19:22 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1673998
)
 R:
ERROR - 2019-02-01 15:19:23 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800817
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1800817_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 15:19:23 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1673998
)
 R:
ERROR - 2019-02-01 15:19:24 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 9827692
)
 R:
ERROR - 2019-02-01 15:19:24 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 9827718
)
 R:
ERROR - 2019-02-01 15:19:25 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1873555
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/547963.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:19:26 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1673998
)
 R:
ERROR - 2019-02-01 15:19:26 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1873636
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/547969.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:19:27 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867172
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/539147.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:19:27 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1076817
)
 R:
ERROR - 2019-02-01 15:19:28 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1076825
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/370367.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:19:29 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1076833
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1076933_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 15:19:29 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808338
)
 R:
ERROR - 2019-02-01 15:19:30 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1808389
)
 R:
ERROR - 2019-02-01 15:19:30 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1912402
)
 R:
ERROR - 2019-02-01 15:19:31 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1931342
)
 R:
ERROR - 2019-02-01 15:19:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1931512
)
 R:
ERROR - 2019-02-01 15:19:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1954008
)
 R:
ERROR - 2019-02-01 15:19:33 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1673998
)
 R:
ERROR - 2019-02-01 15:19:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1954024
)
 R:
ERROR - 2019-02-01 15:19:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1561928
)
 R:
ERROR - 2019-02-01 15:19:35 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1561936
)
 R:
ERROR - 2019-02-01 15:19:35 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1561987
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1561987_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 15:19:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1561995
)
 R:
ERROR - 2019-02-01 15:19:37 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1400606
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/J_1400606_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-01 15:19:37 --> Select (Calc: 0.00)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100579 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 48
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 15:19:38 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253351
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831577
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253351
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831585
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253351
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831623
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253351
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831666
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253351
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831534
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253351
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1673998
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:39 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253283
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1907328
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253283
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1907336
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253283
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1907352
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253283
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1673998
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:39 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253590
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800817
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253590
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1673998
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:40 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253827
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 9827692
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253827
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 9827718
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:40 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253064
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1873555
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253064
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1673998
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253064
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1873636
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253064
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867172
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:41 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253831
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1076817
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253831
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1076825
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253831
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1076833
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:42 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=07
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 248697
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808338
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 248697
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1808389
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 248699
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1912402
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 248699
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1931342
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 248699
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1931512
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:42 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=08
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253417
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1954008
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253417
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1673998
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253417
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1954024
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:43 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100579
                    AND RSSTOP=09
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252898
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1400606
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252898
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1561928
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252898
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1561936
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252898
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1561987
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252898
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1561995
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:19:43 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:44 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:44 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:45 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:46 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:46 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:47 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=07
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:47 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=08
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:48 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100579
                    AND RISTOP=09
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:19:49 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253351
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:19:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253351
					    				and MTYPE = 'I'
								    	and MSKU  = '1831577'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1408L-81P-NB' V: R:
ERROR - 2019-02-01 15:19:50 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253351
					    				and MTYPE = 'I'
								    	and MSKU  = '1831585'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '1408L-05-NB' V: R:
ERROR - 2019-02-01 15:19:51 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253351
					    				and MTYPE = 'I'
								    	and MSKU  = '1831623'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '1408L-15-NB' V: R:
ERROR - 2019-02-01 15:19:51 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253351
					    				and MTYPE = 'I'
								    	and MSKU  = '1831666'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = '1408L-38-NB' V: R:
ERROR - 2019-02-01 15:19:52 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253351
					    				and MTYPE = 'I'
								    	and MSKU  = '1831534'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = '1408L-71P-NB' V: R:
ERROR - 2019-02-01 15:19:53 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253351
					    				and MTYPE = 'I'
								    	and MSKU  = '1673998'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = '26362' V: R:
ERROR - 2019-02-01 15:19:53 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253283
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-01 15:19:54 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253283
					    				and MTYPE = 'I'
								    	and MSKU  = '1907328'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2358V60RGTCK-TC' V: R:
ERROR - 2019-02-01 15:19:55 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253283
					    				and MTYPE = 'I'
								    	and MSKU  = '1907336'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2358V70LGTCK-TC' V: R:
ERROR - 2019-02-01 15:19:55 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253283
					    				and MTYPE = 'I'
								    	and MSKU  = '1907352'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2358V10SGTCK-TC' V: R:
ERROR - 2019-02-01 15:19:56 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253283
					    				and MTYPE = 'I'
								    	and MSKU  = '1673998'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '26362' V: R:
ERROR - 2019-02-01 15:19:57 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253590
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-01 15:19:57 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253590
					    				and MTYPE = 'I'
								    	and MSKU  = '1800817'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '236-04-WESSMO-BS' V: R:
ERROR - 2019-02-01 15:19:58 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253590
					    				and MTYPE = 'I'
								    	and MSKU  = '1673998'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '26362' V: R:
ERROR - 2019-02-01 15:19:59 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253827
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => TIGHT DELIVERY TO THE BASEMENT, WILL NEED FEET REMOVED.
        )

)

ERROR - 2019-02-01 15:19:59 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253827
					    				and MTYPE = 'I'
								    	and MSKU  = '9827692'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'P26ZF10FS-SI' V: R:
ERROR - 2019-02-01 15:20:00 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253827
					    				and MTYPE = 'I'
								    	and MSKU  = '9827718'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '85812-335-1' V: R:
ERROR - 2019-02-01 15:20:01 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253064
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-01 15:20:02 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253064
					    				and MTYPE = 'I'
								    	and MSKU  = '1873555'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'UTW210300-MB' V: R:
ERROR - 2019-02-01 15:20:02 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253064
					    				and MTYPE = 'I'
								    	and MSKU  = '1673998'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '26362' V: R:
ERROR - 2019-02-01 15:20:03 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253064
					    				and MTYPE = 'I'
								    	and MSKU  = '1873636'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'UTW210000-MB' V: R:
ERROR - 2019-02-01 15:20:04 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253064
					    				and MTYPE = 'I'
								    	and MSKU  = '1867172'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'K973M-L1-1K-RG' V: R:
ERROR - 2019-02-01 15:20:04 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253831
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-01 15:20:05 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253831
					    				and MTYPE = 'I'
								    	and MSKU  = '1076817'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-123014A-SCB' V: R:
ERROR - 2019-02-01 15:20:06 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253831
					    				and MTYPE = 'I'
								    	and MSKU  = '1076825'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-123083A-SCB' V: R:
ERROR - 2019-02-01 15:20:06 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253831
					    				and MTYPE = 'F'
								    	and MSKU  = '1076833'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-123053A-SCB' V: R:
ERROR - 2019-02-01 15:20:07 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 248697
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>        No Instructions Provided
        )

)

ERROR - 2019-02-01 15:20:08 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 248697
					    				and MTYPE = 'I'
								    	and MSKU  = '1808338'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1387-523-MP' V: R:
ERROR - 2019-02-01 15:20:09 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 248697
					    				and MTYPE = 'I'
								    	and MSKU  = '1808389'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1388-523-MP' V: R:
ERROR - 2019-02-01 15:20:09 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 248699
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>        No Instructions Provided
        )

)

ERROR - 2019-02-01 15:20:10 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 248699
					    				and MTYPE = 'I'
								    	and MSKU  = '1912402'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'ED5QFB' V: R:
ERROR - 2019-02-01 15:20:11 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 248699
					    				and MTYPE = 'I'
								    	and MSKU  = '1931342'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'ED5QHB-R' V: R:
ERROR - 2019-02-01 15:20:11 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 248699
					    				and MTYPE = 'I'
								    	and MSKU  = '1931512'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'ED5QRS-R' V: R:
ERROR - 2019-02-01 15:20:12 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253417
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:20:13 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253417
					    				and MTYPE = 'I'
								    	and MSKU  = '1954008'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680P-SOF-AG' V: R:
ERROR - 2019-02-01 15:20:13 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253417
					    				and MTYPE = 'I'
								    	and MSKU  = '1673998'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '26362' V: R:
ERROR - 2019-02-01 15:20:14 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253417
					    				and MTYPE = 'I'
								    	and MSKU  = '1954024'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680P-R-AG' V: R:
ERROR - 2019-02-01 15:20:15 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 252898
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:20:15 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252898
					    				and MTYPE = 'I'
								    	and MSKU  = '1561928'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'OP2QHF' V: R:
ERROR - 2019-02-01 15:20:16 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252898
					    				and MTYPE = 'I'
								    	and MSKU  = '1561936'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'OP2QKR' V: R:
ERROR - 2019-02-01 15:31:36 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:36 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:31:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:31:38 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN2
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:31:39 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:39 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:31:40 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:40 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:31:40 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN2
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:31:41 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100593'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 15:31:42 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100593' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100593
            [RHDATE] => 20190201
            [RHTRUC] => 51
            [RHDRIV] => Austin Williams
            [RHHELP] => Austin Williams
            [RHSTOP] => 5
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => C
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 63205
            [RHHLPEMP] => 63205
            [RHTRNAME] => VAN2
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Driver now loading
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 15:31:42 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:42 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:31:50 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:50 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:31:51 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:51 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:31:51 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:51 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:31:52 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN2
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:31:53 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100593'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 15:31:54 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100593' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100593
            [RHDATE] => 20190201
            [RHTRUC] => 51
            [RHDRIV] => Austin Williams
            [RHHELP] => Austin Williams
            [RHSTOP] => 5
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => C
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 63205
            [RHHLPEMP] => 63205
            [RHTRNAME] => VAN2
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Driver now loading
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 15:31:55 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:55 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:31:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:31:59 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:31:59 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:32:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:32:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:32:01 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN2
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:32:02 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-01 15:32:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1834843
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501115.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:32:03 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1937707
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://vcfstage01.vcfcorp.com/en_US/images/sample/1937707.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:32:04 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1630938
)
 R:
ERROR - 2019-02-01 15:32:05 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1897578
)
 R:
ERROR - 2019-02-01 15:32:05 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1818465
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/420943.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:32:06 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1818473
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/420946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-01 15:32:07 --> Select (Calc: 0.00)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100593 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 0
            [RHMILES] => 0
            [RHDATE] => 20190201
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-01 15:32:08 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 19
            [RSINVNO] => 753245
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1834843
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:32:08 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 251845
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1937707
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:32:09 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 239311
            [RSINSEQ] => 20
            [RSINSSS] => 6
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1630938
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:32:09 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 240333
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1897578
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:32:10 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190201' AND (DMEFFEND = 0 OR DMEFFEND >= '20190201')
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 0
            [RSINVNO] => 0
            [RSINSEQ] => 0
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 0
            [RSPRCTP] => 
            [RSITSSQ] => 0
            [RSPRBACT] => L
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 152359
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 165
            [RSINVNO] => 13034
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1818465
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 165
            [RSINVNO] => 13034
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1818473
            [RSPRCTP] => S
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-01 15:32:11 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:32:11 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:32:12 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:32:12 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:32:13 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100593
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-01 15:32:14 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 753245
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:32:14 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 753245
					    				and MTYPE = 'S'
								    	and MSKU  = '1834843'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '1126-CPB420' V: R:
ERROR - 2019-02-01 15:32:15 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 251845
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:32:16 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 251845
					    				and MTYPE = 'S'
								    	and MSKU  = '1937707'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1861R-P4SF9KH' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => SCRATCHES ON TABLE TOP
        )

)

ERROR - 2019-02-01 15:32:17 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 239311
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:32:17 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 239311
					    				and MTYPE = 'S'
								    	and MSKU  = '1630938'
								    	and MSSEQ = 020
								    	and MSBSQ = 06
								    	and MITEM = '1240-49-BSC' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 1/22/1019 12:09 CCI CHAISE IS BOUNCING WHEN YOU SIT IN IT AND YOU
        )

    [1] => stdClass Object
        (
            [MTEXT] => SINK IN IT MARKG@CC
        )

)

ERROR - 2019-02-01 15:32:18 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 240333
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:32:19 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 240333
					    				and MTYPE = 'S'
								    	and MSKU  = '1897578'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'UJP546255NF-CG' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => LOUD SQUEEK WHEN STTING ON LVST
        )

    [1] => stdClass Object
        (
            [MTEXT] => 1/4/19 DAKOTA@825 NO ONE HOME. 235-250P.
        )

    [2] => stdClass Object
        (
            [MTEXT] => LOUD SQUEEK WHEN STTING ON LVST
        )

)

ERROR - 2019-02-01 15:32:19 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 13034
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-01 15:32:20 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 13034
					    				and MTYPE = 'S'
								    	and MSKU  = '1818465'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680-R-AM' V: R:
ERROR - 2019-02-01 15:32:21 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 13034
					    				and MTYPE = 'S'
								    	and MSKU  = '1818473'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680-SOF-AM' V: R:
ERROR - 2019-02-01 15:32:21 --> Select (Calc: 0.00)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100593
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTOP] => 5
            [RSPRBACT] => L
        )

)

ERROR - 2019-02-01 15:32:22 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 15:32:23 --> Select (Calc: 0.00)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'VCF'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'VCF' and RHDATE = '20190201')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => VAN3
            [CTCURMILES] => 56444
        )

    [1] => stdClass Object
        (
            [CTTRUKNAME] => 162083
            [CTCURMILES] => 92172
        )

    [2] => stdClass Object
        (
            [CTTRUKNAME] => 625992
            [CTCURMILES] => 108860
        )

    [3] => stdClass Object
        (
            [CTTRUKNAME] => 635841
            [CTCURMILES] => 28886
        )

    [4] => stdClass Object
        (
            [CTTRUKNAME] => 635842
            [CTCURMILES] => 108434
        )

    [5] => stdClass Object
        (
            [CTTRUKNAME] => 635854
            [CTCURMILES] => 110398
        )

    [6] => stdClass Object
        (
            [CTTRUKNAME] => 635857
            [CTCURMILES] => 100562
        )

)

ERROR - 2019-02-01 15:32:23 --> Select (Calc: 0.00)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-01 15:32:24 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:25 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:26 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-01 15:32:27 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:28 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-01 15:32:28 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:29 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-01 15:32:30 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:31 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:32 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:32 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:33 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:34 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:35 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:36 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-01 15:32:38 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:32:38 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:32:39 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:32:39 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:32:52 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:32:52 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:32:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:32:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:02 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:02 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:09 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:09 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:19 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:19 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:20 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:20 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:22 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:22 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:29 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:29 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:33:30 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:33:30 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:34:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:34:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:36:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:36:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:36:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:36:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:36:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:36:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:36:26 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:36:26 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:36:27 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100593
            [RHCMP] => VCF
            [SMMRKT] => OHVCO
            [RHTRUC] => 51
            [RHSTAG] => C
            [RADRVCMPD] => 0
            [RHTRNAME] => VAN2
            [RHMILES] => 0
            [RADRVUSER] => 4171528395
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:36:28 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100593'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 15:36:28 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100593' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100593
            [RHDATE] => 20190201
            [RHTRUC] => 51
            [RHDRIV] => Austin Williams
            [RHHELP] => Austin Williams
            [RHSTOP] => 5
            [RHCUBE] => 0
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => C
            [RHSTAT] => RSVER
            [RHCMP] => VCF
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 63205
            [RHHLPEMP] => 63205
            [RHTRNAME] => VAN2
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 0
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 0
            [RHDRVDIST] => 0
            [RHPRJDEP] => 0
            [RHPRJARV] => 0
            [RHPRJMILES] => 0
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Stop 01 loaded
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 15:36:29 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:36:29 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:37:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:37:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-01 15:37:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:37:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-01 15:37:58 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190131
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190201
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190201 AND A.RADATE < 20190209)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100579
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => UST 03
            [RHMILES] => 0
            [RADRVUSER] => 7135528975
            [RADATE] => 20190201
        )

)

ERROR - 2019-02-01 15:37:59 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100579'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190201' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-01 15:38:00 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100579' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100579
            [RHDATE] => 20190201
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 9
            [RHCUBE] => 851
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => B
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => UST 03
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => N
            [RHDDROUTE] => 11881501
            [RHDRVSEQ] => 0
            [RHDRVTIM] => 11
            [RHDRVDIST] => 6925
            [RHPRJDEP] => 730
            [RHPRJARV] => 1605
            [RHPRJMILES] => 48
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready to Load: 8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-01 15:38:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-01 15:38:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

