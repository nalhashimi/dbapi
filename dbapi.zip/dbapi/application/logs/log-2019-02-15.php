<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-15 11:13:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-15 11:13:12 --> POST: Array
(
    [username] => dcmobile
    [password] => dcmobile
    [conntype] => ezc
    [liblist] => QTEMP VCFCORPF STOREDEV STOREQA BETADATA VCFMENU STOREPGMS QGPL VCFCOMM LIBHTTPX VALUECITY ASYNC VCFGEN ZMODEDIIP ZMODLIB10 POPUP API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => n
    [dbjob] => DCPORTAL
    [store] => 000
    [pconntimout] => 15
)

