ERROR - 2019-01-25 17:06:22 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-25 17:06:22 --> POST: Array
(
    [Connection:_close

username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pc] => 
    [0] => DCPORTAL
)

ERROR - 2019-01-25 17:08:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-25 17:08:08 --> POST: Array
(
    [Connection:_close

username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pc] => 
    [0] => DCPORTAL
)

ERROR - 2019-01-25 17:08:43 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-25 17:08:43 --> POST: Array
(
    [Connection:_close

username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pc] => 
    [0] => DCPORTAL
)

