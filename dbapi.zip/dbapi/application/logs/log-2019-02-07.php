<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-07 16:05:10 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:05:10 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:05:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:05:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:05:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:05:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:05:17 --> Select (Calc: 0.06)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190206
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190207
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190207 AND A.RADATE < 20190215)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100749
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 7064528947
            [RADATE] => 20190207
        )

)

ERROR - 2019-02-07 16:05:17 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100749'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190207' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-07 16:05:18 --> Select (Calc: 0.01)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100749' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100749
            [RHDATE] => 20190207
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 8
            [RHCUBE] => 865
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11922021
            [RHDRVSEQ] => 1
            [RHDRVTIM] => 10
            [RHDRVDIST] => 5782
            [RHPRJDEP] => 730
            [RHPRJARV] => 2323
            [RHPRJMILES] => 161
            [RHACTDEP] => 1504
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Notified Stop  2
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-07 16:05:19 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:05:19 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-07 16:06:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:06:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:06:26 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:06:26 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:06:27 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:06:27 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-07 16:06:27 --> Select (Calc: 0.02)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190206
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190207
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190207 AND A.RADATE < 20190215)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100749
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 7064528947
            [RADATE] => 20190207
        )

)

ERROR - 2019-02-07 16:06:30 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-07 16:06:30 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867458
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/538888.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:31 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867288
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/526018.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1473522
)
 R:
ERROR - 2019-02-07 16:06:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1803972
)
 R:
ERROR - 2019-02-07 16:06:33 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1869949
)
 R:
ERROR - 2019-02-07 16:06:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1869949
)
 R:
ERROR - 2019-02-07 16:06:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1871676
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/503029.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:35 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1729764
)
 R:
ERROR - 2019-02-07 16:06:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1887033
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1887033_SA_matt_only
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:06:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1887394
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/633468.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1858122
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/476493.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1741845
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/417514.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:38 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776878
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/426333.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776878
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/426333.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776142
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/439529.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776142
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/439529.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:41 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1910566
)
 R:
ERROR - 2019-02-07 16:06:41 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1910566
)
 R:
ERROR - 2019-02-07 16:06:42 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1914049
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643265.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:43 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929992
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/707920.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:43 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1930028
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1930028_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:06:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831593
)
 R:
ERROR - 2019-02-07 16:06:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831615
)
 R:
ERROR - 2019-02-07 16:06:45 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831674
)
 R:
ERROR - 2019-02-07 16:06:45 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831682
)
 R:
ERROR - 2019-02-07 16:06:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831739
)
 R:
ERROR - 2019-02-07 16:06:47 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831755
)
 R:
ERROR - 2019-02-07 16:06:47 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754572
)
 R:
ERROR - 2019-02-07 16:06:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754599
)
 R:
ERROR - 2019-02-07 16:06:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754602
)
 R:
ERROR - 2019-02-07 16:06:49 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754629
)
 R:
ERROR - 2019-02-07 16:06:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754645
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/428443.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754645
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/428443.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 9824384
)
 R:
ERROR - 2019-02-07 16:06:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1332066
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/CW_1332066_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:06:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1332066
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/CW_1332066_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:06:53 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1332422
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/CW_1332422_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:06:53 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1818473
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/420946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:06:54 --> Select (Calc: 0.01)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100749 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 20190207
            [RHPRJMILES] => 161
            [RHMILES] => 41708
            [RHDATE] => 20190207
            [RHTIMEZONE] => EST
            [RHACTDEP] => 1504
        )

)

ERROR - 2019-02-07 16:06:55 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=01
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867458
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150516
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867288
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150517
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1473522
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150518
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1803972
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150519
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1869949
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150520
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1869949
            [RSPRCTP] => I
            [RSITSSQ] => 1
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150521
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1871676
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150522
        )

)

ERROR - 2019-02-07 16:06:55 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=02
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254215
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1729764
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254215
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1887033
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254215
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1887394
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254215
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1858122
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:06:56 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=03
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254294
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1741845
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:06:57 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=04
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 216576
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1910566
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 216576
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1910566
            [RSPRCTP] => C
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 216576
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1914049
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253354
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776878
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253354
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1776878
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253354
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776142
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253354
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1776142
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:06:57 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=05
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254383
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929992
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254383
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1930028
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:06:58 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=06
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831593
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831615
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831674
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831682
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831739
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831755
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754572
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754599
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [8] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754602
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [9] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754629
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [10] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754645
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [11] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1754645
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [12] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 80
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 9824384
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:06:59 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=07
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332066
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332066
            [RSPRCTP] => D
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332066
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332066
            [RSPRCTP] => E
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332422
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332422
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:06:59 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=08
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254367
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1818473
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:07:00 --> Select (Calc: 0.01)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=01
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RIRTETYP] => D
            [RISTRNO] => 0
            [RIINVNO] => 0
            [RIINSEQ] => 0
            [RIINSSS] => 0
            [RIINSSQ] => 0
            [RIITSEQ] => 0
            [RISKNBR] => 0
            [RIPRCTP] => 
            [RIITSSQ] => 0
            [RISEQ] => 1
            [RIIMAGE] => /DriverCentral/Images/Development/00825_100749_01_1.png
        )

)

ERROR - 2019-02-07 16:07:01 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=02
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:07:01 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=03
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:07:02 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=04
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:07:02 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=05
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:07:03 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=06
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:07:04 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=07
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:07:05 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=08
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:07:05 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253689
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                       ..
        )

)

ERROR - 2019-02-07 16:07:06 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1867458'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KX979M-L1-EL-MB' V: R:
ERROR - 2019-02-07 16:07:07 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1867288'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'K981M-L1-EL-RB' V: R:
ERROR - 2019-02-07 16:07:07 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1473522'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'LY320-153KHF' V: R:
ERROR - 2019-02-07 16:07:08 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1803972'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'LY320-253QKR' V: R:
ERROR - 2019-02-07 16:07:09 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1869949'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = '700600254-3BXLP' V: R:
ERROR - 2019-02-07 16:07:09 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1869949'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = '700600254-3BXLP' V: R:
ERROR - 2019-02-07 16:07:10 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1871676'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = '700753046-6M' V: R:
ERROR - 2019-02-07 16:07:11 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254215
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 2-2-19 CUST WOULD LIKE 1 HOUR CALL AHEAD
        )

)

ERROR - 2019-02-07 16:07:11 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254215
					    				and MTYPE = 'I'
								    	and MSKU  = '1729764'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VCF006-5B' V: R:
ERROR - 2019-02-07 16:07:12 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254215
					    				and MTYPE = 'I'
								    	and MSKU  = '1887033'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'HK12LHQ-B-5M' V: R:
ERROR - 2019-02-07 16:07:13 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254215
					    				and MTYPE = 'I'
								    	and MSKU  = '1887394'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'BB66' V: R:
ERROR - 2019-02-07 16:07:13 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254215
					    				and MTYPE = 'I'
								    	and MSKU  = '1858122'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FO-229812-RO' V: R:
ERROR - 2019-02-07 16:07:14 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254294
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => ********PLEASE TAKE OLD CHAIR BACK AND CALL STORE 28 FOR
        )

    [1] => stdClass Object
        (
            [MTEXT] => CREDIT MEMO AND TRANSFER TO US KR********************************
        )

    [2] => stdClass Object
        (
            [MTEXT] => *  NO COD COMING FROM OTHER INVOICE KR***************************
        )

    [3] => stdClass Object
        (
            [MTEXT] => *********
        )

)

ERROR - 2019-02-07 16:07:15 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254294
					    				and MTYPE = 'I'
								    	and MSKU  = '1741845'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1323G-50-BK-BB' V: R:
ERROR - 2019-02-07 16:07:16 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253354
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => ***C/M SET UP ON INVOICE #613439. BE
        )

)

ERROR - 2019-02-07 16:07:16 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253354
					    				and MTYPE = 'I'
								    	and MSKU  = '1776878'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '700730109-3MXL' V: R:
ERROR - 2019-02-07 16:07:17 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253354
					    				and MTYPE = 'I'
								    	and MSKU  = '1776878'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '700730109-3MXL' V: R:
ERROR - 2019-02-07 16:07:17 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253354
					    				and MTYPE = 'I'
								    	and MSKU  = '1776142'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '700056204-3BXL' V: R:
ERROR - 2019-02-07 16:07:18 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253354
					    				and MTYPE = 'I'
								    	and MSKU  = '1776142'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '700056204-3BXL' V: R:
ERROR - 2019-02-07 16:07:19 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 216576
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => ***HAS DEL ON INVOICE #630616. BE
        )

)

ERROR - 2019-02-07 16:07:19 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 216576
					    				and MTYPE = 'C'
								    	and MSKU  = '1910566'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '800199-3BXLCK' V: R:
ERROR - 2019-02-07 16:07:20 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 216576
					    				and MTYPE = 'C'
								    	and MSKU  = '1910566'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '800199-3BXLCK' V: R:
ERROR - 2019-02-07 16:07:21 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 216576
					    				and MTYPE = 'C'
								    	and MSKU  = '1914049'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '820573-6MCK' V: R:
ERROR - 2019-02-07 16:07:21 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254383
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>        No Instructions Provided
        )

)

ERROR - 2019-02-07 16:07:22 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254383
					    				and MTYPE = 'I'
								    	and MSKU  = '1929992'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-7071PP-20B-AB' V: R:
ERROR - 2019-02-07 16:07:23 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254383
					    				and MTYPE = 'I'
								    	and MSKU  = '1930028'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-7071PP-30B-AB' V: R:
ERROR - 2019-02-07 16:07:23 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 252941
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-07 16:07:24 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831593'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-05-DB' V: R:
ERROR - 2019-02-07 16:07:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831615'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-71P-DB' V: R:
ERROR - 2019-02-07 16:07:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831674'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-05P-DB' V: R:
ERROR - 2019-02-07 16:07:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831682'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-15-DB' V: R:
ERROR - 2019-02-07 16:07:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831739'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-38-DB' V: R:
ERROR - 2019-02-07 16:07:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831755'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-49PD-DB' V: R:
ERROR - 2019-02-07 16:07:28 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754572'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-56R' V: R:
ERROR - 2019-02-07 16:07:29 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754599'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-6H' V: R:
ERROR - 2019-02-07 16:07:29 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754602'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-6F' V: R:
ERROR - 2019-02-07 16:07:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754629'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-D' V: R:
ERROR - 2019-02-07 16:07:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754645'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-N' V: R:
ERROR - 2019-02-07 16:07:31 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754645'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-N' V: R:
ERROR - 2019-02-07 16:07:32 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '9824384'
								    	and MSSEQ = 080
								    	and MSBSQ = 00
								    	and MITEM = 'KING WAVERLY BLAC' V: R:
ERROR - 2019-02-07 16:07:33 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 247987
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-07 16:07:33 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 247987
					    				and MTYPE = 'D'
								    	and MSKU  = '1332066'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'U8868-AR1-ME-SB' V: R:
ERROR - 2019-02-07 16:07:34 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 247987
					    				and MTYPE = 'D'
								    	and MSKU  = '1332066'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'U8868-AR1-ME-SB' V: R:
ERROR - 2019-02-07 16:07:35 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 247987
					    				and MTYPE = 'D'
								    	and MSKU  = '1332422'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'U8868-AL1-ME-SB' V: R:
ERROR - 2019-02-07 16:07:36 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254367
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 02/04/19***RESELECT***PLEASE REFER TO INVOICE #35-710503/#825-189
        )

    [1] => stdClass Object
        (
            [MTEXT] => 563...PURCHASE ORDER #P1288617=SOFA...CUSTOMER DOESN'T OWE COD...
        )

    [2] => stdClass Object
        (
            [MTEXT] => AMERICA@165
        )

)

ERROR - 2019-02-07 16:07:37 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254367
					    				and MTYPE = 'I'
								    	and MSKU  = '1818473'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680-SOF-AM' V: R:
ERROR - 2019-02-07 16:07:37 --> Select (Calc: 0.01)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => D
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => C
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Complete
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => C
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Complete Service
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => C
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Picked Up
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => F
            [MBLPRBSTS] => 9
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Follow Up
            [MBLWRDREQ] => 5
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => H
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Not At Home
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => H
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Not At Home
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 1
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged Merchandise
            [MBLWRDREQ] => 3
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => N
            [MBLPRBSTS] => 1
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Incomplete Service
            [MBLWRDREQ] => 3
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Not On Truck
            [MBLWRDREQ] => 3
        )

    [12] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => N
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Wrong Parts
            [MBLWRDREQ] => 3
        )

    [13] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 3
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Wrong Merchandise
            [MBLWRDREQ] => 5
        )

    [14] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Too Big
            [MBLWRDREQ] => 5
        )

    [15] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => N
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Did Not Pickup
            [MBLWRDREQ] => 5
        )

    [16] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => D
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Deliver
            [MBLWRDREQ] => 0
        )

    [17] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => P
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Pickup
            [MBLWRDREQ] => 0
        )

    [18] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => X
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Transfer
            [MBLWRDREQ] => 0
        )

    [19] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => S
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Start Service
            [MBLWRDREQ] => 0
        )

    [20] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => W
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wrong Address
            [MBLWRDREQ] => 0
        )

    [21] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => X
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Reschedule Stop
            [MBLWRDREQ] => 4
        )

    [22] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => X
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Reschedule Stop
            [MBLWRDREQ] => 4
        )

)

ERROR - 2019-02-07 16:07:38 --> Select (Calc: 0.01)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-07 16:07:39 --> Select (Calc: 0.01)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:40 --> Select (Calc: 0.01)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:41 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-07 16:07:42 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:43 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-07 16:07:44 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:45 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-07 16:07:46 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:47 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:47 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:48 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:49 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:50 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:51 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:52 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:07:53 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:07:53 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:07:54 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:07:54 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-07 16:08:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:08:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:08:43 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:08:43 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:08:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:08:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:09:11 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:09:11 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:09:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:09:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:09:12 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190206
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190207
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190207 AND A.RADATE < 20190215)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100749
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 7064528947
            [RADATE] => 20190207
        )

)

ERROR - 2019-02-07 16:09:13 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100749'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190207' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-07 16:09:14 --> Select (Calc: 0.01)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100749' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100749
            [RHDATE] => 20190207
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 8
            [RHCUBE] => 865
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11922021
            [RHDRVSEQ] => 1
            [RHDRVTIM] => 10
            [RHDRVDIST] => 5782
            [RHPRJDEP] => 730
            [RHPRJARV] => 2323
            [RHPRJMILES] => 161
            [RHACTDEP] => 1504
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Notified Stop  2
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-07 16:09:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:09:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-07 16:09:27 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:09:27 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:09:28 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:09:28 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:09:29 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:09:29 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-07 16:09:30 --> Select (Calc: 0.03)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190206
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190207
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190207 AND A.RADATE < 20190215)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100749
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 7064528947
            [RADATE] => 20190207
        )

)

ERROR - 2019-02-07 16:09:32 --> Select (Calc: 0.00)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-07 16:09:33 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867458
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/538888.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1867288
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/526018.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:35 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1473522
)
 R:
ERROR - 2019-02-07 16:09:35 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1803972
)
 R:
ERROR - 2019-02-07 16:09:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1869949
)
 R:
ERROR - 2019-02-07 16:09:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1869949
)
 R:
ERROR - 2019-02-07 16:09:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1871676
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/503029.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:38 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1729764
)
 R:
ERROR - 2019-02-07 16:09:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1887033
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1887033_SA_matt_only
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:09:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1887394
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/633468.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1858122
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/476493.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1741845
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/417514.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:41 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776878
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/426333.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:42 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776878
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/426333.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:43 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776142
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/439529.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:43 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1776142
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/439529.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1910566
)
 R:
ERROR - 2019-02-07 16:09:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1910566
)
 R:
ERROR - 2019-02-07 16:09:45 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1914049
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/643265.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1929992
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/707920.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1930028
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1930028_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:09:47 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831593
)
 R:
ERROR - 2019-02-07 16:09:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831615
)
 R:
ERROR - 2019-02-07 16:09:48 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831674
)
 R:
ERROR - 2019-02-07 16:09:49 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831682
)
 R:
ERROR - 2019-02-07 16:09:49 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831739
)
 R:
ERROR - 2019-02-07 16:09:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1831755
)
 R:
ERROR - 2019-02-07 16:09:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754572
)
 R:
ERROR - 2019-02-07 16:09:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754599
)
 R:
ERROR - 2019-02-07 16:09:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754602
)
 R:
ERROR - 2019-02-07 16:09:53 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754629
)
 R:
ERROR - 2019-02-07 16:09:53 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754645
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/428443.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:54 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1754645
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/428443.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:55 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 9824384
)
 R:
ERROR - 2019-02-07 16:09:55 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1332066
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/CW_1332066_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:09:56 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1332066
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/CW_1332066_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:09:56 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1332422
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/CW_1332422_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-07 16:09:57 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1818473
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/420946.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-07 16:09:58 --> Select (Calc: 0.00)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100749 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 20190207
            [RHPRJMILES] => 161
            [RHMILES] => 41708
            [RHDATE] => 20190207
            [RHTIMEZONE] => EST
            [RHACTDEP] => 1504
        )

)

ERROR - 2019-02-07 16:09:58 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=01
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867458
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150516
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1867288
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150517
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1473522
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150518
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1803972
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150519
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1869949
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150520
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1869949
            [RSPRCTP] => I
            [RSITSSQ] => 1
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150521
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253689
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1871676
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 150522
        )

)

ERROR - 2019-02-07 16:09:59 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=02
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254215
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1729764
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254215
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1887033
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254215
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1887394
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254215
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1858122
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:10:00 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=03
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254294
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1741845
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:10:01 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=04
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 216576
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1910566
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 216576
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1910566
            [RSPRCTP] => C
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 216576
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1914049
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253354
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776878
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253354
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1776878
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253354
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1776142
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253354
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1776142
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:10:01 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=05
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254383
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1929992
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254383
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1930028
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:10:02 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=06
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831593
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831615
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831674
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831682
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831739
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1831755
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754572
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754599
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [8] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754602
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [9] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754629
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [10] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1754645
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [11] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1754645
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [12] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 252941
            [RSINSEQ] => 80
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 0
            [RSSKNBR] => 9824384
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:10:02 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=07
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332066
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332066
            [RSPRCTP] => D
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332066
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332066
            [RSPRCTP] => E
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332422
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 247987
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1332422
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:10:03 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190207' AND (DMEFFEND = 0 OR DMEFFEND >= '20190207')
                    WHERE RSSTORE=00825
                    AND RSROUT=100749
                    AND RSSTOP=08
                    AND RSRTETYP='D' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254367
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1818473
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-07 16:10:04 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=01
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:Array
(
    [0] => stdClass Object
        (
            [RIRTETYP] => D
            [RISTRNO] => 0
            [RIINVNO] => 0
            [RIINSEQ] => 0
            [RIINSSS] => 0
            [RIINSSQ] => 0
            [RIITSEQ] => 0
            [RISKNBR] => 0
            [RIPRCTP] => 
            [RIITSSQ] => 0
            [RISEQ] => 1
            [RIIMAGE] => /DriverCentral/Images/Development/00825_100749_01_1.png
        )

)

ERROR - 2019-02-07 16:10:05 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=02
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:10:05 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=03
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:10:06 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=04
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:10:06 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=05
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:10:07 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=06
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:10:08 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=07
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:10:09 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100749
                    AND RISTOP=08
                    AND RIRTETYP='D'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-07 16:10:09 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253689
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>                       ..
        )

)

ERROR - 2019-02-07 16:10:10 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1867458'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KX979M-L1-EL-MB' V: R:
ERROR - 2019-02-07 16:10:11 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1867288'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'K981M-L1-EL-RB' V: R:
ERROR - 2019-02-07 16:10:11 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1473522'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'LY320-153KHF' V: R:
ERROR - 2019-02-07 16:10:12 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1803972'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'LY320-253QKR' V: R:
ERROR - 2019-02-07 16:10:13 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1869949'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = '700600254-3BXLP' V: R:
ERROR - 2019-02-07 16:10:13 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1869949'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = '700600254-3BXLP' V: R:
ERROR - 2019-02-07 16:10:14 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253689
					    				and MTYPE = 'I'
								    	and MSKU  = '1871676'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = '700753046-6M' V: R:
ERROR - 2019-02-07 16:10:15 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254215
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 2-2-19 CUST WOULD LIKE 1 HOUR CALL AHEAD
        )

)

ERROR - 2019-02-07 16:10:15 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254215
					    				and MTYPE = 'I'
								    	and MSKU  = '1729764'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'VCF006-5B' V: R:
ERROR - 2019-02-07 16:10:16 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254215
					    				and MTYPE = 'I'
								    	and MSKU  = '1887033'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'HK12LHQ-B-5M' V: R:
ERROR - 2019-02-07 16:10:17 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254215
					    				and MTYPE = 'I'
								    	and MSKU  = '1887394'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'BB66' V: R:
ERROR - 2019-02-07 16:10:17 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254215
					    				and MTYPE = 'I'
								    	and MSKU  = '1858122'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'FO-229812-RO' V: R:
ERROR - 2019-02-07 16:10:18 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254294
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => ********PLEASE TAKE OLD CHAIR BACK AND CALL STORE 28 FOR
        )

    [1] => stdClass Object
        (
            [MTEXT] => CREDIT MEMO AND TRANSFER TO US KR********************************
        )

    [2] => stdClass Object
        (
            [MTEXT] => *  NO COD COMING FROM OTHER INVOICE KR***************************
        )

    [3] => stdClass Object
        (
            [MTEXT] => *********
        )

)

ERROR - 2019-02-07 16:10:19 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254294
					    				and MTYPE = 'I'
								    	and MSKU  = '1741845'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1323G-50-BK-BB' V: R:
ERROR - 2019-02-07 16:10:20 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253354
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => ***C/M SET UP ON INVOICE #613439. BE
        )

)

ERROR - 2019-02-07 16:10:20 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253354
					    				and MTYPE = 'I'
								    	and MSKU  = '1776878'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '700730109-3MXL' V: R:
ERROR - 2019-02-07 16:10:21 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253354
					    				and MTYPE = 'I'
								    	and MSKU  = '1776878'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '700730109-3MXL' V: R:
ERROR - 2019-02-07 16:10:22 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253354
					    				and MTYPE = 'I'
								    	and MSKU  = '1776142'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '700056204-3BXL' V: R:
ERROR - 2019-02-07 16:10:22 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253354
					    				and MTYPE = 'I'
								    	and MSKU  = '1776142'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '700056204-3BXL' V: R:
ERROR - 2019-02-07 16:10:23 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 216576
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => ***HAS DEL ON INVOICE #630616. BE
        )

)

ERROR - 2019-02-07 16:10:24 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 216576
					    				and MTYPE = 'C'
								    	and MSKU  = '1910566'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '800199-3BXLCK' V: R:
ERROR - 2019-02-07 16:10:24 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 216576
					    				and MTYPE = 'C'
								    	and MSKU  = '1910566'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '800199-3BXLCK' V: R:
ERROR - 2019-02-07 16:10:25 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 216576
					    				and MTYPE = 'C'
								    	and MSKU  = '1914049'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '820573-6MCK' V: R:
ERROR - 2019-02-07 16:10:26 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254383
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] =>        No Instructions Provided
        )

)

ERROR - 2019-02-07 16:10:26 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254383
					    				and MTYPE = 'I'
								    	and MSKU  = '1929992'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-7071PP-20B-AB' V: R:
ERROR - 2019-02-07 16:10:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254383
					    				and MTYPE = 'I'
								    	and MSKU  = '1930028'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-7071PP-30B-AB' V: R:
ERROR - 2019-02-07 16:10:28 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 252941
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-07 16:10:28 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831593'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-05-DB' V: R:
ERROR - 2019-02-07 16:10:29 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831615'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-71P-DB' V: R:
ERROR - 2019-02-07 16:10:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831674'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-05P-DB' V: R:
ERROR - 2019-02-07 16:10:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831682'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-15-DB' V: R:
ERROR - 2019-02-07 16:10:31 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831739'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-38-DB' V: R:
ERROR - 2019-02-07 16:10:32 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1831755'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '1241CP-49PD-DB' V: R:
ERROR - 2019-02-07 16:10:32 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754572'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-56R' V: R:
ERROR - 2019-02-07 16:10:33 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754599'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-6H' V: R:
ERROR - 2019-02-07 16:10:33 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754602'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-6F' V: R:
ERROR - 2019-02-07 16:10:34 --> Select (Calc: 0.01)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754629'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-D' V: R:
ERROR - 2019-02-07 16:10:35 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754645'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-N' V: R:
ERROR - 2019-02-07 16:10:36 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '1754645'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'B00280-N' V: R:
ERROR - 2019-02-07 16:10:36 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 252941
					    				and MTYPE = 'I'
								    	and MSKU  = '9824384'
								    	and MSSEQ = 080
								    	and MSBSQ = 00
								    	and MITEM = 'KING WAVERLY BLAC' V: R:
ERROR - 2019-02-07 16:10:37 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 247987
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-07 16:10:38 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 247987
					    				and MTYPE = 'D'
								    	and MSKU  = '1332066'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'U8868-AR1-ME-SB' V: R:
ERROR - 2019-02-07 16:10:38 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 247987
					    				and MTYPE = 'D'
								    	and MSKU  = '1332066'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'U8868-AR1-ME-SB' V: R:
ERROR - 2019-02-07 16:10:39 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 247987
					    				and MTYPE = 'D'
								    	and MSKU  = '1332422'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'U8868-AL1-ME-SB' V: R:
ERROR - 2019-02-07 16:10:40 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254367
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 02/04/19***RESELECT***PLEASE REFER TO INVOICE #35-710503/#825-189
        )

    [1] => stdClass Object
        (
            [MTEXT] => 563...PURCHASE ORDER #P1288617=SOFA...CUSTOMER DOESN'T OWE COD...
        )

    [2] => stdClass Object
        (
            [MTEXT] => AMERICA@165
        )

)

ERROR - 2019-02-07 16:10:40 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254367
					    				and MTYPE = 'I'
								    	and MSKU  = '1818473'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-6680-SOF-AM' V: R:
ERROR - 2019-02-07 16:10:41 --> Select (Calc: 0.00)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => D
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => A
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Stop
            [MBLWRDREQ] => 0
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => C
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Complete
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => C
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Complete Service
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => C
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Picked Up
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => F
            [MBLPRBSTS] => 9
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Follow Up
            [MBLWRDREQ] => 5
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => H
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Not At Home
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => H
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Not At Home
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 1
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged Merchandise
            [MBLWRDREQ] => 3
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => N
            [MBLPRBSTS] => 1
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Incomplete Service
            [MBLWRDREQ] => 3
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Not On Truck
            [MBLWRDREQ] => 3
        )

    [12] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => N
            [MBLPRBSTS] => 2
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Wrong Parts
            [MBLWRDREQ] => 3
        )

    [13] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 3
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Wrong Merchandise
            [MBLWRDREQ] => 5
        )

    [14] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => N
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Too Big
            [MBLWRDREQ] => 5
        )

    [15] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => N
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Did Not Pickup
            [MBLWRDREQ] => 5
        )

    [16] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => D
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Deliver
            [MBLWRDREQ] => 0
        )

    [17] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => P
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Pickup
            [MBLWRDREQ] => 0
        )

    [18] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => X
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Transfer
            [MBLWRDREQ] => 0
        )

    [19] => stdClass Object
        (
            [MBLPUDEL] => S
            [MBLPRBACT] => S
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Start Service
            [MBLWRDREQ] => 0
        )

    [20] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => W
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wrong Address
            [MBLWRDREQ] => 0
        )

    [21] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => X
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Reschedule Stop
            [MBLWRDREQ] => 4
        )

    [22] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => X
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Reschedule Stop
            [MBLWRDREQ] => 4
        )

)

ERROR - 2019-02-07 16:10:42 --> Select (Calc: 0.01)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-07 16:10:43 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:44 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:44 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-07 16:10:45 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:46 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-07 16:10:47 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:48 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-07 16:10:48 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:49 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:50 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:51 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:52 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:52 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:53 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:54 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-07 16:10:56 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:10:56 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:10:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:10:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-07 16:11:17 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:11:17 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:14:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:14:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:17:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:17:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:20:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:20:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:23:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:23:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:25:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:25:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:28:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:28:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:31:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:31:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:33:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:33:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:36:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:36:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:39:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:39:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:42:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:42:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:45:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:45:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:48:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:48:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:51:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:51:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:54:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:54:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 16:57:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 16:57:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-07 17:00:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-07 17:00:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

