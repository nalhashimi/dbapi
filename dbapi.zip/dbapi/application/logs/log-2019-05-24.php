<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-24 11:33:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-05-24 11:33:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-05-24 11:33:14 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-05-24 11:33:15 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
