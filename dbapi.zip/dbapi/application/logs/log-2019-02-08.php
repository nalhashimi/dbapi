<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-02-08 08:44:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 08:44:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 08:47:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 08:47:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 08:50:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 08:50:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 08:53:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 08:53:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 08:56:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 08:56:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 08:59:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 08:59:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:01:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:01:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:04:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:04:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:07:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:07:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:09:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:09:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:12:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:12:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:15:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:15:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:18:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:18:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:21:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:21:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:24:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:24:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:26:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:26:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:29:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:29:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:32:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:32:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:35:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:35:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:38:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:38:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:41:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:41:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:43:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:43:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:43:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 09:43:00 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 09:46:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:46:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:49:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:49:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:52:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:52:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:55:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:55:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 09:58:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 09:58:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:01:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:01:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:01:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:01:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:01:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:01:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:01:00 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:01:00 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-02-08 10:04:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:04:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:04:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:04:00 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:07:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:07:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:07:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:07:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:07:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:07:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:07:00 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:07:00 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-02-08 10:10:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:10:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:10:01 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:10:01 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:13:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:13:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:13:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:13:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:13:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:13:00 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:13:00 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-02-08 10:13:00 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-02-08 10:50:02 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:50:02 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:50:03 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:50:03 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-08 10:50:05 --> Select (Calc: 0.18)SELECT COUNT(*) AS MSGCOUNT
                FROM RTSMBLACT
                WHERE RMSTR# = 825
                AND RMROUT = 100749 V: R:Array
(
    [0] => stdClass Object
        (
            [MSGCOUNT] => 931
        )

)

ERROR - 2019-02-08 10:50:06 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:50:06 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:50:07 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:50:07 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-08 10:50:08 --> Select (Calc: 0.42)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190207
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190208
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190208 AND A.RADATE < 20190216)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100784
            [RHCMP] => KCLLC
            [SMMRKT] => OHVCO
            [RHTRUC] => 7
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => KHAT1
            [RHMILES] => 0
            [RADRVUSER] => 7280528487
            [RADATE] => 20190208
        )

)

ERROR - 2019-02-08 10:50:09 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:50:09 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:50:11 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:50:11 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-08 10:50:11 --> Select (Calc: 0.01)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190207
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190208
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190208 AND A.RADATE < 20190216)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100784
            [RHCMP] => KCLLC
            [SMMRKT] => OHVCO
            [RHTRUC] => 7
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => KHAT1
            [RHMILES] => 0
            [RADRVUSER] => 7280528487
            [RADATE] => 20190208
        )

)

ERROR - 2019-02-08 10:50:13 --> Select (Calc: 0.11)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100784'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190208' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-08 10:50:14 --> Select (Calc: 0.03)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100784' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100784
            [RHDATE] => 20190208
            [RHTRUC] => 7
            [RHDRIV] => D285 SAEDASSAF
            [RHHELP] => D285 SAEDASSAF
            [RHSTOP] => 13
            [RHCUBE] => 1068
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => B
            [RHSTAT] => RSVER
            [RHCMP] => KCLLC
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 90
            [RHHLPEMP] => 90
            [RHTRNAME] => KHAT1
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11920421
            [RHDRVSEQ] => 13
            [RHDRVTIM] => 20
            [RHDRVDIST] => 16256
            [RHPRJDEP] => 730
            [RHPRJARV] => 1805
            [RHPRJMILES] => 89
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready to Load: 8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-08 10:50:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:50:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-08 10:51:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:51:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:51:02 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:51:02 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:51:02 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:51:02 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:51:03 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190207
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190208
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190208 AND A.RADATE < 20190216)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100784
            [RHCMP] => KCLLC
            [SMMRKT] => OHVCO
            [RHTRUC] => 7
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => KHAT1
            [RHMILES] => 0
            [RADRVUSER] => 7280528487
            [RADATE] => 20190208
        )

)

ERROR - 2019-02-08 10:51:04 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100784'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190208' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-02-08 10:51:04 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100784' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100784
            [RHDATE] => 20190208
            [RHTRUC] => 7
            [RHDRIV] => D285 SAEDASSAF
            [RHHELP] => D285 SAEDASSAF
            [RHSTOP] => 13
            [RHCUBE] => 1068
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => B
            [RHSTAT] => RSVER
            [RHCMP] => KCLLC
            [RHMILES] => 0
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 90
            [RHHLPEMP] => 90
            [RHTRNAME] => KHAT1
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11920421
            [RHDRVSEQ] => 13
            [RHDRVTIM] => 20
            [RHDRVDIST] => 16256
            [RHPRJDEP] => 730
            [RHPRJARV] => 1805
            [RHPRJMILES] => 89
            [RHACTDEP] => 0
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready to Load: 8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-02-08 10:51:05 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:51:05 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-08 10:51:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:51:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:51:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:51:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:51:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:51:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-08 10:51:17 --> Select (Calc: 0.02)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190207
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190208
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190208 AND A.RADATE < 20190216)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100784
            [RHCMP] => KCLLC
            [SMMRKT] => OHVCO
            [RHTRUC] => 7
            [RHSTAG] => B
            [RADRVCMPD] => 0
            [RHTRNAME] => KHAT1
            [RHMILES] => 0
            [RADRVUSER] => 7280528487
            [RADATE] => 20190208
        )

)

ERROR - 2019-02-08 10:51:22 --> Select (Calc: 0.01)SELECT SNAME, SADD1, SCITY, SSTCD, SZIPCD, SMRGL#, SMCOMP
            FROM VALUECITY/STRMST
            WHERE STRNBR=825 AND SMLOC#=1 V: R:Array
(
    [0] => stdClass Object
        (
            [SNAME] => Columbus Central Delivery
            [SADD1] => 3232 Alum Creek Dr
            [SCITY] => Columbus
            [SSTCD] => OH
            [SZIPCD] => 432070000
            [SMRGL#] => 6144494495
            [SMCOMP] => V
        )

)

ERROR - 2019-02-08 10:51:22 --> Select (Calc: 0.03)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1935313
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/704083.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:23 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1935356
)
 R:
ERROR - 2019-02-08 10:51:24 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1935402
)
 R:
ERROR - 2019-02-08 10:51:24 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1935305
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/704095.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:25 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1824309
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501193.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:26 --> Select (Calc: 0.05)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1824627
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501329.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:26 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1824627
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501329.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:27 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933515
)
 R:
ERROR - 2019-02-08 10:51:27 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933558
)
 R:
ERROR - 2019-02-08 10:51:28 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933574
)
 R:
ERROR - 2019-02-08 10:51:29 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1927922
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/543738.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:29 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1928678
)
 R:
ERROR - 2019-02-08 10:51:30 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1473425
)
 R:
ERROR - 2019-02-08 10:51:30 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1803972
)
 R:
ERROR - 2019-02-08 10:51:31 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1824309
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501193.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1824627
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501329.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:32 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1824627
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501329.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:33 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1824627
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501329.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1824627
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/501329.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:34 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933558
)
 R:
ERROR - 2019-02-08 10:51:35 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933647
)
 R:
ERROR - 2019-02-08 10:51:36 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933744
)
 R:
ERROR - 2019-02-08 10:51:36 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743244
)
 R:
ERROR - 2019-02-08 10:51:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743368
)
 R:
ERROR - 2019-02-08 10:51:37 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743376
)
 R:
ERROR - 2019-02-08 10:51:38 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743384
)
 R:
ERROR - 2019-02-08 10:51:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743392
)
 R:
ERROR - 2019-02-08 10:51:39 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743406
)
 R:
ERROR - 2019-02-08 10:51:40 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743414
)
 R:
ERROR - 2019-02-08 10:51:41 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1928473
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/378678.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:42 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1927906
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/378678.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:42 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1945963
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1945963_SAO
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:51:43 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1901168
)
 R:
ERROR - 2019-02-08 10:51:44 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1901184
)
 R:
ERROR - 2019-02-08 10:51:45 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1901214
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/654627.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:45 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1901214
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/654627.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:46 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1901214
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/654627.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:47 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1901214
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/654627.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:47 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1800213
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/483081.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:48 --> Select (Calc: 0.03)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1741748
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1741748_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:51:49 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888048
)
 R:
ERROR - 2019-02-08 10:51:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888072
)
 R:
ERROR - 2019-02-08 10:51:50 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1887912
)
 R:
ERROR - 2019-02-08 10:51:51 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1887939
)
 R:
ERROR - 2019-02-08 10:51:52 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1887998
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/637516.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:52 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1888005
)
 R:
ERROR - 2019-02-08 10:51:53 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1868543
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1868543_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:51:54 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1868543
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/H_DW_1868543_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:51:54 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1903535
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/652322.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:55 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1903535
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/652322.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:56 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1903535
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/652322.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:56 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1903535
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/652322.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:57 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1903535
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/652322.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:51:57 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933523
)
 R:
ERROR - 2019-02-08 10:51:58 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933566
)
 R:
ERROR - 2019-02-08 10:51:59 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1933582
)
 R:
ERROR - 2019-02-08 10:51:59 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1596624
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/284611.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:52:00 --> Select (Calc: 0.02)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1906992
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1906992_SA
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:52:01 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1729764
)
 R:
ERROR - 2019-02-08 10:52:01 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1886908
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1886908_SA_matt_only
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:52:02 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1449117
)
 R:
ERROR - 2019-02-08 10:52:02 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1449133
)
 R:
ERROR - 2019-02-08 10:52:03 --> Select (Calc: 0.06)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1449338
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/RP_1276522_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:52:04 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1449303
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/J_1276514_S
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:52:05 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743198
)
 R:
ERROR - 2019-02-08 10:52:05 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1743236
)
 R:
ERROR - 2019-02-08 10:52:06 --> Select (Calc: 0.00)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1918117
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/662740.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:52:07 --> Select (Calc: 0.03)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1890379
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://s7d4.scene7.com/is/image/ASF/DW_1890379_S_Accents
            [WPIMGWIDTH] => wid=###
            [WPIMGHIGH] => hei=###
        )

)

ERROR - 2019-02-08 10:52:07 --> Select (Calc: 0.01)
            SELECT CONCAT(TRIM(W.WPIMGURL), S.SIIMGNAME) AS URL, TRIM(W.WPIMGWIDTH) AS WPIMGWIDTH, TRIM(W.WPIMGHIGH) AS WPIMGHIGH
            FROM SKUWEBIMG S
            JOIN WEBIMGDEF W ON W.WPIMGTYPE = S.SIIMGTYPE
            WHERE S.SIIMGNAME <> '' AND S.SISKUNBR=?
            ORDER BY W.WPSEQUENCE
            FETCH FIRST 1 ROWS ONLY V:Array
(
    [0] => 1890417
)
 R:Array
(
    [0] => stdClass Object
        (
            [URL] => http://content.valuecityfurniture.com/ProductImages/0/642965.jpg
            [WPIMGWIDTH] => 
            [WPIMGHIGH] => 
        )

)

ERROR - 2019-02-08 10:52:08 --> Select (Calc: 0.03)SELECT TRIM(H.RHSEAL) AS RHSEAL, A.RADRVSTRD, H.RHPRJMILES, H.RHMILES, H.RHDATE, H.RHTIMEZONE, H.RHACTDEP
             FROM RTSHDR H
             JOIN RTSAPRVAL A ON (H.RHSTR#=A.RASTR# AND H.RHROUT=A.RAROUT)
             WHERE RASTR#=00825 AND RAROUT=100784 V: R:Array
(
    [0] => stdClass Object
        (
            [RHSEAL] => 
            [RADRVSTRD] => 0
            [RHPRJMILES] => 89
            [RHMILES] => 0
            [RHDATE] => 20190208
            [RHTIMEZONE] => EST
            [RHACTDEP] => 0
        )

)

ERROR - 2019-02-08 10:52:09 --> Select (Calc: 0.10)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=01
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254456
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1935313
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254456
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1935356
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254456
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1935402
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254456
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1935305
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254456
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1824309
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254456
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1824627
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254456
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1824627
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:10 --> Select (Calc: 0.01)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=02
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933558
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933647
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933744
            [RSPRCTP] => C
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933515
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933558
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933574
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1927922
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 60
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1928678
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [8] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1473425
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [9] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1803972
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [10] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 80
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1824309
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [11] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1824627
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [12] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1824627
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [13] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 2
            [RSITSEQ] => 2
            [RSSKNBR] => 1824627
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [14] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253993
            [RSINSEQ] => 90
            [RSINSSS] => 0
            [RSINSSQ] => 3
            [RSITSEQ] => 2
            [RSSKNBR] => 1824627
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:10 --> Select (Calc: 0.15)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=03
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743244
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743368
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743376
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743384
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743392
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743406
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743414
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [7] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1928473
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [8] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1927906
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [9] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254465
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1945963
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:11 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=04
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254447
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1901168
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254447
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1901184
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254447
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1901214
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254447
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1901214
            [RSPRCTP] => I
            [RSITSSQ] => 1
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254447
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1901214
            [RSPRCTP] => I
            [RSITSSQ] => 2
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254447
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1901214
            [RSPRCTP] => I
            [RSITSSQ] => 3
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:12 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=05
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254154
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1800213
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254154
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1741748
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:12 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=06
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253288
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888048
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253288
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888072
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253288
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1887912
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253288
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1887939
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253288
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1887998
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253288
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1888005
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:13 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=07
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254322
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1868543
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254322
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1868543
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254322
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1903535
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254322
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 1
            [RSITSEQ] => 2
            [RSSKNBR] => 1903535
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254322
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 2
            [RSITSEQ] => 2
            [RSSKNBR] => 1903535
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254322
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 3
            [RSITSEQ] => 2
            [RSSKNBR] => 1903535
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [6] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254322
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 4
            [RSITSEQ] => 2
            [RSSKNBR] => 1903535
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:13 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=08
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254123
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933523
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254123
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933566
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254123
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1933582
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:14 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=09
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254424
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1596624
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254424
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1906992
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:15 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=10
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254440
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1729764
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254440
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1886908
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254440
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1449117
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254440
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1449133
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [4] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254440
            [RSINSEQ] => 40
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1449338
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [5] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254440
            [RSINSEQ] => 50
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1449303
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => C
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:15 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=11
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253884
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743198
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253884
            [RSINSEQ] => 30
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743198
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [2] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253884
            [RSINSEQ] => 40
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743236
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [3] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 253884
            [RSINSEQ] => 40
            [RSINSSS] => 1
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1743236
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:16 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=12
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 245108
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1918117
            [RSPRCTP] => D
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 245108
            [RSINSEQ] => 70
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1918117
            [RSPRCTP] => E
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:17 --> Select (Calc: 0.00)SELECT RSSTRNO,RSINVNO,RSINSEQ,RSINSSS,RSINSSQ,RSITSEQ,RSSKNBR,RSPRCTP,RSITSSQ,RSPRBACT,RSPRBSTS,RSTEXT,DMPUMSG,DMLOADMSG,DMDELMSG,RSSRVTIMS,RSPBMTIME
                    FROM RTSITMSTS
                    LEFT JOIN SKUDELMSG ON DMSKUNBR = RSSKNBR AND DMEFFBEG <= '20190208' AND (DMEFFEND = 0 OR DMEFFEND >= '20190208')
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSSTOP=13
                    AND RSRTETYP='L' V: R:Array
(
    [0] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254430
            [RSINSEQ] => 10
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1890379
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

    [1] => stdClass Object
        (
            [RSSTRNO] => 825
            [RSINVNO] => 254430
            [RSINSEQ] => 20
            [RSINSSS] => 0
            [RSINSSQ] => 0
            [RSITSEQ] => 2
            [RSSKNBR] => 1890417
            [RSPRCTP] => I
            [RSITSSQ] => 0
            [RSPRBACT] => 
            [RSPRBSTS] => 
            [RSTEXT] => 
            [DMPUMSG] => 
            [DMLOADMSG] => 
            [DMDELMSG] => 
            [RSSRVTIMS] => 0
            [RSPBMTIME] => 0
        )

)

ERROR - 2019-02-08 10:52:17 --> Select (Calc: 0.13)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=01
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:18 --> Select (Calc: 0.02)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=02
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:18 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=03
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:19 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=04
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:20 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=05
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:20 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=06
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:21 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=07
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:22 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=08
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:22 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=09
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:23 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=10
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:24 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=11
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:24 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=12
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:25 --> Select (Calc: 0.00)SELECT RIRTETYP,RISTRNO,RIINVNO,RIINSEQ,RIINSSS,RIINSSQ,RIITSEQ,RISKNBR,RIPRCTP,RIITSSQ,RISEQ,RIIMAGE
                    FROM RTSIMAGE
                    WHERE RISTORE=00825
                    AND RIROUT=100784
                    AND RISTOP=13
                    AND RIRTETYP='L'
                    ORDER BY RISTRNO ASC,RIINVNO ASC,RIINSEQ ASC,RIINSSS ASC,RIINSSQ ASC,RIITSEQ ASC,RISKNBR ASC,RIPRCTP ASC,RIITSSQ ASC,RISEQ ASC V: R:
ERROR - 2019-02-08 10:52:26 --> Select (Calc: 0.09)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254456
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-08 10:52:26 --> Select (Calc: 0.12)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254456
					    				and MTYPE = 'I'
								    	and MSKU  = '1935313'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '8633-32-CB' V: R:
ERROR - 2019-02-08 10:52:27 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254456
					    				and MTYPE = 'I'
								    	and MSKU  = '1935356'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '8633-61-CB' V: R:
ERROR - 2019-02-08 10:52:28 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254456
					    				and MTYPE = 'I'
								    	and MSKU  = '1935402'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '8633-67-CB' V: R:
ERROR - 2019-02-08 10:52:28 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254456
					    				and MTYPE = 'I'
								    	and MSKU  = '1935305'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '8633-27-CB' V: R:
ERROR - 2019-02-08 10:52:29 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254456
					    				and MTYPE = 'I'
								    	and MSKU  = '1824309'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'SS-TA-2448B-BCH-C' V: R:
ERROR - 2019-02-08 10:52:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254456
					    				and MTYPE = 'I'
								    	and MSKU  = '1824627'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'SS-BS-125-BCH-K24' V: R:
ERROR - 2019-02-08 10:52:30 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254456
					    				and MTYPE = 'I'
								    	and MSKU  = '1824627'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = 'SS-BS-125-BCH-K24' V: R:
ERROR - 2019-02-08 10:52:31 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253993
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-08 10:52:32 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1933515'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213917-AI' V: R:
ERROR - 2019-02-08 10:52:32 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1933558'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213947-AI' V: R:
ERROR - 2019-02-08 10:52:33 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1933574'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213974-AI' V: R:
ERROR - 2019-02-08 10:52:33 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1927922'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = 'VCF016-5M' V: R:
ERROR - 2019-02-08 10:52:34 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1928678'
								    	and MSSEQ = 060
								    	and MSBSQ = 00
								    	and MITEM = 'VCF019-5B' V: R:
ERROR - 2019-02-08 10:52:35 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1473425'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = 'LY320-153QHF' V: R:
ERROR - 2019-02-08 10:52:35 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1803972'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = 'LY320-253QKR' V: R:
ERROR - 2019-02-08 10:52:36 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1824309'
								    	and MSSEQ = 080
								    	and MSBSQ = 00
								    	and MITEM = 'SS-TA-2448B-BCH-C' V: R:
ERROR - 2019-02-08 10:52:37 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1824627'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = 'SS-BS-125-BCH-K24' V: R:
ERROR - 2019-02-08 10:52:37 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1824627'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = 'SS-BS-125-BCH-K24' V: R:
ERROR - 2019-02-08 10:52:38 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1824627'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = 'SS-BS-125-BCH-K24' V: R:
ERROR - 2019-02-08 10:52:38 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'I'
								    	and MSKU  = '1824627'
								    	and MSSEQ = 090
								    	and MSBSQ = 00
								    	and MITEM = 'SS-BS-125-BCH-K24' V: R:
ERROR - 2019-02-08 10:52:39 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'C'
								    	and MSKU  = '1933558'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213947-AI' V: R:
ERROR - 2019-02-08 10:52:40 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'C'
								    	and MSKU  = '1933647'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213973-AI' V: R:
ERROR - 2019-02-08 10:52:40 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253993
					    				and MTYPE = 'C'
								    	and MSKU  = '1933744'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213918-AI' V: R:
ERROR - 2019-02-08 10:52:41 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254465
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-08 10:52:42 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1743244'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2892-RM' V: R:
ERROR - 2019-02-08 10:52:42 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1743368'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '902M' V: R:
ERROR - 2019-02-08 10:52:43 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1743376'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2814-1' V: R:
ERROR - 2019-02-08 10:52:44 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1743384'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2814-2' V: R:
ERROR - 2019-02-08 10:52:44 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1743392'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2814-3' V: R:
ERROR - 2019-02-08 10:52:45 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1743406'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2814-5' V: R:
ERROR - 2019-02-08 10:52:45 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1743414'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '2814-FULL' V: R:
ERROR - 2019-02-08 10:52:46 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1928473'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'VCF015-3M' V: R:
ERROR - 2019-02-08 10:52:47 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1927906'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'VCF015-4M' V: R:
ERROR - 2019-02-08 10:52:47 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254465
					    				and MTYPE = 'I'
								    	and MSKU  = '1945963'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = '93413' V: R:
ERROR - 2019-02-08 10:52:48 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254447
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-08 10:52:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254447
					    				and MTYPE = 'I'
								    	and MSKU  = '1901168'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'CM420WT' V: R:
ERROR - 2019-02-08 10:52:49 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254447
					    				and MTYPE = 'I'
								    	and MSKU  = '1901184'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'CM420WB' V: R:
ERROR - 2019-02-08 10:52:50 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254447
					    				and MTYPE = 'I'
								    	and MSKU  = '1901214'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'CM420SSN' V: R:
ERROR - 2019-02-08 10:52:51 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254447
					    				and MTYPE = 'I'
								    	and MSKU  = '1901214'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'CM420SSN' V: R:
ERROR - 2019-02-08 10:52:51 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254447
					    				and MTYPE = 'I'
								    	and MSKU  = '1901214'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'CM420SSN' V: R:
ERROR - 2019-02-08 10:52:52 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254447
					    				and MTYPE = 'I'
								    	and MSKU  = '1901214'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = 'CM420SSN' V: R:
ERROR - 2019-02-08 10:52:53 --> Select (Calc: 0.01)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254154
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-08 10:52:53 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254154
					    				and MTYPE = 'I'
								    	and MSKU  = '1800213'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'DLB-858BP-SR' V: R:
ERROR - 2019-02-08 10:52:54 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254154
					    				and MTYPE = 'I'
								    	and MSKU  = '1741748'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '1323P-53-BK-BB' V: R:
ERROR - 2019-02-08 10:52:55 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253288
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-08 10:52:55 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253288
					    				and MTYPE = 'I'
								    	and MSKU  = '1888048'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '3651-37' V: R:
ERROR - 2019-02-08 10:52:56 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253288
					    				and MTYPE = 'I'
								    	and MSKU  = '1888072'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = '3651-39' V: R:
ERROR - 2019-02-08 10:52:57 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253288
					    				and MTYPE = 'I'
								    	and MSKU  = '1887912'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '3651-03' V: R:
ERROR - 2019-02-08 10:52:57 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253288
					    				and MTYPE = 'I'
								    	and MSKU  = '1887939'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '3651-04' V: R:
ERROR - 2019-02-08 10:52:58 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253288
					    				and MTYPE = 'I'
								    	and MSKU  = '1887998'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = '3651-44' V: R:
ERROR - 2019-02-08 10:52:58 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253288
					    				and MTYPE = 'I'
								    	and MSKU  = '1888005'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = '3651-45' V: R:
ERROR - 2019-02-08 10:52:59 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254322
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-08 10:53:00 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254322
					    				and MTYPE = 'I'
								    	and MSKU  = '1868543'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'J642SNALVAROLUXE' V: R:
ERROR - 2019-02-08 10:53:00 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254322
					    				and MTYPE = 'I'
								    	and MSKU  = '1868543'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'J642SNALVAROLUXE' V: R:
ERROR - 2019-02-08 10:53:01 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254322
					    				and MTYPE = 'F'
								    	and MSKU  = '1903535'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'OD8255-64' V: R:
ERROR - 2019-02-08 10:53:02 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254322
					    				and MTYPE = 'F'
								    	and MSKU  = '1903535'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'OD8255-64' V: R:
ERROR - 2019-02-08 10:53:02 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254322
					    				and MTYPE = 'F'
								    	and MSKU  = '1903535'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'OD8255-64' V: R:
ERROR - 2019-02-08 10:53:03 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254322
					    				and MTYPE = 'F'
								    	and MSKU  = '1903535'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'OD8255-64' V: R:
ERROR - 2019-02-08 10:53:04 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254322
					    				and MTYPE = 'F'
								    	and MSKU  = '1903535'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'OD8255-64' V: R:
ERROR - 2019-02-08 10:53:04 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254123
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-08 10:53:05 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254123
					    				and MTYPE = 'I'
								    	and MSKU  = '1933523'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213917-AB' V: R:
ERROR - 2019-02-08 10:53:06 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254123
					    				and MTYPE = 'I'
								    	and MSKU  = '1933566'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213947-AB' V: R:
ERROR - 2019-02-08 10:53:06 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254123
					    				and MTYPE = 'I'
								    	and MSKU  = '1933582'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'KRO-213974-AB' V: R:
ERROR - 2019-02-08 10:53:07 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254424
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-08 10:53:08 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254424
					    				and MTYPE = 'I'
								    	and MSKU  = '1596624'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'P740BK-60' V: R:
ERROR - 2019-02-08 10:53:08 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254424
					    				and MTYPE = 'I'
								    	and MSKU  = '1906992'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = '2011095' V: R:
ERROR - 2019-02-08 10:53:09 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254440
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-08 10:53:10 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254440
					    				and MTYPE = 'I'
								    	and MSKU  = '1729764'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'VCF006-5B' V: R:
ERROR - 2019-02-08 10:53:10 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254440
					    				and MTYPE = 'I'
								    	and MSKU  = '1886908'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'HKGMFQ10-5M' V: R:
ERROR - 2019-02-08 10:53:11 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254440
					    				and MTYPE = 'I'
								    	and MSKU  = '1449117'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '2500PA-156QHFS' V: R:
ERROR - 2019-02-08 10:53:12 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254440
					    				and MTYPE = 'I'
								    	and MSKU  = '1449133'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '2500PA-156QKR' V: R:
ERROR - 2019-02-08 10:53:13 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254440
					    				and MTYPE = 'I'
								    	and MSKU  = '1449338'
								    	and MSSEQ = 040
								    	and MSBSQ = 00
								    	and MITEM = '2500PA-120' V: R:
ERROR - 2019-02-08 10:53:13 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254440
					    				and MTYPE = 'F'
								    	and MSKU  = '1449303'
								    	and MSSEQ = 050
								    	and MSBSQ = 00
								    	and MITEM = '2500PA-133' V: R:
ERROR - 2019-02-08 10:53:14 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 253884
                                    and MTYPE = 'D' V: R:
ERROR - 2019-02-08 10:53:15 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253884
					    				and MTYPE = 'D'
								    	and MSKU  = '1743198'
								    	and MSSEQ = 030
								    	and MSBSQ = 00
								    	and MITEM = '2867' V: R:
ERROR - 2019-02-08 10:53:15 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 253884
					    				and MTYPE = 'D'
								    	and MSKU  = '1743236'
								    	and MSSEQ = 040
								    	and MSBSQ = 01
								    	and MITEM = '2890' V: R:
ERROR - 2019-02-08 10:53:16 --> Select (Calc: 0.03)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 245108
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-08 10:53:17 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 245108
					    				and MTYPE = 'D'
								    	and MSKU  = '1918117'
								    	and MSSEQ = 070
								    	and MSBSQ = 00
								    	and MITEM = '101003-1462-45-BL' V: R:
ERROR - 2019-02-08 10:53:18 --> Select (Calc: 0.00)SELECT MTEXT
                                    from INVCOM
                                    where MSTORE = 00825
                                    and MINV# = 254430
                                    and MTYPE = 'D' V: R:Array
(
    [0] => stdClass Object
        (
            [MTEXT] => 
        )

)

ERROR - 2019-02-08 10:53:18 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254430
					    				and MTYPE = 'I'
								    	and MSKU  = '1890379'
								    	and MSSEQ = 010
								    	and MSBSQ = 00
								    	and MITEM = 'PX300503D2B-MB' V: R:
ERROR - 2019-02-08 10:53:19 --> Select (Calc: 0.00)SELECT MTEXT
					    				from INVCOM
					    				where MSTORE = 00825
					    				and MINV# = 254430
					    				and MTYPE = 'I'
								    	and MSKU  = '1890417'
								    	and MSSEQ = 020
								    	and MSBSQ = 00
								    	and MITEM = 'PX300502CE3B-MB' V: R:
ERROR - 2019-02-08 10:53:20 --> Select (Calc: 0.01)SELECT RSSTOP,RSPRBACT
                    FROM RTSITMSTS
                    WHERE RSSTORE=00825
                    AND RSROUT=100784
                    AND RSRTETYP='L'
                    AND RSSTRNO=0 AND RSINVNO=0 AND RSINSEQ=0 AND RSINSSS=0 AND RSITSEQ=0 AND RSSKNBR=0 AND RSPRCTP='' AND RSITSSQ=0
                    ORDER BY RSSTOP ASC V: R:
ERROR - 2019-02-08 10:53:20 --> Select (Calc: 0.02)SELECT MBLPUDEL, MBLPRBACT, MBLPRBSTS, MBLIMGREQ, MBLPRBDESC, MBLWRDREQ
            FROM MBLPRBMST
            WHERE MBLRTETYP = ?
            ORDER BY MBLPRBACT ASC, MBLPRBSTS ASC, MBLPRBDESC ASC V:Array
(
    [0] => L
)
 R:Array
(
    [0] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => D
            [MBLPRBSTS] => 
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Load Exception
            [MBLWRDREQ] => 3
        )

    [1] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => L
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Loaded
            [MBLWRDREQ] => 0
        )

    [2] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 4
            [MBLIMGREQ] => Y
            [MBLPRBDESC] => Damaged/Not Loaded
            [MBLWRDREQ] => 3
        )

    [3] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => P
            [MBLPRBSTS] => 5
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Short-Out of Stock
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MBLPUDEL] => P
            [MBLPRBACT] => R
            [MBLPRBSTS] => C
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Customer
            [MBLWRDREQ] => 0
        )

    [5] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => G
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get Transfer
            [MBLWRDREQ] => 0
        )

    [6] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => L
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Ready to Load
            [MBLWRDREQ] => 0
        )

    [7] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => S
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Get from Service
            [MBLWRDREQ] => 0
        )

    [8] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => R
            [MBLPRBSTS] => T
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Wait on Trailer
            [MBLWRDREQ] => 0
        )

    [9] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => T
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => COD Tender
            [MBLWRDREQ] => 0
        )

    [10] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => U
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Abort Load
            [MBLWRDREQ] => 0
        )

    [11] => stdClass Object
        (
            [MBLPUDEL] => D
            [MBLPRBACT] => V
            [MBLPRBSTS] => 
            [MBLIMGREQ] => N
            [MBLPRBDESC] => Verify Load
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-08 10:53:22 --> Select (Calc: 0.52)SELECT CTTRUKNAME,CTCURMILES
                FROM CNTDRVTRK T
                JOIN CNTDRVCMP C
                ON
                    T.CTCOMPANY = C.CCCOMPANY
                WHERE
                    T.CTCOMPANY = 'KCLLC'
                    AND T.CTMARKET = 'OHVCO'
                    AND T.CTTRUKNAME NOT IN (SELECT RHTRNAME FROM RTSHDR WHERE RHTRKC <> '1' AND RHCMP = 'KCLLC' and RHDATE = '20190208')
                    AND T.CTTRUKNAME != ''
                    AND T.CTAVAILBLE = 'Y'
                    AND T.CTENDDATE = 0
                    AND (C.CCVENDOR = 'ASI' AND T.CTSTRNBR = '825' OR C.CCVENDOR <> 'ASI')
                ORDER BY CTTRUKNAME ASC V: R:Array
(
    [0] => stdClass Object
        (
            [CTTRUKNAME] => KHAT5
            [CTCURMILES] => 285991
        )

)

ERROR - 2019-02-08 10:53:22 --> Select (Calc: 0.04)SELECT * FROM RTSMBLCTL WHERE MCSTATE IS NOT NULL; V: R:Array
(
    [0] => stdClass Object
        (
            [MCSTATE] => 0
            [MCMESSAGE] => Click Drive to start driving here.
            [MCBUTTON] => Drive
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [1] => stdClass Object
        (
            [MCSTATE] => 1
            [MCMESSAGE] => Meet the customer and click Continue.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ARVSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [2] => stdClass Object
        (
            [MCSTATE] => 2
            [MCMESSAGE] => Update all items to continue.
            [MCBUTTON] => Abort delivery
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => START
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => Y
            [MCASRTCOD] => Y
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [3] => stdClass Object
        (
            [MCSTATE] => 3
            [MCMESSAGE] => Click Customer Agree to finalize items.
            [MCBUTTON] => Customer Agree ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => Y
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [4] => stdClass Object
        (
            [MCSTATE] => 4
            [MCMESSAGE] => 
            [MCBUTTON] => 
            [MCSTPIMG] => N
            [MCSTPIMGH] => N
            [MCSETDETL] => Y
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [5] => stdClass Object
        (
            [MCSTATE] => 5
            [MCMESSAGE] => Departed - Not At Home
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => NOTHME
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => H
            [MCALLSTATS] => 
            [MCALLOVER] => *
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [6] => stdClass Object
        (
            [MCSTATE] => 6
            [MCMESSAGE] => Departed - Success
            [MCBUTTON] => (Finished)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DPTSTP
            [MCMSGEMAIL] => *
            [MCMSGRECPT] => *
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => Y
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [7] => stdClass Object
        (
            [MCSTATE] => 7
            [MCMESSAGE] => Click Drive (Aborted) to start driving here.
            [MCBUTTON] => Drive (Aborted)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => ABTSTP
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => *
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => A
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => Driver aborted
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => N
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

    [8] => stdClass Object
        (
            [MCSTATE] => 8
            [MCMESSAGE] => Click Drive (Return) to start driving here.
            [MCBUTTON] => Drive (Return)
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => U
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [9] => stdClass Object
        (
            [MCSTATE] => 9
            [MCMESSAGE] => Departed - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [10] => stdClass Object
        (
            [MCSTATE] => 10
            [MCMESSAGE] => Departed - Wrong Address
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => WRGADR
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => W
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [11] => stdClass Object
        (
            [MCSTATE] => 11
            [MCMESSAGE] => Driving To Stop
            [MCBUTTON] => Arrive ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DRIVNG
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [12] => stdClass Object
        (
            [MCSTATE] => 12
            [MCMESSAGE] => Click Continue to resume delivery.
            [MCBUTTON] => Continue ...
            [MCSTPIMG] => Y
            [MCSTPIMGH] => N
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => 
            [MCMSGACTN] => 
            [MCMSGSTAT] => 
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => N
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => Y
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => N
            [MCRESCHED] => N
        )

    [13] => stdClass Object
        (
            [MCSTATE] => 13
            [MCMESSAGE] => Delay Active
            [MCBUTTON] => End Delay ...
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => Y
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => DLYNOW
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 0
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => Y
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => 
            [MCALLSTATS] => 
            [MCALLOVER] => 
            [MCALLNOTES] => 
            [MCFINAL] => N
            [MCFOCUS] => Y
            [MCGOAL] => N
            [MCSETEND] => N
            [MCDELAYTXT] => Y
            [MCRESCHED] => N
        )

    [14] => stdClass Object
        (
            [MCSTATE] => 14
            [MCMESSAGE] => Rescheduled - Canceled
            [MCBUTTON] => Retry
            [MCSTPIMG] => N
            [MCSTPIMGH] => Y
            [MCSETDETL] => N
            [MCSETITEM] => N
            [MCNXTSTOP] => N
            [MCMSGSTOP] => *
            [MCMSGACTN] => STPSTS
            [MCMSGSTAT] => CANCEL
            [MCMSGEMAIL] => 
            [MCMSGRECPT] => 
            [MCMSGASTOP] => 
            [MCMSGDLYTM] => 
            [MCMSGDLYTX] => 
            [MCMSGTIMER] => U
            [MCMSGITEMS] => N
            [MCASRTCOD] => N
            [MCSETSTART] => N
            [MCALLACTIN] => X
            [MCALLSTATS] => 
            [MCALLOVER] => Y
            [MCALLNOTES] => *
            [MCFINAL] => N
            [MCFOCUS] => N
            [MCGOAL] => Y
            [MCSETEND] => Y
            [MCDELAYTXT] => N
            [MCRESCHED] => Y
        )

)

ERROR - 2019-02-08 10:53:23 --> Select (Calc: 0.06)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 0
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 0
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:24 --> Select (Calc: 0.02)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 1
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 1
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:25 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 2
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 2
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 7
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 0
        )

)

ERROR - 2019-02-08 10:53:26 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 3
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 1
            [MMTEXT] => Customer Agree
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => Y
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 2
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 3
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 3
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:27 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 4
)
 R:
ERROR - 2019-02-08 10:53:27 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 5
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 5
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:28 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 6
)
 R:
ERROR - 2019-02-08 10:53:29 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 7
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 7
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:30 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 8
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 8
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:31 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 9
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 9
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:31 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 10
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 10
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:32 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 11
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 1
            [MMTEXT] => Arrive
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 1
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 3
            [MMTEXT] => Abort Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => Y
            [MMABTSTATE] => 7
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 11
            [MMMENUSEQ] => 4
            [MMTEXT] => Cancel
            [MMCOLOR] => #FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:33 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 12
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 1
            [MMTEXT] => Start Delivery
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 2
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay Now
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 4
            [MMTEXT] => Reschedule Delivery
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 14
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => N
            [MBLWRDREQ] => 4
        )

    [3] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 5
            [MMTEXT] => Not At Home
            [MMCOLOR] => FF8080
            [MMNXTSTATE] => 5
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => moreinfo
            [MMINTSTATE] => 0
            [MBLIMGREQ] => Y
            [MBLWRDREQ] => 0
        )

    [4] => stdClass Object
        (
            [MMSTATE] => 12
            [MMMENUSEQ] => 7
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:34 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 13
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 1
            [MMTEXT] => End Delay
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => Y
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [1] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 2
            [MMTEXT] => Delay More
            [MMCOLOR] => FFFF99
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => Y
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

    [2] => stdClass Object
        (
            [MMSTATE] => 13
            [MMMENUSEQ] => 3
            [MMTEXT] => Cancel
            [MMCOLOR] => FFF
            [MMNXTSTATE] => 99
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:35 --> Select (Calc: 0.00)SELECT M.*, P.MBLIMGREQ, P.MBLWRDREQ FROM RTSMBLMNU M LEFT JOIN RTSMBLCTL C ON MMNXTSTATE=MCSTATE LEFT JOIN MBLPRBMST P ON MCALLACTIN = MBLPRBACT AND MCALLSTATS = MBLPRBSTS AND MBLPUDEL='D' WHERE MMSTATE = ? V:Array
(
    [0] => 14
)
 R:Array
(
    [0] => stdClass Object
        (
            [MMSTATE] => 14
            [MMMENUSEQ] => 1
            [MMTEXT] => Drive To Stop
            [MMCOLOR] => B5FFC8
            [MMNXTSTATE] => 11
            [MMDELAYNOW] => N
            [MMALLITEMS] => N
            [MMABORTNOW] => N
            [MMABTSTATE] => 0
            [MMAGREE] => N
            [MMDELAYEND] => N
            [MMINTVIEW] => 
            [MMINTSTATE] => 0
            [MBLIMGREQ] => 
            [MBLWRDREQ] => 
        )

)

ERROR - 2019-02-08 10:53:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:53:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:53:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:53:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:53:37 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:53:37 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-02-08 10:53:47 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:53:47 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:56:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:56:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 10:59:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 10:59:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:02:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:02:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:05:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:05:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:08:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:08:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:11:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:11:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:14:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:14:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:17:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:17:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:20:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:20:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:23:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:23:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:26:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:26:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:29:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:29:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:32:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:32:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:35:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:35:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:38:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:38:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:41:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:41:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:44:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:44:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:47:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:47:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:50:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:50:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:53:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:53:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:56:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:56:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 11:59:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 11:59:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 12:02:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 12:02:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 12:05:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 12:05:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-02-08 12:08:03 --> ATTEMPTING TO LOGIN
ERROR - 2019-02-08 12:08:03 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

