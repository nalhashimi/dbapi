<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-29 11:14:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:14:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:14:45 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:14:45 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:14:47 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:14:47 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:14:47 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:14:47 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:14:47 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:14:47 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:14:47 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:14:47 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-01-29 11:14:55 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:14:55 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:15:01 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:15:01 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:15:11 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:15:11 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:15:13 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:15:13 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:15:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:15:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:15:29 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:15:29 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:15:45 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:15:45 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:20:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:20:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:30:50 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:30:50 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:30:50 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:30:50 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 11:42:27 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:42:27 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 11:52:46 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 11:52:46 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCPORTAL
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:08:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:08:04 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:08:04 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 14:08:04 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 14:08:25 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:08:25 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:08:25 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 14:08:25 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 14:08:25 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 14:08:25 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 14:08:25 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 14:08:25 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-01-29 14:08:55 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:08:55 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:09:46 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:09:46 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:09:51 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:09:51 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:09:52 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:09:52 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:09:53 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:09:53 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:13:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:13:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:14:38 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:14:38 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:17:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:17:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:17:42 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:17:42 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:17:47 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:17:47 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:17:56 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:17:56 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:18:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:18:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:18:21 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:18:21 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:46:13 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:46:13 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:46:43 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:46:43 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:46:48 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 14:46:48 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 14:47:10 --> Select (Calc: 0.02)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:
ERROR - 2019-01-29 15:29:27 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:27 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:29:28 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:28 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:29:29 --> Select (Calc: 0.01)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:29:29 --> Select (Calc: 0.02)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:29:30 --> Select (Calc: 0.05)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:29:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:29:38 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:38 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:29:52 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:52 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:29:53 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:53 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:29:53 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:29:54 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:29:55 --> Select (Calc: 0.01)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:29:56 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:56 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:29:56 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:56 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:29:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:29:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:29:58 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:29:58 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:29:59 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:30:00 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:30:00 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:30:08 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:30:08 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:30:09 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:30:09 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:30:10 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:30:10 --> Select (Calc: 0.01)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:30:11 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:30:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:30:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:30:30 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:30:30 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:30:34 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:30:34 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:30:42 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:32:07 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:34:08 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:34:38 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:34:38 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:35:52 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:35:52 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:35:56 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:35:56 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:35:59 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:36:03 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:36:06 --> Select (Calc: 0.01)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:36:10 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:36:10 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:36:44 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:36:44 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:36:46 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:36:46 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:36:49 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:36:52 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:36:55 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 15:36:55 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 15:36:55 --> Severity: Warning --> db2_exec(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 148
ERROR - 2019-01-29 15:36:55 --> Severity: Warning --> db2_exec(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 148
ERROR - 2019-01-29 15:36:55 --> Severity: Warning --> db2_exec(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 148
ERROR - 2019-01-29 15:36:55 --> Severity: Warning --> db2_exec(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 148
ERROR - 2019-01-29 15:36:55 --> Severity: Warning --> db2_exec(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 148
ERROR - 2019-01-29 15:36:55 --> Severity: Warning --> db2_exec(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 148
ERROR - 2019-01-29 15:36:55 --> Select (Calc: 0.04)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:
ERROR - 2019-01-29 15:37:04 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:37:04 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:37:04 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 15:37:04 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 15:37:04 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 15:37:04 --> Severity: Warning --> db2_pconnect(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 15:37:04 --> Severity: Warning --> db2_pconnect(): Statement Execute Failed /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 62
ERROR - 2019-01-29 15:37:04 --> Severity: Warning --> db2_conn_error(): Error occurred in SQL Call Level Interface SQLCODE=-99999 /www/zendsvr6/htdocs/development/nalhash/dbapi/application/models/ISeries_DB2_model.php 65
ERROR - 2019-01-29 15:37:06 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:37:06 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:37:09 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:37:11 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:37:15 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:37:18 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:37:18 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:41:58 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:41:58 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:42:03 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:42:03 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:42:06 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:42:10 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:42:13 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:42:17 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:42:17 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:42:57 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:42:57 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:43:10 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:10 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:43:11 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:11 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:43:12 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:43:12 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:43:13 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:43:14 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:14 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:43:16 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:16 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:43:17 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:17 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:43:18 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:43:18 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:43:19 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:43:20 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:20 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:43:36 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:36 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:43:36 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:36 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:43:37 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:43:38 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:43:39 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:43:40 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:43:40 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:46:27 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:46:27 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:46:28 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:46:28 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:46:28 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:46:29 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:46:30 --> Select (Calc: 0.01)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:46:31 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:46:31 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:47:11 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:47:11 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:47:12 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:47:12 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:47:13 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:47:13 --> Select (Calc: 0.00)SELECT S.EADEVICEID, S.EAENVNAME
	                FROM RTSAPRVAL R
	                JOIN WEBENVASN S on ( (CONCAT('User: ',RADEVICE) = S.EADEVICEID OR CONCAT('Store: ',R.RASTR#) = S.EADEVICEID OR '*default' = S.EADEVICEID) AND EACODE = 'DcMobile')
	                WHERE (RAROUT='100513'  OR RASTR# = '825' OR RADEVICE  IN ('8888888888')) AND RADATE = '20190129' V: R:Array
(
    [0] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [1] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [2] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [3] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [4] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [5] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [6] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [7] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [8] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [9] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [10] => stdClass Object
        (
            [EADEVICEID] => User: 8888888888
            [EAENVNAME] => Dev
        )

    [11] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [12] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [13] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [14] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [15] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [16] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [17] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [18] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [19] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [20] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [21] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [22] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [23] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [24] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [25] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [26] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [27] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [28] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

    [29] => stdClass Object
        (
            [EADEVICEID] => *default
            [EAENVNAME] => Beta
        )

    [30] => stdClass Object
        (
            [EADEVICEID] => Store: 825
            [EAENVNAME] => Dev
        )

)

ERROR - 2019-01-29 15:47:14 --> Select (Calc: 0.00)SELECT H.*, S.SNAME
                               FROM RTSHDR H
                               JOIN VALUECITY/STRMST S ON (S.STRNBR=H.RHSTR# AND S.SMLOC#=1)
                               WHERE RHSTR#='825'
                               AND RHROUT='100513' V: R:Array
(
    [0] => stdClass Object
        (
            [RHSTR#] => 825
            [RHROUT] => 100513
            [RHDATE] => 20190129
            [RHTRUC] => 5
            [RHDRIV] => JOEL BUMGARNER
            [RHHELP] => JOEL BUMGARNER
            [RHSTOP] => 12
            [RHCUBE] => 1139
            [RHCODD] => 0
            [RHSEAL] => 
            [RHCODC] => 0
            [RHTCKP] => 
            [RHDRVC] => 
            [RHDRVU] => 
            [RHTRKC] => 
            [RHRECN] => 
            [RHSTAG] => F
            [RHSTAT] => RSVER
            [RHCMP] => UST
            [RHMILES] => 41708
            [RHMILEE] => 0
            [RHCMPSTOPS] => 0
            [RHCLNSTOPS] => 0
            [RHTOTVALUE] => 0
            [RHCMPVALUE] => 0
            [RHCLNVALUE] => 0
            [RHDRVEMP] => 44641
            [RHHLPEMP] => 44641
            [RHTRNAME] => TRUCK 5
            [RHTRHSTSEQ] => 0
            [RHTRIPSTAT] => R
            [RHDDROUTE] => 11851886
            [RHDRVSEQ] => 2
            [RHDRVTIM] => 10
            [RHDRVDIST] => 6733
            [RHPRJDEP] => 730
            [RHPRJARV] => 1808
            [RHPRJMILES] => 45
            [RHACTDEP] => 1102
            [RHACTARV] => 0
            [RHACTMILES] => 0
            [RHCURSTAT] => Ready for Delivery:8888888888
            [RHSTSLEVEL] => 1
            [RHMGROVR] => 
            [RHTIMEZONE] => EST
            [SNAME] => Columbus Central Delivery
        )

)

ERROR - 2019-01-29 15:47:15 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:47:15 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:49:20 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:49:20 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:49:21 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:49:21 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:49:22 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:49:22 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:49:22 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

ERROR - 2019-01-29 15:49:53 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:49:53 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 000
)

ERROR - 2019-01-29 15:49:54 --> ATTEMPTING TO LOGIN
ERROR - 2019-01-29 15:49:54 --> POST: Array
(
    [username] => DCPORTAL
    [password] => DCPORTAL
    [conntype] => db2
    [liblist] => ,QTEMP,VCFCORPF,STOREDEV,STOREQA,BETADATA,VCFMENU,STOREPGMS,QGPL,VCFCOMM,LIBHTTPX,VALUECITY,ASYNC,VCFGEN,ZMODEDIIP,ZMODLIB10,POPUP,API_LIB EASYCOM
    [servername] => DEVELOP
    [persistent] => y
    [dbjob] => DCMOBILE
    [pconntimout] => 1
    [store] => 825
)

ERROR - 2019-01-29 15:49:55 --> Select (Calc: 0.00)SELECT RASTR#,RAROUT,RHCMP,SMMRKT,RHTRUC,RHSTAG,RADRVCMPD,RHTRNAME,RHMILES,RADRVUSER,RADATE
                FROM RTSAPRVAL A
                JOIN RTSHDR H ON (A.RASTR#=H.RHSTR# AND A.RAROUT=H.RHROUT)
                JOIN VALUECITY/STRMST S ON (S.STRNBR=A.RASTR# AND S.SMLOC#=1)
                WHERE
                (
                    (
                        A.RADATE = 20190128
                        AND H.RHSTAG IN ('F')
                        AND A.RADRVCMPD = 0
                    )
                    OR
                    (
                        A.RADATE = 20190129
                        AND H.RHSTAG IN ('B','C','D','F')
                    )
                    OR
                    (
                        (A.RADATE > 20190129 AND A.RADATE < 20190206)
                        AND H.RHSTAG IN ('B','C','D')
                    )
                )
                AND A.RADEVICE = '8888888888'
                AND H.RHRECN != '1'
                AND H.RHTRKC != '1'
                ORDER BY A.RADRVCMPD ASC, A.RADATE ASC, H.RHSTAG DESC V: R:Array
(
    [0] => stdClass Object
        (
            [RASTR#] => 825
            [RAROUT] => 100513
            [RHCMP] => UST
            [SMMRKT] => OHVCO
            [RHTRUC] => 5
            [RHSTAG] => F
            [RADRVCMPD] => 0
            [RHTRNAME] => TRUCK 5
            [RHMILES] => 41708
            [RADRVUSER] => 2260528315
            [RADATE] => 20190129
        )

)

