<?php
/**
 * This is first round implementation of a remote DB request over RESTful API. 
 */
class RemoteRequest extends CI_Controller {
    
    private $validToken = false;

    public function __construct(){
        parent::__construct();
        $this->load->helper('error_code');
        //$this->load->helper('database');
        $this->load->helper('jwt');
        $this->load->helper('request');
        $this->load->helper('auth');
        $this->load->helper('rest_api');
        
        $jwt_token = getBearerToken();
        
        $validToken = is_jwt_valid($jwt_token);
        
        if($jwt_token == false  || !$validToken) {
            log_message("ERROR", "Invalid token invoked : " . $jwt_token);
            die(header('HTTP/1.1 403 Forbidden'));
        } else {
            $this->validToken = $validToken['token'];
        }
        
    }
    
    /**
     * Index method for completeness.
     * Returns a JSON response with an
     * error message.
     */
    public function index()
    {
        header('Content-Type: application/json');
        echo json_encode(array(
            "code" => BAD_DATA,
            "message" => "No resource specified."
        ));
    }
  
  
  public function select()
  {
      header('Content-Type: application/json');
      $time = -microtime(true);
      
      $this->load->model('RemoteRequest_model');
      $this->RemoteRequest_model->Connect($this->validToken);
      $sql = $_POST['sql'];
      $values = isset($_POST['values']) ? $_POST['values'] : null;
      $EmptyResults = isset($_POST['EmptyResults']) ? $_POST['EmptyResults'] : false;
      
      $rtn = $this->RemoteRequest_model->Select($sql, $values, $EmptyResults, false);
      
      // Performance: End
      $time += microtime(true);
      $timeStr = sprintf('%0.2f', $time);
      
      echo formatReturnData($rtn);
      
  }
    
  public function update()
  {
      header('Content-Type: application/json');
      $time = -microtime(true);
      
      $this->load->model('RemoteRequest_model');
      $this->RemoteRequest_model->Connect($this->validToken);
      $sql = $_POST['sql'];
      $values = isset($_POST['values']) ? $_POST['values'] : null;
      
      $rtn = $this->RemoteRequest_model->Update($sql, $values, false);

      
      // Performance: End
      $time += microtime(true);
      $timeStr = sprintf('%0.2f', $time);
      
      echo formatReturnData($rtn);
  }
  
  public function remoteDB() 
  {
      header('Content-Type: application/json');
            
      if($this->input->method(true) == 'POST'){
          echo json_encode(createResourceElement(
              $this->users["table"], $this->users["create_fields"], $this->users["create_types"],
              [$_POST["username"],
                  password_hash(hash("sha512", $_POST["password"], true), PASSWORD_DEFAULT),
                  $_POST["email"]]
              ));
          return;
      }
      // Update - PUT
      if($this->input->method(true) == 'PUT'){
          if(check_jwt_cookie($this->auth["service_name"], $this->auth["cookie_name"])){
              $jwt = get_jwt_data($this->auth["cookie_name"]);
              $_PUT = get_request_body();
              if(isset($jwt["username"]) && $jwt["username"] == $_PUT["username"]) {
                  echo json_encode(updateResourceElement(
                      $this->users["table"], $this->users["update_fields"], "s",
                      [$_PUT["email"]], $this->users["update_key"], $_PUT["username"]
                      ));
                  return;
              }
              echo json_encode(array(
                  "code" => BAD_CREDENTIALS,
                  "message" => "Token does not match the provided credentials."
              ));
              return;
          }
          echo json_encode(array(
              "code" => NO_COOKIE,
              "message" => "Token not found or invalid."
          ));
          return;
      }
      // Delete - DELETE
      if($this->input->method(true) == 'DELETE'){
          if(check_jwt_cookie($this->auth["service_name"], $this->auth["cookie_name"])){
              $jwt = get_jwt_data($this->auth["cookie_name"]);
              $_DELETE = get_request_body();
              if(isset($jwt["username"]) && $jwt["username"] == $_DELETE["username"]) {
                  echo json_encode(deleteResourceElement(
                      $this->users["table"], $this->users["delete_key"], $_DELETE["username"]
                      ));
                  return;
              }
              echo json_encode(array(
                  "code" => BAD_CREDENTIALS,
                  "message" => "Token does not match the provided credentials."
              ));
              return;
          }
          echo json_encode(array(
              "code" => NO_COOKIE,
              "message" => "Token not found or invalid."
          ));
          return;
      }
      // Read - GET
      if($param == ''){
          echo json_encode(readResourceRoot( $this->users["table"], $this->users["read_fields"]));
          return;
      }
      else{
          $data = readResourceElement(
              $this->users["table"], $this->users["read_fields"], $this->users["read_key"],
              $param
              );
          if($data == false)
              echo json_encode(array(
                  "code" => BAD_DATA,
                  "message" => "No user with this username."
              ));
              else
                  echo json_encode($data[0]);
      }
  }
  
}

?>