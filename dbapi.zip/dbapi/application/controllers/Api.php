<?php

/**
 * This is a sample implementation of a RESTful API. The database contains a
 * `users` table with four columns (`user_id`, `username`, `password` and
 * `email`).
 */
class Api extends CI_Controller
{

    private $users, $auth;

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('error_code');
        $this->load->helper('jwt');
        //$this->load->helper('request');
        $this->load->helper('auth');
        //$this->load->helper('rest_api');
    }

    public function login()
    { // echo (getBearerToken());
        header('Content-Type: application/json');
        log_message("ERROR", "ATTEMPTING TO LOGIN");
        if ($this->input->method(true) != 'POST') {
            echo json_encode(array(
                "message:" => "Use the HTTP POST method to login to the system."
            ));
            return;
        } else {
            $username       = isset($_POST["username"])     ? $_POST["username"]    : false;
            $password       = isset($_POST["password"])     ? $_POST["password"]    : false;
            $servername     = isset($_POST["servername"])   ? $_POST["servername"]  : false;
            $liblist        = isset($_POST["liblist"])      ? $_POST["liblist"]     : false;
            $conntype       = isset($_POST["conntype"])     ? $_POST["conntype"]    : false;
            $persistent     = isset($_POST["persistent"])   ? $_POST["persistent"]  : false;
            $dbjob          = isset($_POST["dbjob"])        ? $_POST["dbjob"]       : false;
            $pconntimout    = isset($_POST["pconntimout"])  ? $_POST["pconntimout"] : false;
            $store          = isset($_POST["store"])        ? $_POST["store"]       : false;
            
            echo formatReturnData(authorize($username, $password, $servername, $liblist, $conntype, $persistent, $dbjob, $pconntimout, $store));
            
            return;
        }
    }

    public function readToken()
    {
        $jwt_token = getBearerToken();
        temp_read_token($jwt_token);
    }

    public function validatetoken()
    {
        header('Content-Type: application/json');
        $jwt_token = getBearerToken();
        if ($jwt_token == false || ! is_jwt_valid($jwt_token)) {
            echo json_encode(array(
                "code" => BAD_CREDENTIALS,
                "message" => "Token is not valid."
            ));
            
            return;
        } else {
            echo json_encode(array(
                "code" => SUCCESS,
                "message" => "Token is valid."
            ));
        }
        return;
    }

    public function renewtoken()
    {
        header('Content-Type: application/json');
        $jwt_token = getBearerToken();
        if ($jwt_token != false/*  && !is_jwt_valid($jwt_token) */){
            
            echo json_encode(regenerate_jwt($jwt_token));
            return;
        }
    }

    /**
     * Index method for completeness.
     * Returns a JSON response with an
     * error message.
     */
    public function index()
    {
        header('Content-Type: application/json');
        echo json_encode(array(
            "code" => BAD_DATA,
            "message" => "No resource specified."
        ));
    }
}
?>
